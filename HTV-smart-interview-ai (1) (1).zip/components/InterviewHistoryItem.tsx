
import React, { useState } from 'react';
import { Interview } from '../types';
import { ChevronDownIcon, CalendarIcon, SparklesIcon } from './icons';

// Framer Motion mock for animation
const motion = {
    div: ({ children, ...props }: React.PropsWithChildren<any>) => <div {...props}>{children}</div>,
    section: ({ children, ...props }: React.PropsWithChildren<any>) => <section {...props}>{children}</section>,
};

interface InterviewHistoryItemProps {
    interview: Interview;
}

const InterviewHistoryItem: React.FC<InterviewHistoryItemProps> = ({ interview }) => {
    const [isOpen, setIsOpen] = useState(false);

    const scoreColor = interview.score > 80 ? 'text-green-400' : interview.score > 60 ? 'text-yellow-400' : 'text-red-400';

    return (
        <div className="border border-gray-200 dark:border-gray-700/80 rounded-lg overflow-hidden">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="w-full flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800/50 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            >
                <div className="flex items-center gap-4">
                     <div className="flex items-center gap-2 text-gray-500 dark:text-gray-400">
                        <CalendarIcon className="w-5 h-5"/>
                        <span className="font-medium">{interview.date}</span>
                    </div>
                    <span className="font-semibold">{interview.role}</span>
                </div>
                <div className="flex items-center gap-4">
                    <span className={`text-lg font-bold ${scoreColor}`}>{interview.score}%</span>
                    <ChevronDownIcon className={`w-5 h-5 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
                </div>
            </button>
            {isOpen && (
                <motion.section
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3 }}
                    className="p-6 bg-white dark:bg-gray-900/50"
                >
                    <div className="flex items-center gap-2 mb-4 text-lg font-semibold text-transparent bg-clip-text bg-gradient-to-r from-brand-accent-light to-brand-secondary">
                        <SparklesIcon className="w-6 h-6 text-brand-accent-light"/>
                        AI-Powered Analysis
                    </div>
                    <div className="space-y-4">
                        <div>
                            <h4 className="font-bold mb-1">Summary</h4>
                            <p className="text-gray-600 dark:text-gray-300 text-sm">{interview.analysis.summary}</p>
                        </div>
                         <div>
                            <h4 className="font-bold mb-2">Key Strengths</h4>
                            <ul className="list-disc list-inside space-y-1 text-sm">
                                {interview.analysis.strengths.map((strength, i) => <li key={i} className="text-green-600 dark:text-green-400"><span className="text-gray-600 dark:text-gray-300">{strength}</span></li>)}
                            </ul>
                        </div>
                         <div>
                            <h4 className="font-bold mb-2">Areas for Improvement</h4>
                            <ul className="list-disc list-inside space-y-1 text-sm">
                                {interview.analysis.improvements.map((item, i) => <li key={i} className="text-yellow-600 dark:text-yellow-400"><span className="text-gray-600 dark:text-gray-300">{item}</span></li>)}
                            </ul>
                        </div>
                    </div>
                </motion.section>
            )}
        </div>
    );
};

export default InterviewHistoryItem;
