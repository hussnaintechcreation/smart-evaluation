
import React from 'react';

interface SummaryCardProps {
    title: string;
    value: string;
    change: string;
    changeType: 'increase' | 'decrease';
}

const ArrowUpIcon = () => (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path>
    </svg>
);

const ArrowDownIcon = () => (
     <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
    </svg>
);

const SummaryCard: React.FC<SummaryCardProps> = ({ title, value, change, changeType }) => {
    const isIncrease = changeType === 'increase';
    const changeColor = isIncrease ? 'text-green-400' : 'text-red-400';

    return (
        <div className="bg-white dark:bg-gray-900/50 dark:backdrop-blur-sm p-6 rounded-xl shadow-lg border border-transparent dark:border-gray-700/50 hover:border-brand-accent-dark transition-all duration-300 transform hover:-translate-y-1">
            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">{title}</h3>
            <p className="text-3xl font-bold mt-2">{value}</p>
            <div className={`flex items-center mt-2 text-sm ${changeColor}`}>
                {isIncrease ? <ArrowUpIcon /> : <ArrowDownIcon />}
                <span className="ml-1 font-semibold">{change}</span>
                <span className="text-gray-500 dark:text-gray-400 ml-1">vs last month</span>
            </div>
        </div>
    );
};

export default SummaryCard;
