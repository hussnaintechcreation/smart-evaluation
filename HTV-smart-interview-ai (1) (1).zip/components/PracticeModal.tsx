
import React from 'react';
import { XIcon } from './icons';

interface PracticeModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const PracticeModal: React.FC<PracticeModalProps> = ({ isOpen, onClose }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-white dark:bg-brand-card border border-brand-accent-dark/30 rounded-2xl shadow-2xl w-full max-w-lg p-8 m-4 relative">
                <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-white">
                    <XIcon className="w-6 h-6"/>
                </button>
                <div className="text-center">
                    <h2 className="text-2xl font-bold font-display text-brand-text-primary mb-4">Practice Interview</h2>
                    <p className="text-brand-text-secondary mb-6">
                        Welcome to your practice session. This is a great opportunity to get comfortable with the platform. Your video and audio will be recorded, but the results will not be saved or shared.
                    </p>
                    <ul className="text-left text-brand-text-secondary space-y-2 mb-8">
                        <li>- Ensure you are in a quiet, well-lit room.</li>
                        <li>- Use a stable internet connection.</li>
                        <li>- Speak clearly into your microphone.</li>
                    </ul>
                    <button
                        className="w-full bg-brand-accent-light text-brand-dark py-3 rounded-lg text-lg font-bold font-display tracking-wider transition-all duration-300 hover:bg-white hover:shadow-glow-accent"
                    >
                        Start Practice Session
                    </button>
                </div>
            </div>
        </div>
    );
};

export default PracticeModal;
