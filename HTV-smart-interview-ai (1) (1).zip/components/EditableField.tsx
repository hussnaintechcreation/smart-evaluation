import React, { useState, useEffect } from 'react';
import { PencilIcon, CheckIcon, XIcon } from './icons';

interface EditableFieldProps {
    label: string;
    value: string;
    onSave: (newValue: string) => void;
    type?: 'text' | 'date' | 'select';
    options?: string[];
}

const EditableField: React.FC<EditableFieldProps> = ({ label, value, onSave, type = 'text', options = [] }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [currentValue, setCurrentValue] = useState(value);

    useEffect(() => {
        setCurrentValue(value);
    }, [value]);

    const handleSave = () => {
        onSave(currentValue);
        setIsEditing(false);
    };

    const handleCancel = () => {
        setCurrentValue(value);
        setIsEditing(false);
    };

    const renderInput = () => {
        if (type === 'select') {
            return (
                 <select
                    value={currentValue}
                    onChange={(e) => setCurrentValue(e.target.value)}
                    className="w-full bg-gray-100 dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-brand-accent-dark"
                >
                    {options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                </select>
            );
        }
        return (
            <input
                type={type}
                value={currentValue}
                onChange={(e) => setCurrentValue(e.target.value)}
                autoFocus
                onBlur={handleCancel}
                onKeyDown={(e) => e.key === 'Enter' && handleSave()}
                className="w-full bg-gray-100 dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-brand-accent-dark"
            />
        )
    }

    return (
        <div>
            <label className="text-sm font-medium text-gray-500 dark:text-gray-400">{label}</label>
            <div className="mt-1 flex items-center gap-2">
                {isEditing ? (
                    <>
                        {renderInput()}
                        <div className="relative group">
                            <button onClick={handleSave} className="p-2 text-green-500 rounded-full hover:bg-green-500/10"><CheckIcon className="w-5 h-5"/></button>
                            <span className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 px-2 py-1 bg-gray-800 text-white text-xs rounded-md opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-10">Save</span>
                        </div>
                        <div className="relative group">
                            <button onClick={handleCancel} className="p-2 text-red-500 rounded-full hover:bg-red-500/10"><XIcon className="w-5 h-5"/></button>
                             <span className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 px-2 py-1 bg-gray-800 text-white text-xs rounded-md opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-10">Cancel</span>
                        </div>
                    </>
                ) : (
                    <>
                        <p className="font-semibold flex-grow">{value}</p>
                        <div className="relative group">
                            <button onClick={() => setIsEditing(true)} className="p-2 text-gray-500 rounded-full hover:bg-gray-500/10"><PencilIcon className="w-4 h-4"/></button>
                            <span className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 px-2 py-1 bg-gray-800 text-white text-xs rounded-md opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-10">Edit</span>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};

export default EditableField;