
export const formatCNIC = (value: string): string => {
    const cnic = value.replace(/\D/g, '').substring(0, 13);
    if (cnic.length > 12) {
        return `${cnic.slice(0, 5)}-${cnic.slice(5, 12)}-${cnic.slice(12)}`;
    }
    if (cnic.length > 5) {
        return `${cnic.slice(0, 5)}-${cnic.slice(5)}`;
    }
    return cnic;
};

export const validateCNIC = (value: string): boolean => {
    const cnicRegex = /^[0-9]{5}-[0-9]{7}-[0-9]$/;
    return cnicRegex.test(value);
};
