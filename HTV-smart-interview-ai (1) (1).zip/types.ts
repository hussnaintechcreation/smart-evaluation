
export enum Theme {
    LIGHT = 'light',
    DARK = 'dark',
}

export enum AuthView {
    LANDING = 'landing',
    LOGIN = 'login',
    SIGNUP = 'signup',
}

export enum UserRole {
    CANDIDATE = 'candidate',
    ADMIN = 'admin',
}

export enum CandidateStatus {
    PENDING = 'Pending',
    INTERVIEWING = 'Interviewing',
    OFFERED = 'Offered',
    REJECTED = 'Rejected',
}

export interface Candidate {
    id: string;
    name: string;
    email: string;
    status: CandidateStatus;
    score: number;
}

export interface AIAnalysis {
    summary: string;
    strengths: string[];
    improvements: string[];
}

export interface Interview {
    id: string;
    date: string;
    role: string;
    score: number;
    status: 'Completed' | 'Scheduled';
    analysis: AIAnalysis;
}

export interface CandidateProfileData {
    id: string;
    name: string;
    fatherName: string;
    gender: 'Male' | 'Female' | 'Other';
    dob: string;
    cnic: string;
    photoUrl: string;
    interviews: Interview[];
}
