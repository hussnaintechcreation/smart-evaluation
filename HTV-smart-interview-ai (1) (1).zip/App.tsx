
import React, { useState, useEffect, useCallback } from 'react';
import AuthPage from './pages/AuthPage';
import AdminDashboard from './pages/AdminDashboard';
import Globe from './3D/Globe';
import { useTheme } from './hooks/useTheme';

const App: React.FC = () => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const { theme } = useTheme();

    useEffect(() => {
        // Manage body class for theme-specific styles
        if (isAuthenticated) {
            document.body.classList.remove('auth-page-active', 'dark');
            document.body.classList.add(theme); // 'light' or 'dark'
        } else {
            document.body.classList.remove('light');
            document.body.classList.add('auth-page-active', 'dark');
        }
    }, [isAuthenticated, theme]);

    const handleLogin = useCallback(() => {
        setIsAuthenticated(true);
    }, []);

    const handleLogout = useCallback(() => {
        setIsAuthenticated(false);
    }, []);

    return (
        <div className="w-screen h-screen overflow-hidden">
            {!isAuthenticated && <Globe />}
            {isAuthenticated ? (
                <AdminDashboard onLogout={handleLogout} />
            ) : (
                <AuthPage onLogin={handleLogin} />
            )}
        </div>
    );
};

export default App;
