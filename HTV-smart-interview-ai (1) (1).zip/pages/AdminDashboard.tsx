
import React, { useState } from 'react';
import SummaryCard from '../components/SummaryCard';
import CandidateListPage from './CandidateListPage';
import CandidateProfilePage from './CandidateProfilePage';
import { useTheme } from '../hooks/useTheme';
import { LayoutDashboardIcon, UsersIcon, LogOutIcon } from '../components/icons';

interface AdminDashboardProps {
    onLogout: () => void;
}

const SunIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m4.93 17.66 1.41-1.41"/><path d="m17.66 4.93 1.41-1.41"/></svg>
);

const MoonIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>
);

type View = {
    page: 'dashboard' | 'candidates' | 'profile';
    candidateId?: string | null;
};

const AdminDashboard: React.FC<AdminDashboardProps> = ({ onLogout }) => {
    const [view, setView] = useState<View>({ page: 'dashboard' });
    const { theme, toggleTheme } = useTheme();

    const handleViewCandidate = (candidateId: string) => {
        setView({ page: 'profile', candidateId });
    };

    const handleBackToList = () => {
        setView({ page: 'candidates' });
    };

    const renderContent = () => {
        switch (view.page) {
            case 'profile':
                return <CandidateProfilePage candidateId={view.candidateId!} onBack={handleBackToList} />;
            case 'candidates':
                return <CandidateListPage onViewCandidate={handleViewCandidate} />;
            case 'dashboard':
            default:
                return (
                     <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <SummaryCard title="Total Candidates" value="1,250" change="+15.3%" changeType="increase" />
                        <SummaryCard title="Interviews Conducted" value="832" change="+5.1%" changeType="increase" />
                        <SummaryCard title="Offers Extended" value="98" change="-2.5%" changeType="decrease" />
                        <SummaryCard title="Hiring Rate" value="7.8%" change="+0.2%" changeType="increase" />
                    </div>
                );
        }
    };
    
    const getPageTitle = () => {
        switch (view.page) {
            case 'profile':
                return 'Candidate Profile';
            case 'candidates':
                return 'Candidate Management';
            case 'dashboard':
            default:
                return 'Dashboard Overview';
        }
    }

    return (
        <div className="flex h-screen bg-gray-100 dark:bg-brand-dark text-gray-800 dark:text-brand-text-primary">
            {/* Sidebar */}
            <aside className="w-64 bg-white dark:bg-gray-900/70 dark:backdrop-blur-sm flex flex-col border-r border-gray-200 dark:border-gray-800 transition-colors duration-300">
                <div className="h-20 flex items-center justify-center border-b border-gray-200 dark:border-gray-800">
                    <h1 className="text-xl font-bold font-display text-transparent bg-clip-text bg-gradient-to-r from-brand-accent-light to-brand-secondary">Smart Interview AI</h1>
                </div>
                <nav className="flex-1 px-4 py-6 space-y-2">
                    <a href="#" onClick={(e) => {e.preventDefault(); setView({ page: 'dashboard' });}} className={`flex items-center gap-3 px-4 py-2 rounded-lg transition-colors ${view.page === 'dashboard' ? 'bg-brand-accent-dark/20 text-brand-accent-light' : 'hover:bg-gray-200 dark:hover:bg-gray-800'}`}>
                        <LayoutDashboardIcon className="w-5 h-5"/> Dashboard
                    </a>
                    <a href="#" onClick={(e) => {e.preventDefault(); setView({ page: 'candidates' });}} className={`flex items-center gap-3 px-4 py-2 rounded-lg transition-colors ${view.page === 'candidates' || view.page === 'profile' ? 'bg-brand-accent-dark/20 text-brand-accent-light' : 'hover:bg-gray-200 dark:hover:bg-gray-800'}`}>
                        <UsersIcon className="w-5 h-5" /> Candidates
                    </a>
                </nav>
                <div className="p-4 border-t border-gray-200 dark:border-gray-800">
                    <button
                        onClick={onLogout}
                        className="w-full text-left flex items-center gap-3 px-4 py-2 rounded-lg transition-colors hover:bg-gray-200 dark:hover:bg-gray-800"
                    >
                        <LogOutIcon className="w-5 h-5" /> Logout
                    </button>
                </div>
            </aside>

            {/* Main Content */}
            <main className="flex-1 flex flex-col overflow-hidden">
                <header className="h-20 flex items-center justify-between px-8 border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900/70 dark:backdrop-blur-sm shrink-0">
                    <h2 className="text-2xl font-semibold">{getPageTitle()}</h2>
                    <div className="flex items-center space-x-4">
                        <button onClick={toggleTheme} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700">
                            {theme === 'dark' ? <SunIcon /> : <MoonIcon />}
                        </button>
                        <div className="w-10 h-10 bg-gradient-to-br from-brand-accent-light to-brand-secondary rounded-full"></div>
                    </div>
                </header>
                <div className="flex-1 p-8 overflow-y-auto">
                    {renderContent()}
                </div>
            </main>
        </div>
    );
};

export default AdminDashboard;
