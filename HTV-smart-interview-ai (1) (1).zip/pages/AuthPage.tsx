
import React, { useState } from 'react';
import { AuthView, UserRole } from '../types';
import { formatCNIC, validateCNIC } from '../utils/cnic';
import { UserIcon, LockKeyholeIcon, BriefcaseBusinessIcon } from '../components/icons';

interface AuthPageProps {
    onLogin: () => void;
}

const AuthPage: React.FC<AuthPageProps> = ({ onLogin }) => {
    const [view, setView] = useState<AuthView>(AuthView.LANDING);
    const [role, setRole] = useState<UserRole | null>(null);
    const [cnic, setCnic] = useState('');
    const [error, setError] = useState('');

    const handlePortalSelect = (selectedRole: UserRole) => {
        setRole(selectedRole);
        setView(AuthView.LOGIN);
    };

    const handleCnicChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setCnic(formatCNIC(e.target.value));
        if (error) setError('');
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (role === UserRole.CANDIDATE) {
            if (!validateCNIC(cnic)) {
                setError('Invalid CNIC format. Please use #####-#######-#.');
                return;
            }
        }
        // Mock login success
        console.log(`Logging in as ${role} with CNIC: ${cnic}`);
        onLogin();
    };

    const renderLandingView = () => (
        <div className="flex flex-col items-center gap-6 w-full animate-fadeIn">
            <button
                onClick={() => handlePortalSelect(UserRole.CANDIDATE)}
                className="w-full bg-transparent text-brand-accent-light border-2 border-brand-accent-light py-3 rounded-lg text-lg font-bold font-display tracking-wider transition-all duration-300 hover:bg-brand-accent-light hover:text-brand-dark hover:shadow-glow-accent"
            >
                Candidate Portal
            </button>
            <button
                onClick={() => handlePortalSelect(UserRole.ADMIN)}
                className="w-full bg-transparent text-brand-secondary border-2 border-brand-secondary py-3 rounded-lg text-lg font-bold font-display tracking-wider transition-all duration-300 hover:bg-brand-secondary hover:text-brand-dark hover:shadow-glow-secondary"
            >
                Admin Portal
            </button>
        </div>
    );

    const renderFormView = () => (
        <div className="w-full relative animate-fadeIn">
            <button onClick={() => setView(AuthView.LANDING)} className="absolute -top-12 -left-4 text-brand-text-secondary hover:text-brand-accent-light transition-colors">
                 <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
            </button>
            <h2 className="text-2xl font-bold font-display text-center mb-2 text-brand-text-primary">
                {role === UserRole.CANDIDATE ? 'Candidate' : 'Admin'} Login
            </h2>
            <p className="text-center text-brand-text-secondary mb-8">
                {view === AuthView.LOGIN ? 'Sign in to continue' : 'Create your account'}
            </p>
            <form onSubmit={handleSubmit} className="space-y-6">
                {role === UserRole.CANDIDATE ? (
                    <div className="relative">
                        <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-brand-text-secondary" />
                        <input
                            type="text"
                            placeholder="CNIC (#####-#######-#)"
                            value={cnic}
                            onChange={handleCnicChange}
                            className="w-full bg-transparent border-b-2 border-gray-500 text-white pl-10 py-2 focus:outline-none focus:border-brand-accent-light transition-colors"
                            required
                        />
                    </div>
                ) : (
                     <div className="relative">
                        <BriefcaseBusinessIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-brand-text-secondary" />
                        <input
                            type="email"
                            placeholder="Work Email"
                            className="w-full bg-transparent border-b-2 border-gray-500 text-white pl-10 py-2 focus:outline-none focus:border-brand-secondary transition-colors"
                            required
                        />
                    </div>
                )}
                <div className="relative">
                    <LockKeyholeIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-brand-text-secondary" />
                    <input
                        type="password"
                        placeholder="Password"
                        className="w-full bg-transparent border-b-2 border-gray-500 text-white pl-10 py-2 focus:outline-none focus:border-brand-accent-light transition-colors"
                        required
                    />
                </div>
                {error && <p className="text-red-400 text-sm text-center">{error}</p>}
                <button
                    type="submit"
                    className="w-full bg-brand-accent-light text-brand-dark py-3 rounded-lg text-lg font-bold font-display tracking-wider transition-all duration-300 hover:bg-white hover:shadow-glow-accent"
                >
                    {view === AuthView.LOGIN ? 'Login' : 'Sign Up'}
                </button>
            </form>
        </div>
    );

    return (
        <div className="flex items-center justify-center min-h-screen">
            <div className="w-full max-w-md mx-auto p-8 sm:p-12 bg-brand-card border border-brand-accent-dark/30 rounded-2xl backdrop-blur-sm shadow-2xl">
                <header className="text-center mb-8">
                    <div className="w-16 h-16 bg-gradient-to-br from-[#2B2E6A] to-[#5B2D6E] rounded-2xl mx-auto mb-4 flex items-center justify-center">
                        <svg className="w-10 h-10 text-white" viewBox="0 0 24 24" fill="currentColor"><path d="M12 14c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0-6c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2z"/><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm0-14c-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4z"/><path d="M12 16c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4zm0 1.9c2.97 0 6.1 1.46 6.1 2.1H5.9c0-.64 3.13-2.1 6.1-2.1z"/></svg>
                    </div>
                    <h1 className="text-3xl font-bold font-display text-brand-text-primary">Smart Interview AI</h1>
                    <p className="text-brand-text-secondary mt-1">Powered by HUSSNAIN’S TECH CREATION PVT LTD.</p>
                </header>
                <main>
                    {view === AuthView.LANDING ? renderLandingView() : renderFormView()}
                </main>
            </div>
        </div>
    );
};

export default AuthPage;
