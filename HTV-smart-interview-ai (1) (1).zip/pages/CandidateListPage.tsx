import React, { useState, useMemo } from 'react';
import { Candidate, CandidateStatus } from '../types';
import { ChevronsUpDownIcon, ChevronUpIcon, ChevronDownIcon, EyeIcon, Trash2Icon } from '../components/icons';

const mockCandidates: Candidate[] = [
    { id: '1', name: 'Zainab Ahmed', email: 'zainab.a@example.com', status: CandidateStatus.OFFERED, score: 92 },
    { id: '2', name: 'Bilal Khan', email: 'bilal.k@example.com', status: CandidateStatus.INTERVIEWING, score: 85 },
    { id: '3', name: 'Ayesha Malik', email: 'ayesha.m@example.com', status: CandidateStatus.PENDING, score: 0 },
    { id: '4', name: 'Usman Tariq', email: 'usman.t@example.com', status: CandidateStatus.REJECTED, score: 68 },
    { id: '5', name: 'Fatima Ali', email: 'fatima.a@example.com', status: CandidateStatus.INTERVIEWING, score: 78 },
    { id: '6', name: 'Hassan Raza', email: 'hassan.r@example.com', status: CandidateStatus.OFFERED, score: 95 },
    { id: '7', name: 'Sana Javed', email: 'sana.j@example.com', status: CandidateStatus.PENDING, score: 0 },
    { id: '8', name: 'Ali Hassan', email: 'ali.h@example.com', status: CandidateStatus.REJECTED, score: 55 },
];

type SortConfig = {
    key: keyof Candidate;
    direction: 'ascending' | 'descending';
} | null;

interface CandidateListPageProps {
    onViewCandidate: (candidateId: string) => void;
}

const CandidateListPage: React.FC<CandidateListPageProps> = ({ onViewCandidate }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState<CandidateStatus | 'all'>('all');
    const [sortConfig, setSortConfig] = useState<SortConfig>(null);

    const filteredCandidates = useMemo(() => {
        let sortableCandidates = [...mockCandidates];

        if (sortConfig !== null) {
            sortableCandidates.sort((a, b) => {
                if (a[sortConfig.key] < b[sortConfig.key]) {
                    return sortConfig.direction === 'ascending' ? -1 : 1;
                }
                if (a[sortConfig.key] > b[sortConfig.key]) {
                    return sortConfig.direction === 'ascending' ? 1 : -1;
                }
                return 0;
            });
        }

        return sortableCandidates.filter(candidate => {
            const matchesSearch = candidate.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                candidate.email.toLowerCase().includes(searchTerm.toLowerCase());
            const matchesFilter = statusFilter === 'all' || candidate.status === statusFilter;
            return matchesSearch && matchesFilter;
        });
    }, [searchTerm, statusFilter, sortConfig]);

    const requestSort = (key: keyof Candidate) => {
        let direction: 'ascending' | 'descending' = 'ascending';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
            direction = 'descending';
        }
        setSortConfig({ key, direction });
    };

    const getSortIcon = (key: keyof Candidate) => {
        if (!sortConfig || sortConfig.key !== key) {
            return <ChevronsUpDownIcon className="w-4 h-4 ml-2 opacity-50" />;
        }
        if (sortConfig.direction === 'ascending') {
            return <ChevronUpIcon className="w-4 h-4 ml-2" />;
        }
        return <ChevronDownIcon className="w-4 h-4 ml-2" />;
    };
    
    const statusColorMap: Record<CandidateStatus, string> = {
        [CandidateStatus.PENDING]: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
        [CandidateStatus.INTERVIEWING]: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
        [CandidateStatus.OFFERED]: 'bg-green-500/20 text-green-400 border-green-500/30',
        [CandidateStatus.REJECTED]: 'bg-red-500/20 text-red-400 border-red-500/30',
    };

    return (
        <div className="bg-white dark:bg-gray-900/50 dark:backdrop-blur-sm p-6 rounded-xl shadow-lg border border-transparent dark:border-gray-700/50">
            <div className="flex items-center justify-between mb-6">
                <input
                    type="text"
                    placeholder="Search by name or email..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="bg-gray-100 dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-lg px-4 py-2 w-1/3 focus:outline-none focus:ring-2 focus:ring-brand-accent-dark"
                />
                <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value as CandidateStatus | 'all')}
                    className="bg-gray-100 dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-brand-accent-dark"
                >
                    <option value="all">All Statuses</option>
                    {Object.values(CandidateStatus).map(status => (
                        <option key={status} value={status}>{status}</option>
                    ))}
                </select>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-left">
                    <thead className="border-b-2 border-gray-200 dark:border-gray-700">
                        <tr>
                            {['name', 'email', 'status', 'score'].map((key) => (
                                <th key={key} className="p-4 uppercase text-sm font-semibold text-gray-500 dark:text-gray-400 cursor-pointer" onClick={() => requestSort(key as keyof Candidate)}>
                                    <div className="flex items-center">
                                        {key} {getSortIcon(key as keyof Candidate)}
                                    </div>
                                </th>
                            ))}
                            <th className="p-4 uppercase text-sm font-semibold text-gray-500 dark:text-gray-400 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredCandidates.map(candidate => (
                            <tr key={candidate.id} className="border-b border-gray-200 dark:border-gray-800 hover:bg-gray-100 dark:hover:bg-gray-800/50">
                                <td className="p-4 font-medium">{candidate.name}</td>
                                <td className="p-4 text-gray-600 dark:text-gray-300">{candidate.email}</td>
                                <td className="p-4">
                                    <span className={`px-3 py-1 text-xs font-semibold rounded-full border ${statusColorMap[candidate.status]}`}>
                                        {candidate.status}
                                    </span>
                                </td>
                                <td className={`p-4 font-bold ${candidate.score > 80 ? 'text-green-400' : candidate.score > 60 ? 'text-yellow-400' : 'text-red-400'}`}>
                                    {candidate.score > 0 ? `${candidate.score}%` : 'N/A'}
                                </td>
                                <td className="p-4 text-right">
                                    <div className="relative inline-flex items-center group">
                                        <button onClick={() => onViewCandidate(candidate.id)} className="p-2 text-gray-500 hover:text-brand-accent-light rounded-full hover:bg-brand-accent-dark/10 transition-colors"><EyeIcon className="w-5 h-5"/></button>
                                        <span className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 px-2 py-1 bg-gray-800 text-white text-xs rounded-md opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-10">
                                            View Details
                                        </span>
                                    </div>
                                    <div className="relative inline-flex items-center group ml-2">
                                        <button className="p-2 text-gray-500 hover:text-red-500 rounded-full hover:bg-red-500/10 transition-colors"><Trash2Icon className="w-5 h-5"/></button>
                                         <span className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 px-2 py-1 bg-gray-800 text-white text-xs rounded-md opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-10">
                                            Delete
                                        </span>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default CandidateListPage;