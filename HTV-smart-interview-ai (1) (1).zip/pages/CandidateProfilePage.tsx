import React, { useState } from 'react';
import { CandidateProfileData } from '../types';
import EditableField from '../components/EditableField';
import InterviewHistoryItem from '../components/InterviewHistoryItem';
import PracticeModal from '../components/PracticeModal';
import { UserIcon } from '../components/icons';

const mockProfile: CandidateProfileData = {
    id: '1',
    name: 'Zainab Ahmed',
    fatherName: 'Ahmed Ali',
    gender: 'Female',
    dob: '1998-05-15',
    cnic: '35202-1234567-8',
    photoUrl: '', // Set to empty to test fallback avatar
    interviews: [
        { 
            id: 'i1', date: '2024-07-10', role: 'Senior Frontend Engineer', score: 92, status: 'Completed', 
            analysis: {
                summary: 'Zainab is a highly skilled frontend engineer with deep expertise in React and modern state management. She communicated her thought process clearly and provided optimal solutions to technical challenges.',
                strengths: ['Excellent problem-solving skills', 'Strong communication', 'In-depth knowledge of React hooks and context API'],
                improvements: ['Could elaborate more on testing strategies for micro-frontends'],
            }
        },
        { 
            id: 'i2', date: '2024-06-25', role: 'Frontend Developer (Screening)', score: 88, status: 'Completed',
            analysis: {
                summary: 'Candidate demonstrated strong fundamentals in JavaScript and CSS. Showed good potential and a passion for UI/UX design.',
                strengths: ['Solid grasp of core web technologies', 'Creative approach to UI problems'],
                improvements: ['Experience with large-scale state management libraries is limited'],
            }
        },
    ]
};


interface CandidateProfilePageProps {
    candidateId: string;
    onBack: () => void;
}

const CandidateProfilePage: React.FC<CandidateProfilePageProps> = ({ candidateId, onBack }) => {
    const [profile, setProfile] = useState<CandidateProfileData>(mockProfile);
    const [isPracticeModalOpen, setPracticeModalOpen] = useState(false);

    const handleSave = (field: keyof CandidateProfileData, value: string) => {
        setProfile(prev => ({ ...prev, [field]: value }));
        // Here you would typically call an API to save the data
        console.log(`Saving ${field}: ${value}`);
    };

    return (
        <>
            <div className="space-y-8">
                <button onClick={onBack} className="flex items-center gap-2 text-sm text-brand-accent-light hover:underline">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><path d="m15 18-6-6 6-6"/></svg>
                    Back to Candidate List
                </button>

                {/* Profile Header */}
                <div className="bg-white dark:bg-gray-900/50 dark:backdrop-blur-sm p-6 rounded-xl shadow-lg border border-transparent dark:border-gray-700/50">
                    <div className="flex items-start gap-6">
                        {profile.photoUrl ? (
                             <img src={profile.photoUrl} alt={profile.name} className="w-24 h-24 rounded-full border-4 border-brand-accent-dark object-cover shadow-lg shadow-brand-accent-dark/20"/>
                        ) : (
                            <div className="w-24 h-24 rounded-full border-4 border-brand-accent-dark bg-gray-200 dark:bg-gray-700 flex items-center justify-center shadow-lg shadow-brand-accent-dark/20">
                                <UserIcon className="w-12 h-12 text-gray-500 dark:text-gray-400" />
                            </div>
                        )}
                        <div className="flex-grow grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-6">
                            <EditableField label="Full Name" value={profile.name} onSave={(val) => handleSave('name', val)} />
                            <EditableField label="Father's Name" value={profile.fatherName} onSave={(val) => handleSave('fatherName', val)} />
                            <EditableField label="Gender" value={profile.gender} onSave={(val) => handleSave('gender', val)} type="select" options={['Male', 'Female', 'Other']} />
                            <EditableField label="Date of Birth" value={profile.dob} onSave={(val) => handleSave('dob', val)} type="date" />
                            <EditableField label="CNIC" value={profile.cnic} onSave={(val) => handleSave('cnic', val)} />
                        </div>
                    </div>
                </div>

                {/* Interview History */}
                <div>
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-xl font-bold">Interview History</h2>
                         <button
                            onClick={() => setPracticeModalOpen(true)}
                            className="bg-brand-accent-light text-brand-dark px-4 py-2 rounded-lg font-bold font-display tracking-wider transition-all duration-300 hover:bg-white hover:shadow-glow-accent text-sm"
                        >
                            Start Practice Interview
                        </button>
                    </div>
                    <div className="space-y-4">
                        {profile.interviews.map(interview => (
                            <InterviewHistoryItem key={interview.id} interview={interview} />
                        ))}
                    </div>
                </div>
            </div>
            <PracticeModal isOpen={isPracticeModalOpen} onClose={() => setPracticeModalOpen(false)} />
        </>
    );
};

export default CandidateProfilePage;