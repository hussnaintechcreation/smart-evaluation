import { Injectable, signal, effect } from '@angular/core';
import { EvaluationResult } from './gemini.service';

export type InterviewTemplateType = 'technical' | 'behavioral' | 'situational' | 'general';

export interface InterviewQuestion {
  id: string;
  text: string;
}

export interface InterviewTemplate {
  id: string;
  jobTitle: string;
  category: string;
  experienceLevel: string;
  questions: string[];
  createdAt: string; // ISO string date
  type: InterviewTemplateType;
}

export interface InterviewResult {
  questionId: string;
  questionText: string;
  evaluation: EvaluationResult;
  answeredOn: string; // ISO string date
  userName: string;
  jobTitle: string; // Added for filtering
  category: string;  // Added for filtering
  experienceLevel: string; // Added for filtering
}

const initialDefaultTemplate: InterviewTemplate = {
  id: 'template_default',
  jobTitle: 'General Tech Practice',
  category: 'General',
  experienceLevel: 'Entry-Level',
  createdAt: new Date().toISOString(),
  type: 'general',
  questions: [
    "Can you explain the difference between `let`, `const`, and `var` in JavaScript?",
    "What is the purpose of the `async` and `await` keywords in TypeScript?",
    "Describe the concept of dependency injection in Angular.",
    "What are Angular Signals and how do they improve change detection?",
    "Explain the 'box model' in CSS."
  ]
};

@Injectable({
  providedIn: 'root'
})
export class InterviewService {
  private readonly TEMPLATES_STORAGE_KEY = 'evalion_templates';
  private readonly RESULTS_STORAGE_KEY = 'evalion_results';

  // This signal now holds interview templates
  interviewTemplates = signal<InterviewTemplate[]>([]);
  results = signal<InterviewResult[]>([]);
  
  // This is now a temporary holder for the questions of the *active* interview
  activeQuestions = signal<string[]>([]);
  activeTemplate = signal<InterviewTemplate | null>(null); // Track the active template

  constructor() {
    this.loadFromLocalStorage();

    // Persist to localStorage whenever signals change
    effect(() => {
      this.saveToLocalStorage(this.TEMPLATES_STORAGE_KEY, this.interviewTemplates());
      this.saveToLocalStorage(this.RESULTS_STORAGE_KEY, this.results());
    });
  }

  // --- Template Management (Admin) ---

  getInterviewTemplates(): InterviewTemplate[] {
    return this.interviewTemplates();
  }
  
  addInterviewTemplate(templateData: Omit<InterviewTemplate, 'id' | 'createdAt'>): void {
    const newTemplate: InterviewTemplate = {
      ...templateData,
      id: `template_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    this.interviewTemplates.update(current => [newTemplate, ...current]);
  }
  
  deleteInterviewTemplate(id: string): void {
    if (id === 'template_default') {
      alert("The default practice template cannot be deleted.");
      return;
    }
    this.interviewTemplates.update(current => current.filter(t => t.id !== id));
  }
  
  // --- Active Interview Management (Candidate) ---
  
  startInterviewSession(templateId: string): boolean {
    const template = this.interviewTemplates().find(t => t.id === templateId);
    if (template && template.questions.length > 0) {
      this.activeQuestions.set(template.questions);
      this.activeTemplate.set(template); // Set the active template
      return true;
    }
    this.activeQuestions.set([]);
    this.activeTemplate.set(null);
    return false;
  }
  
  getActiveQuestions(): string[] {
    return this.activeQuestions();
  }


  // --- Result Management (Candidate & Admin) ---

  getResults(): InterviewResult[] {
    return this.results();
  }

  addResult(result: Omit<InterviewResult, 'answeredOn'>): void {
    const newResult: InterviewResult = {
        ...result,
        answeredOn: new Date().toISOString()
    };
    this.results.update(current => [newResult, ...current]);
  }

  // --- Persistence ---

  private loadFromLocalStorage(): void {
    try {
      const storedTemplates = localStorage.getItem(this.TEMPLATES_STORAGE_KEY);
      if (storedTemplates) {
        let parsedTemplates: InterviewTemplate[] = JSON.parse(storedTemplates);

        // Migration: Add 'type' property if it doesn't exist
        parsedTemplates = parsedTemplates.map(t => ({ ...t, type: t.type || 'general' }));

        // Ensure default template always exists
        if (!parsedTemplates.find((t: InterviewTemplate) => t.id === 'template_default')) {
           this.interviewTemplates.set([initialDefaultTemplate, ...parsedTemplates]);
        } else {
           this.interviewTemplates.set(parsedTemplates);
        }
      } else {
        this.interviewTemplates.set([initialDefaultTemplate]); // Load default if nothing is stored
      }

      const storedResults = localStorage.getItem(this.RESULTS_STORAGE_KEY);
      if (storedResults) {
        this.results.set(JSON.parse(storedResults));
      }
    } catch (e) {
      console.error("Failed to load data from localStorage", e);
      this.interviewTemplates.set([initialDefaultTemplate]);
      this.results.set([]);
    }
  }

  private saveToLocalStorage(key: string, data: any): void {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.error(`Failed to save data to localStorage (key: ${key})`, e);
    }
  }
  
  // DEPRECATED METHODS for old question model - can be removed later
  getQuestions(): InterviewQuestion[] { return []; }
  addQuestion(text: string): void {}
  updateQuestion(id: string, newText: string): void {}
  deleteQuestion(id: string): void {}
}