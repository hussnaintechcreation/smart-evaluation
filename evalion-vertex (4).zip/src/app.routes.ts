import { Routes } from '@angular/router';
import { authGuard } from './guards/auth.guard';
import { LoginComponent } from './components/login/login.component';
import { CandidateDashboardComponent } from './components/candidate-dashboard/candidate-dashboard.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { LandingComponent } from './components/landing/landing.component';
import { SignupComponent } from './components/signup/signup.component';

export const APP_ROUTES: Routes = [
  { path: 'landing', component: LandingComponent },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { 
    path: 'candidate', 
    component: CandidateDashboardComponent,
    canActivate: [authGuard] 
  },
  { 
    path: 'admin', 
    component: AdminDashboardComponent,
    canActivate: [authGuard]
  },
  // Redirect to landing page by default
  { path: '', redirectTo: '/landing', pathMatch: 'full' },
  // Wildcard route for a 404 page or redirect
  { path: '**', redirectTo: '/landing' }
];