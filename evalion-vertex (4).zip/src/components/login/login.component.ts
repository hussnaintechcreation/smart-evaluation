import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService, UserRole } from '../../services/auth.service';
import { ChatbotComponent } from '../chatbot/chatbot.component'; // Import ChatbotComponent

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink, ChatbotComponent],
  templateUrl: './login.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoginComponent {
  private fb: FormBuilder = inject(FormBuilder);
  private authService = inject(AuthService);
  private router: Router = inject(Router);

  loginForm = this.fb.group({
    email: ['candidate@example.com', [Validators.required, Validators.email]],
    password: ['password123', Validators.required],
    rememberMe: [true]
  });

  // FIX: Widen type to include 'admin' for the login UI toggle.
  activeRole = signal<UserRole | 'admin'>('candidate');
  showPassword = signal(false);
  loginError = signal<string | null>(null);
  currentYear = new Date().getFullYear();

  constructor() {
    // If user is already authenticated, redirect them away from login
    if (this.authService.isAuthenticated()) {
        const role = this.authService.currentUserRole();
        this.router.navigate([role === 'candidate' ? '/candidate' : '/admin']);
    }
  }

  // FIX: Widen type to include 'admin' to match the signal and logic.
  setActiveRole(role: UserRole | 'admin'): void {
    this.activeRole.set(role);
    this.loginError.set(null);
    if (role === 'admin') {
        this.loginForm.patchValue({ email: 'admin@example.com' });
    } else {
        this.loginForm.patchValue({ email: 'candidate@example.com' });
    }
  }

  togglePasswordVisibility(): void {
    this.showPassword.update(value => !value);
  }
  
  forgotPassword(): void {
    alert("This is a mock-up. In a real application, this would trigger a password reset flow.");
  }

  onSubmit(): void {
    if (this.loginForm.invalid) {
      this.loginError.set('Please enter valid credentials.');
      return;
    }

    this.loginError.set(null);
    const { email, password } = this.loginForm.value;

    const success = this.authService.login(email!, password!, this.activeRole());

    if (!success) {
      this.loginError.set('Login failed. Please check your credentials.');
    }
    // On success, the auth service handles navigation
  }
}