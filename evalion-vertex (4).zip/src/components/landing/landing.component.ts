import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-landing',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './landing.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LandingComponent {
  // FIX: Explicitly define the type for the injected service.
  private router: Router = inject(Router);
  currentYear = new Date().getFullYear();

  navigateToLogin(): void {
    this.router.navigate(['/login']);
  }
}
