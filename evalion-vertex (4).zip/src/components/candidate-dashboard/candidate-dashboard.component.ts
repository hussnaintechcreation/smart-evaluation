import { ChangeDetectionStrategy, Component, computed, inject, signal, effect, OnInit, AfterViewInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { CommonModule, Location, DOCUMENT, DatePipe } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { InterviewComponent } from '../interview/interview.component';
import { ChatbotComponent } from '../chatbot/chatbot.component';
import { AuthService, User } from '../../services/auth.service';
import { InterviewService, InterviewResult, InterviewTemplate } from '../../services/interview.service';
import { ConfirmationDialogComponent } from '../shared/confirmation-dialog.component';
import { ThemeService } from '../../services/theme.service';
import { ThemeCustomizerComponent } from '../shared/theme-customizer.component';

declare var Chart: any;

type DashboardView = 'overview' | 'practice' | 'history' | 'profile' | 'theme-settings';

@Component({
  selector: 'app-candidate-dashboard',
  standalone: true,
  imports: [CommonModule, InterviewComponent, ChatbotComponent, DatePipe, ReactiveFormsModule, ConfirmationDialogComponent, ThemeCustomizerComponent],
  templateUrl: './candidate-dashboard.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CandidateDashboardComponent implements OnInit, AfterViewInit, OnDestroy {
  authService = inject(AuthService);
  interviewService = inject(InterviewService);
  themeService = inject(ThemeService);
  private location = inject(Location);
  private fb: FormBuilder = inject(FormBuilder);

  @ViewChild('performanceChart', { static: false }) performanceChart!: ElementRef<HTMLCanvasElement>;
  private chartInstance: any;

  view = signal<DashboardView>('overview');
  pastResults = signal<InterviewResult[]>([]);
  expandedResult = signal<string | null>(null);

  availableTemplates = signal<InterviewTemplate[]>([]);
  isPracticing = signal(false);

  // --- Filtering State ---
  jobTitleFilter = signal<string>('');
  categoryFilter = signal<string>('');
  experienceFilter = signal<string>('');

  uniqueJobTitles = computed(() => [...new Set(this.availableTemplates().map(t => t.jobTitle))]);
  uniqueCategories = computed(() => [...new Set(this.availableTemplates().map(t => t.category))]);
  uniqueExperienceLevels = computed(() => [...new Set(this.availableTemplates().map(t => t.experienceLevel))]);

  filteredTemplates = computed(() => {
    const templates = this.availableTemplates();
    const jobTitle = this.jobTitleFilter();
    const category = this.categoryFilter();
    const experience = this.experienceFilter();

    if (!jobTitle && !category && !experience) {
      return templates;
    }

    return templates.filter(template => {
      const matchesJobTitle = !jobTitle || template.jobTitle === jobTitle;
      const matchesCategory = !category || template.category === category;
      const matchesExperience = !experience || template.experienceLevel === experience;
      return matchesJobTitle && matchesCategory && matchesExperience;
    });
  });

  completedCount = computed(() => this.pastResults().length);
  averageScore = computed(() => {
    const results = this.pastResults();
    if (results.length === 0) return 0;
    const total = results.reduce((sum, result) => sum + result.evaluation.score, 0);
    return total / results.length;
  });
  highestScore = computed(() => {
    const results = this.pastResults();
    if (results.length === 0) return 0;
    return Math.max(...results.map(r => r.evaluation.score));
  });

  showLogoutConfirm = signal(false);

  // --- Profile State ---
  profileForm = this.fb.group({
    name: ['', Validators.required],
    fatherName: [''],
    dob: [''],
    cnic: [''],
    mobile: [''],
    photoUrl: ['']
  });
  isEditingProfile = signal(false);
  profileUpdateStatus = signal<{ message: string, type: 'success' | 'error' } | null>(null);

  constructor() {
     effect(() => {
      // Re-render chart if theme or results change
      this.pastResults();
      this.themeService.mode();
      if (this.view() === 'overview' && this.performanceChart?.nativeElement) {
        this.destroyChart();
        this.createChart();
      }
    });

    // Populate profile form when user data is available
    effect(() => {
      const user = this.authService.currentUser();
      if (user) {
        this.profileForm.patchValue({
          name: user.name,
          fatherName: user.fatherName,
          dob: user.dob,
          cnic: user.cnic,
          mobile: user.mobile,
          photoUrl: user.photoUrl,
        });
      }
    });
  }
  
  ngOnInit(): void {
    const user = this.authService.currentUser();
    this.pastResults.set(this.interviewService.getResults().filter(r => r.userName === user?.name));
    this.availableTemplates.set(this.interviewService.getInterviewTemplates());
  }

  ngAfterViewInit(): void {
    if (this.view() === 'overview') {
       this.createChart();
    }
  }

  ngOnDestroy(): void {
    this.destroyChart();
  }
  
  startPractice(templateId: string): void {
    if (this.interviewService.startInterviewSession(templateId)) {
        this.isPracticing.set(true);
    } else {
        alert("Could not start interview. The selected template has no questions.");
    }
  }

  private destroyChart(): void {
    if (this.chartInstance) {
      this.chartInstance.destroy();
      this.chartInstance = null;
    }
  }

  private createChart(): void {
    if (!this.performanceChart?.nativeElement || this.pastResults().length === 0) return;
    
    setTimeout(() => {
      if (!this.performanceChart?.nativeElement) return;
      const ctx = this.performanceChart.nativeElement.getContext('2d');
      if (!ctx) return;
      
      const isLightTheme = this.themeService.mode() === 'light';
      const gridColor = isLightTheme ? 'rgba(0, 0, 0, 0.1)' : 'rgba(255, 255, 255, 0.1)';
      const labelColor = isLightTheme ? '#374151' : '#E5E7EB';
      
      const reversedResults = [...this.pastResults()].reverse();
      const labels = reversedResults.map((_, i) => `Attempt ${i + 1}`);
      const data = reversedResults.map(r => r.evaluation.score);

      const gradient = ctx.createLinearGradient(0, 0, 0, 400);
      gradient.addColorStop(0, 'rgba(34, 211, 238, 0.6)');
      gradient.addColorStop(1, 'rgba(139, 92, 246, 0.1)');

      this.chartInstance = new Chart(ctx, {
        type: 'line', data: { labels: labels, datasets: [{ data: data, backgroundColor: gradient, borderColor: '#22D3EE', borderWidth: 2, pointBackgroundColor: '#FFFFFF', pointBorderColor: '#22D3EE', pointHoverBackgroundColor: '#22D3EE', pointHoverBorderColor: '#FFFFFF', tension: 0.4, fill: true, }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, max: 10, grid: { color: gridColor }, ticks: { color: labelColor } }, x: { grid: { display: false }, ticks: { color: labelColor } } } }
      });
    }, 10);
  }
  
  logout(confirmed: boolean): void {
    if(confirmed) {
      this.authService.logout();
    }
    this.showLogoutConfirm.set(false);
  }

  goBack(): void {
    if (this.isPracticing()) {
      this.isPracticing.set(false);
    } else {
      this.location.back();
    }
  }
  
  setView(newView: DashboardView): void {
    this.view.set(newView);
    this.isPracticing.set(false);
    this.isEditingProfile.set(false);
    if (newView === 'overview' && this.performanceChart) {
       this.destroyChart();
       this.ngAfterViewInit();
    }
  }
  
  toggleResultExpansion(questionId: string): void {
    this.expandedResult.update(current => current === questionId ? null : questionId);
  }
  
  onFileChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = () => {
        this.profileForm.patchValue({ photoUrl: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  }

  saveProfile(): void {
    if (this.profileForm.invalid) {
      this.profileUpdateStatus.set({ message: 'Please ensure all required fields are filled correctly.', type: 'error'});
      return;
    }
    const success = this.authService.updateUserProfile(this.profileForm.value);
    if (success) {
      this.profileUpdateStatus.set({ message: 'Profile updated successfully!', type: 'success'});
      this.isEditingProfile.set(false);
    } else {
      this.profileUpdateStatus.set({ message: 'Failed to update profile. Please try again.', type: 'error'});
    }
    setTimeout(() => this.profileUpdateStatus.set(null), 3000);
  }
  
  onJobTitleFilterChange(event: Event): void {
    this.jobTitleFilter.set((event.target as HTMLSelectElement).value);
  }

  onCategoryFilterChange(event: Event): void {
    this.categoryFilter.set((event.target as HTMLSelectElement).value);
  }

  onExperienceFilterChange(event: Event): void {
    this.experienceFilter.set((event.target as HTMLSelectElement).value);
  }

  resetFilters(): void {
    this.jobTitleFilter.set('');
    this.categoryFilter.set('');
    this.experienceFilter.set('');
  }
  
  getScoreColorClass(score: number): string {
    if (score >= 8) return 'text-emerald-400';
    if (score >= 5) return 'text-cyan-400';
    return 'text-purple-400';
  }
  
  getScoreGradientClass(score: number): string {
    if (score >= 8) return 'from-emerald-400 to-green-500';
    if (score >= 5) return 'from-cyan-400 to-blue-500';
    return 'from-purple-400 to-indigo-500';
  }
}
