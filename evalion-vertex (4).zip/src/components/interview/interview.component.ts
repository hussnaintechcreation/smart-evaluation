import { ChangeDetectionStrategy, Component, computed, inject, signal, ViewChild, ElementRef, effect, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeminiService, EvaluationResult } from '../../services/gemini.service';
import { InterviewService } from '../../services/interview.service';
import { AuthService } from '../../services/auth.service';

type InterviewState = 'not-started' | 'camera-check' | 'in-progress' | 'evaluating' | 'feedback' | 'completed' | 'error';
type PermissionState = 'prompt' | 'granted' | 'denied';
type RecordingStatus = 'idle' | 'recording' | 'paused';


// This is needed for the SpeechRecognition API typings
declare var webkitSpeechRecognition: any;

// Helper function to convert Data URL to Blob
function dataURLtoBlob(dataurl: string): Blob | null {
  const arr = dataurl.split(',');
  if (arr.length < 2) return null; // Invalid dataurl
  const mimeMatch = arr[0].match(/:(.*?);/);
  if (!mimeMatch) return null;
  const mime = mimeMatch[1];
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new Blob([u8arr], { type: mime });
}

@Component({
  selector: 'app-interview',
  standalone: true,
  templateUrl: './interview.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, FormsModule]
})
export class InterviewComponent implements OnDestroy, OnInit {
  geminiService = inject(GeminiService);
  interviewService = inject(InterviewService);
  authService = inject(AuthService);

  @ViewChild('videoPreview', { static: false }) videoPreview!: ElementRef<HTMLVideoElement>;
  @ViewChild('audioVisualizerCanvas', { static: false }) audioVisualizerCanvas!: ElementRef<HTMLCanvasElement>;

  interviewState = signal<InterviewState>('not-started');
  evaluationResult = signal<EvaluationResult | null>(null);
  currentYear = new Date().getFullYear();
  confettiPieces = signal<any[]>([]);
  
  // --- Evaluation Progress State ---
  evaluationProgressSteps = signal<{text: string, status: 'in-progress' | 'done' | 'pending'}[]>([]);

  // --- Permission State ---
  cameraPermission = signal<PermissionState>('prompt');
  micPermission = signal<PermissionState>('prompt');
  
  // --- Recording State ---
  recordingStatus = signal<RecordingStatus>('idle');
  mediaRecorder: MediaRecorder | null = null;
  recordedBlob = signal<Blob | null>(null);
  recordedUrl = signal<string | null>(null);
  private recordedChunks: Blob[] = [];

  // --- Countdown Timer State ---
  readonly maxRecordingTime = 120; // Max duration in seconds (2 minutes)
  timeRemaining = signal(this.maxRecordingTime);
  private timerInterval: any;
  timesUp = signal(false);

  formattedTimeRemaining = computed(() => {
    const totalSeconds = this.timeRemaining();
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  });

  timerProgress = computed(() => {
    return ((this.maxRecordingTime - this.timeRemaining()) / this.maxRecordingTime) * 100;
  });

  // --- Video Specific State ---
  videoStream = signal<MediaStream | null>(null);
  facingMode = signal<'user' | 'environment'>('user');
  hasMultipleCameras = signal(false);

  // --- Audio Visualization State ---
  audioStream = signal<MediaStream | null>(null);
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private dataArray: Uint8Array | null = null;
  private animationFrameId: number | null = null;

  // --- Speech To Text State ---
  isListening = signal(false);
  private speechRecognition: any | null = null;
  finalTranscript = signal('');
  interimTranscript = signal('');
  userAnswer = computed(() => this.finalTranscript() + this.interimTranscript());

  private questions = computed(() => this.interviewService.getActiveQuestions());

  currentQuestionIndex = signal(0);
  currentQuestion = computed(() => this.questions()[this.currentQuestionIndex()]);
  
  progress = computed(() => {
    const totalQuestions = this.questions().length;
    if (totalQuestions === 0) {
      return 0;
    }
    // Progress should reflect being "on" the current question, so we use +1
    return ((this.currentQuestionIndex() + 1) / totalQuestions) * 100;
  });

  errorMessage = this.geminiService.error;

  showErrorDetails = signal(false);

  errorDetails = computed(() => {
    const msg = this.errorMessage();
    if (!msg) {
        return { reason: 'An unknown error occurred.', suggestion: 'Please try again or restart the interview.', icon: 'unknown' };
    }
    const lowerMsg = msg.toLowerCase();

    // Media Device Errors
    if (lowerMsg.includes('permission') && lowerMsg.includes('denied')) return { reason: 'Media Access Denied.', suggestion: 'Please allow camera and microphone access in your browser settings and reload.', icon: 'cam-denied' };
    if (lowerMsg.includes('not found')) return { reason: 'Device Not Found.', suggestion: 'Please ensure your camera and microphone are connected and not disabled.', icon: 'cam-not-found' };
    if (lowerMsg.includes('in use')) return { reason: 'Device In Use.', suggestion: 'Your camera or microphone is being used by another application. Please close it and try again.', icon: 'cam-in-use' };
    if (lowerMsg.includes('specifications') || lowerMsg.includes('overconstrained')) return { reason: 'Unsupported Device.', suggestion: 'The selected camera does not meet the required specifications (e.g., resolution). Try another device.', icon: 'cam-unsupported' };
    if (lowerMsg.includes('insecure connection')) return { reason: 'Insecure Connection.', suggestion: 'Camera and microphone access requires a secure (HTTPS) connection.', icon: 'insecure' };

    // AI Service Errors
    if (lowerMsg.includes('api key')) return { reason: 'Invalid API Key.', suggestion: 'Please ensure your API key is configured correctly.', icon: 'api-key' };
    if (lowerMsg.includes('network')) return { reason: 'Network Connection Error.', suggestion: 'Please check your internet connection.', icon: 'network' };
    if (lowerMsg.includes('busy')) return { reason: 'AI Service Overloaded.', suggestion: 'Please wait a few moments before retrying.', icon: 'service-busy' };
    if (lowerMsg.includes('500') || lowerMsg.includes('503')) return { reason: 'AI Service Error.', suggestion: 'The AI service is experiencing problems. Try again later.', icon: 'service-error' };
    if (lowerMsg.includes('invalid') || lowerMsg.includes('400') || lowerMsg.includes('too large')) return { reason: 'Invalid Request.', suggestion: 'The video file might be too large. Try a shorter video.', icon: 'invalid-request' };
    
    // Other Errors
    if (lowerMsg.includes('speech recognition')) return { reason: 'Speech Recognition Error.', suggestion: 'There was an issue with speech recognition. Check microphone access.', icon: 'speech-error' };
    
    // Fallback for old error messages (just in case)
    if (lowerMsg.includes('microphone access was denied')) return { reason: 'Microphone Access Denied.', suggestion: 'Please allow microphone access in your browser settings and reload.', icon: 'mic-denied' };
    if (lowerMsg.includes('camera access was denied')) return { reason: 'Camera Access Denied.', suggestion: 'Please allow camera access in your browser settings and reload.', icon: 'cam-denied' };
    
    return { reason: 'An Unexpected Error Occurred.', suggestion: msg, icon: 'unknown' };
  });

  canRetry = computed(() => !['api-key', 'cam-denied', 'cam-not-found', 'cam-unsupported', 'insecure'].includes(this.errorDetails().icon));

  constructor() {
    // Effect for video preview
    effect(() => {
      const stream = this.videoStream();
      if (this.videoPreview?.nativeElement) {
        this.videoPreview.nativeElement.srcObject = stream;
      }
    });
  }
  
  ngOnInit(): void {
    this.setupSpeechRecognition();
    this.startInterview();
  }

  ngOnDestroy(): void {
    this.stopMediaStreams();
    if (this.speechRecognition) {
      this.speechRecognition.stop();
    }
    this.stopAudioVisualization();
  }
  
  private setupSpeechRecognition(): void {
    if ('webkitSpeechRecognition' in window) {
      this.speechRecognition = new webkitSpeechRecognition();
      this.speechRecognition.continuous = true;
      this.speechRecognition.interimResults = true;
      
      this.speechRecognition.onresult = (event: any) => {
        let final = '';
        let interim = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }
        this.finalTranscript.update(val => val + final);
        this.interimTranscript.set(interim);
      };

      this.speechRecognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        if (event.error !== 'no-speech') {
          this.geminiService.error.set(`Speech recognition error: ${event.error}.`);
          this.interviewState.set('error');
        }
        this.isListening.set(false);
      };

      this.speechRecognition.onend = () => this.isListening.set(false);
    } else {
      console.warn('Speech Recognition not supported in this browser.');
    }
  }

  async startInterview(): Promise<void> {
    if (this.questions().length === 0) {
      this.geminiService.error.set("No interview questions available for this session.");
      this.interviewState.set('error');
      return;
    }
    this.currentQuestionIndex.set(0);
    this.evaluationResult.set(null);
    this.discardCurrentAnswer();
    this.geminiService.error.set(null);
    this.showErrorDetails.set(false);
    
    await this.startCameraCheck();
  }
  
  async startCameraCheck(): Promise<void> {
    this.interviewState.set('camera-check');
    const stream = await this.initializeVideoStream(true);
    if (!stream) {
      this.interviewState.set('error');
    }
  }

  confirmCameraReady(): void {
    this.interviewState.set('in-progress');
    this.startRecordingForQuestion();
  }

  private stopMediaStreams() {
    this.videoStream()?.getTracks().forEach(track => track.stop());
    this.videoStream.set(null);
    this.audioStream()?.getTracks().forEach(track => track.stop());
    this.audioStream.set(null);
    clearInterval(this.timerInterval);
    this.stopAudioVisualization();
  }

  discardCurrentAnswer(): void {
    if (this.mediaRecorder?.state !== 'inactive') this.mediaRecorder?.stop();
    if(this.isListening()) this.speechRecognition?.stop();

    this.stopMediaStreams();
    this.timeRemaining.set(this.maxRecordingTime);
    this.timesUp.set(false);
    this.recordingStatus.set('idle');
    this.recordedUrl.set(null);
    this.recordedBlob.set(null);
    this.recordedChunks = [];
    this.facingMode.set('user');
    this.finalTranscript.set('');
    this.interimTranscript.set('');
  }

  private handleMediaError(err: any, type: 'camera' | 'microphone' | 'media') {
    console.error(`Error accessing ${type}:`, err);
    let errorMessage = `Could not access the ${type}.`;
    
    // Set permission state first
    if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        if (type === 'camera' || type === 'media') this.cameraPermission.set('denied');
        if (type === 'microphone' || type === 'media') this.micPermission.set('denied');
    }
    
    // Generate more specific error messages
    switch (err.name) {
        case 'NotAllowedError':
        case 'PermissionDeniedError':
            errorMessage = `Permission to access your ${type} was denied. Please check your browser settings.`;
            break;
        case 'NotFoundError':
            errorMessage = `No ${type} device was found. Please ensure your camera and microphone are connected properly.`;
            break;
        case 'NotReadableError':
            errorMessage = `Your ${type} device is currently in use by another application. Please close other apps and try again.`;
            break;
        case 'OverconstrainedError':
            errorMessage = `No ${type} device was found that meets the required specifications. Please try with a different device.`;
            break;
        case 'SecurityError':
            errorMessage = `Access to your ${type} is not possible from an insecure connection. Please use HTTPS.`;
            break;
        default:
            errorMessage = `An unexpected error occurred while accessing your ${type}: ${err.message || err.name}`;
            break;
    }

    this.geminiService.error.set(errorMessage);
    this.interviewState.set('error');
  }

  private async initializeVideoStream(forCheck: boolean = false): Promise<MediaStream | null> {
    try {
      this.stopMediaStreams();
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: this.facingMode() }, 
        audio: true
      });
      this.videoStream.set(stream);
      this.cameraPermission.set('granted');
      this.micPermission.set('granted');
      if (!forCheck) {
        this.audioStream.set(stream);
        this.setupAudioVisualization(stream);
        this.checkCameraDevices();
      }
      return stream;
    } catch (err: any) {
      this.handleMediaError(err, 'media');
      return null;
    }
  }
  
  async startRecordingForQuestion(): Promise<void> {
    this.discardCurrentAnswer();

    const stream = await this.initializeVideoStream();
    if (!stream) {
      this.interviewState.set('error');
      return;
    }

    this.mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
    this.mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) this.recordedChunks.push(event.data);
    };
    this.mediaRecorder.onstop = () => {
      clearInterval(this.timerInterval);
      const blob = new Blob(this.recordedChunks, { type: 'video/webm' });
      this.recordedBlob.set(blob);
      const url = URL.createObjectURL(blob);
      this.recordedUrl.set(url);
      this.recordingStatus.set('idle');
      this.stopMediaStreams();
      if(this.isListening()) this.speechRecognition.stop();
    };
    this.mediaRecorder.start();
    this.recordingStatus.set('recording');
    
    if (this.speechRecognition) {
      this.speechRecognition.start();
      this.isListening.set(true);
    }

    this.timesUp.set(false);
    this.timeRemaining.set(this.maxRecordingTime);
    this.timerInterval = setInterval(() => {
      this.timeRemaining.update(time => {
        if (time > 1) {
          return time - 1;
        } else {
          this.timesUp.set(true);
          this.stopRecording();
          return 0;
        }
      });
    }, 1000);
  }

  stopRecording(): void {
    if (this.mediaRecorder?.state !== 'inactive') this.mediaRecorder.stop();
    if (this.isListening()) this.speechRecognition.stop();
    this.stopAudioVisualization();
    clearInterval(this.timerInterval);
  }

  togglePauseResume(): void {
    if (!this.mediaRecorder) return;
    if (this.recordingStatus() === 'recording') {
      this.mediaRecorder.pause();
      clearInterval(this.timerInterval);
      if(this.isListening()) this.speechRecognition.stop();
      this.stopAudioVisualization();
      this.recordingStatus.set('paused');
    } else if (this.recordingStatus() === 'paused') {
      this.mediaRecorder.resume();
      this.timerInterval = setInterval(() => {
        this.timeRemaining.update(time => {
          if (time > 1) {
            return time - 1;
          } else {
            this.timesUp.set(true);
            this.stopRecording();
            return 0;
          }
        });
      }, 1000);
      if(this.speechRecognition) this.speechRecognition.start();
      if(this.audioStream()) this.setupAudioVisualization(this.audioStream()!);
      this.recordingStatus.set('recording');
    }
  }
  
  private simulateEvaluationProgress(): void {
      const steps = [
        { text: 'Analyzing audio and transcribing speech...', status: 'in-progress' },
        { text: 'Evaluating response content for relevance...', status: 'pending' },
        { text: 'Assessing presentation and confidence from video...', status: 'pending' },
        { text: 'Compiling detailed feedback report...', status: 'pending' }
      ];
      this.evaluationProgressSteps.set(steps);

      const updateStep = (index: number) => {
        if (index >= steps.length) return;
        
        setTimeout(() => {
          this.evaluationProgressSteps.update(currentSteps => {
            const newSteps = [...currentSteps];
            if (newSteps[index - 1]) newSteps[index - 1].status = 'done';
            if (newSteps[index]) newSteps[index].status = 'in-progress';
            return newSteps;
          });
          updateStep(index + 1);
        }, 1500 + Math.random() * 1000); // Simulate variable delay
      };

      updateStep(1);
  }


  async submitAnswer(): Promise<void> {
    if (this.finalTranscript().trim().length < 10 && !this.recordedBlob()) {
      alert("Please provide a spoken answer (minimum 10 characters).");
      return;
    }
    
    if (this.recordingStatus() !== 'idle') {
      this.stopRecording();
      await new Promise(resolve => setTimeout(resolve, 500)); 
    }

    this.interviewState.set('evaluating');
    this.simulateEvaluationProgress();
    const question = this.currentQuestion();
    if (!question) {
        this.geminiService.error.set("Could not find the current question.");
        this.interviewState.set('error');
        return;
    }

    const result = await this.geminiService.evaluateAnswer(question, { 
      videoBlob: this.recordedBlob()!, 
      text: this.finalTranscript() 
    });

    if (result) {
      this.evaluationResult.set(result);
      if (result.score >= 9) {
        this.triggerConfetti();
      }
      this.interviewState.set('feedback');
      this.interviewService.addResult({
          questionId: question,
          questionText: question,
          evaluation: result,
          userName: this.authService.currentUserName() ?? 'Anonymous',
          jobTitle: this.interviewService.activeTemplate()?.jobTitle ?? 'N/A',
          category: this.interviewService.activeTemplate()?.category ?? 'N/A',
          experienceLevel: this.interviewService.activeTemplate()?.experienceLevel ?? 'N/A',
      });
    } else {
      this.interviewState.set('error');
    }
  }
  
  triggerConfetti(): void {
     const pieces = Array.from({ length: 150 }).map(() => ({
        left: `${Math.random() * 100}%`,
        animationDuration: `${Math.random() * 3 + 2}s`,
        animationDelay: `${Math.random() * 4}s`,
        backgroundColor: ['#22D3EE', '#818CF8', '#A78BFA', '#34D399', '#FBBF24'][Math.floor(Math.random() * 5)],
        transform: `rotate(${Math.random() * 360}deg) scale(${Math.random() * 0.5 + 0.5})`
      }));
      this.confettiPieces.set(pieces);
      setTimeout(() => this.confettiPieces.set([]), 7000);
  }

  async nextQuestion(): Promise<void> {
    this.discardCurrentAnswer();

    if (this.currentQuestionIndex() < this.questions().length - 1) {
      this.currentQuestionIndex.update(i => i + 1);
      this.evaluationResult.set(null);
      this.interviewState.set('in-progress');
      this.geminiService.error.set(null);
      this.showErrorDetails.set(false);
      await this.startRecordingForQuestion();
    } else {
      this.interviewState.set('completed');
    }
  }

  async retryLastQuestion(): Promise<void> {
    this.geminiService.error.set(null);
    this.interviewState.set('in-progress');
    this.showErrorDetails.set(false);
    await this.startRecordingForQuestion();
  }

  getScoreColorClass(score: number): string {
    if (score >= 8) return 'text-emerald-400';
    if (score >= 5) return 'text-cyan-400';
    return 'text-purple-400';
  }

  getScoreGradientClass(score: number): string {
    if (score >= 8) return 'from-emerald-400 to-green-500';
    if (score >= 5) return 'from-cyan-400 to-blue-500';
    return 'from-purple-400 to-indigo-500';
  }

  scoreGradientStartColor = computed(() => {
    const score = this.evaluationResult()?.score ?? 0;
    if (score >= 8) return '#34D399';
    if (score >= 5) return '#22D3EE';
    return '#A78BFA';
  });

  scoreGradientEndColor = computed(() => {
    const score = this.evaluationResult()?.score ?? 0;
    if (score >= 8) return '#10B981';
    if (score >= 5) return '#3B82F6';
    return '#6366F1';
  });

  async toggleCameraFacingMode(): Promise<void> {
    if (this.recordingStatus() !== 'idle' && this.interviewState() !== 'camera-check') return;
    const newFacingMode = this.facingMode() === 'user' ? 'environment' : 'user';
    this.facingMode.set(newFacingMode);
    await this.initializeVideoStream(this.interviewState() === 'camera-check');
  }

  toggleErrorDetails(): void {
    this.showErrorDetails.update(val => !val);
  }

  private async checkCameraDevices(): Promise<void> {
    try {
        if (!navigator.mediaDevices?.enumerateDevices) {
            this.hasMultipleCameras.set(false);
            return;
        }
        const devices = await navigator.mediaDevices.enumerateDevices();
        const videoInputs = devices.filter(device => device.kind === 'videoinput');
        this.hasMultipleCameras.set(videoInputs.length > 1);
    } catch (err) {
        console.error("Error enumerating devices:", err);
        this.hasMultipleCameras.set(false);
    }
  }

  private setupAudioVisualization(stream: MediaStream): void {
    if (!this.audioVisualizerCanvas?.nativeElement) return;
    
    this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    this.analyser = this.audioContext.createAnalyser();
    this.analyser.fftSize = 256;
    this.dataArray = new Uint8Array(this.analyser.frequencyBinCount);

    const source = this.audioContext.createMediaStreamSource(stream);
    source.connect(this.analyser);

    this.drawAudioVisualization();
  }

  private drawAudioVisualization(): void {
    if (!this.analyser || !this.dataArray || !this.audioVisualizerCanvas?.nativeElement) {
      this.animationFrameId = null;
      return;
    }

    const canvas = this.audioVisualizerCanvas.nativeElement;
    const canvasCtx = canvas.getContext('2d');
    if (!canvasCtx) return;

    this.animationFrameId = requestAnimationFrame(() => this.drawAudioVisualization());

    this.analyser.getByteFrequencyData(this.dataArray);

    canvasCtx.clearRect(0, 0, canvas.width, canvas.height);
    canvasCtx.fillStyle = 'rgba(0, 0, 0, 0)';

    const barWidth = (canvas.width / this.analyser.frequencyBinCount) * 2.5;
    let x = 0;

    for (let i = 0; i < this.analyser.frequencyBinCount; i++) {
      const barHeight = this.dataArray[i] / 2;

      const gradient = canvasCtx.createLinearGradient(0, canvas.height, 0, 0);
      gradient.addColorStop(0, '#6A00FF');
      gradient.addColorStop(0.5, '#0057FF');
      gradient.addColorStop(1, '#001F3F');
      canvasCtx.fillStyle = gradient;

      canvasCtx.fillRect(x, canvas.height - barHeight, barWidth, barHeight);

      x += barWidth + 1;
    }
  }

  private stopAudioVisualization(): void {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
    if (this.audioContext?.state !== 'closed') {
      this.audioContext?.close().catch(e => console.error('Error closing audio context:', e));
      this.audioContext = null;
      this.analyser = null;
      this.dataArray = null;
    }
    if (this.audioVisualizerCanvas?.nativeElement) {
      const canvasCtx = this.audioVisualizerCanvas.nativeElement.getContext('2d');
      if (canvasCtx) {
        canvasCtx.clearRect(0, 0, this.audioVisualizerCanvas.nativeElement.width, this.audioVisualizerCanvas.nativeElement.height);
      }
    }
  }
}