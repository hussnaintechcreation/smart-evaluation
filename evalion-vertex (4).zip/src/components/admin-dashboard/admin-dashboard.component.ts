import { ChangeDetectionStrategy, Component, computed, inject, signal, OnInit } from '@angular/core';
import { CommonModule, Location, DatePipe } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService, User, UserRole } from '../../services/auth.service';
import { InterviewService, InterviewTemplate, InterviewResult, InterviewTemplateType } from '../../services/interview.service';
import { GeminiService } from '../../services/gemini.service';
import { ConfirmationDialogComponent } from '../shared/confirmation-dialog.component';
import { ThemeCustomizerComponent } from '../shared/theme-customizer.component';

type AdminDashboardView = 'templates' | 'performance' | 'users' | 'theme-settings';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, DatePipe, ConfirmationDialogComponent, ThemeCustomizerComponent],
  templateUrl: './admin-dashboard.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminDashboardComponent implements OnInit {
  authService = inject(AuthService);
  interviewService = inject(InterviewService);
  geminiService = inject(GeminiService);
  private location = inject(Location);
  private fb: FormBuilder = inject(FormBuilder);
  
  view = signal<AdminDashboardView>('templates');
  currentYear = new Date().getFullYear();

  // --- Role-Based Access ---
  isSuperAdmin = computed(() => this.authService.currentUserRole() === 'super-admin');
  canManageTemplates = computed(() => {
    const role = this.authService.currentUserRole();
    return role === 'super-admin' || role === 'content-manager';
  });
  
  // --- Template Management State ---
  templates = signal<InterviewTemplate[]>([]);
  isGenerating = signal(false);
  generationError = signal<string | null>(null);
  expandedTemplateId = signal<string | null>(null);
  templateToDelete = signal<InterviewTemplate | null>(null);
  showLogoutConfirm = signal(false);

  templateForm = this.fb.group({
    jobTitle: ['', Validators.required],
    category: ['Software Engineering', Validators.required],
    experienceLevel: ['Senior', Validators.required],
    questionCount: [5, [Validators.required, Validators.min(1), Validators.max(10)]],
    type: ['technical' as InterviewTemplateType, Validators.required]
  });

  // --- Performance View State ---
  allResults = signal<InterviewResult[]>([]);
  expandedResultId = signal<string | null>(null);

  // Filters for performance view
  jobTitleFilter = signal<string>('');
  categoryFilter = signal<string>('');
  experienceFilter = signal<string>('');
  dateRangeFilter = signal<{ start: string | null, end: string | null }>({ start: null, end: null });
  feedbackKeywordFilter = signal<string>('');

  // Computed filtered results
  filteredResults = computed(() => {
    const results = this.allResults();
    const jobTitle = this.jobTitleFilter().toLowerCase();
    const category = this.categoryFilter().toLowerCase();
    const experience = this.experienceFilter().toLowerCase();
    const keyword = this.feedbackKeywordFilter().toLowerCase();
    const startDate = this.dateRangeFilter().start ? new Date(this.dateRangeFilter().start) : null;
    const endDate = this.dateRangeFilter().end ? new Date(this.dateRangeFilter().end) : null;
    if(endDate) endDate.setHours(23, 59, 59, 999); // Include the entire end day

    return results.filter(result => {
      const resultDate = new Date(result.answeredOn);
      const matchesJobTitle = !jobTitle || result.jobTitle.toLowerCase().includes(jobTitle);
      const matchesCategory = !category || result.category.toLowerCase().includes(category);
      const matchesExperience = !experience || result.experienceLevel.toLowerCase().includes(experience);
      const matchesKeyword = !keyword || result.evaluation.feedback.toLowerCase().includes(keyword);
      const matchesDateRange = 
        (!startDate || resultDate >= startDate) &&
        (!endDate || resultDate <= endDate);

      return matchesJobTitle && matchesCategory && matchesExperience && matchesDateRange && matchesKeyword;
    });
  });
  
  // --- Analytics for filtered results ---
  filteredTotalSubmissions = computed(() => this.filteredResults().length);
  filteredAverageScore = computed(() => {
    const results = this.filteredResults();
    if (results.length === 0) return 0;
    const total = results.reduce((sum, r) => sum + r.evaluation.score, 0);
    return total / results.length;
  });

  // --- User Management State ---
  allUsers = signal<User[]>([]);
  userToToggleStatus = signal<User | null>(null); // For confirmation dialog
  showUserStatusConfirm = signal(false);
  availableRoles: UserRole[] = ['candidate', 'content-manager', 'super-admin'];

  ngOnInit(): void {
    this.templates.set(this.interviewService.getInterviewTemplates());
    this.allResults.set(this.interviewService.getResults());
    this.allUsers.set(this.authService.getAllUsers()); // Fetch all users
  }

  handleLogout(confirmed: boolean): void {
    if (confirmed) {
      this.authService.logout();
    }
    this.showLogoutConfirm.set(false);
  }
  
  setView(newView: AdminDashboardView): void {
    this.view.set(newView);
    // Reset filters when changing views
    if (newView !== 'performance') {
      this.jobTitleFilter.set('');
      this.categoryFilter.set('');
      this.experienceFilter.set('');
      this.dateRangeFilter.set({ start: null, end: null });
    }
  }

  async generateAndSaveTemplate(): Promise<void> {
    if (this.templateForm.invalid) {
      this.templateForm.markAllAsTouched();
      return;
    }
    
    this.isGenerating.set(true);
    this.generationError.set(null);
    const { jobTitle, category, experienceLevel, questionCount, type } = this.templateForm.value;

    const questions = await this.geminiService.generateInterviewQuestions(
      jobTitle!, category!, experienceLevel!, questionCount!
    );

    if (questions) {
      this.interviewService.addInterviewTemplate({
        jobTitle: jobTitle!,
        category: category!,
        experienceLevel: experienceLevel!,
        questions: questions,
        type: type!
      });
      this.templates.set(this.interviewService.getInterviewTemplates());
      this.templateForm.reset({ category: 'Software Engineering', experienceLevel: 'Senior', questionCount: 5, type: 'technical' });
    } else {
      this.generationError.set(this.geminiService.error() || 'An unknown error occurred during question generation.');
    }
    
    this.isGenerating.set(false);
  }

  confirmDeleteTemplate(template: InterviewTemplate): void {
    this.templateToDelete.set(template);
  }
  
  handleDelete(confirmed: boolean): void {
    if (confirmed && this.templateToDelete()) {
      this.interviewService.deleteInterviewTemplate(this.templateToDelete()!.id);
      this.templates.set(this.interviewService.getInterviewTemplates());
    }
    this.templateToDelete.set(null);
  }
  
  toggleTemplateExpansion(templateId: string): void {
    this.expandedTemplateId.update(current => (current === templateId ? null : templateId));
  }
  
  toggleResultExpansion(result: InterviewResult): void {
    const resultId = result.questionId + result.answeredOn;
    this.expandedResultId.update(current => (current === resultId ? null : resultId));
  }

  // --- User Management Methods ---
  confirmToggleUserStatus(user: User): void {
    this.userToToggleStatus.set(user);
    this.showUserStatusConfirm.set(true);
  }

  handleToggleUserStatus(confirmed: boolean): void {
    if (confirmed && this.userToToggleStatus()) {
      this.authService.toggleUserStatus(this.userToToggleStatus()!.id);
      this.allUsers.set(this.authService.getAllUsers()); // Refresh user list
    }
    this.userToToggleStatus.set(null);
    this.showUserStatusConfirm.set(false);
  }

  changeUserRole(userId: string, event: Event): void {
    const newRole = (event.target as HTMLSelectElement).value as UserRole;
    if (this.authService.updateUserRole(userId, newRole)) {
      this.allUsers.set(this.authService.getAllUsers()); // Refresh user list
    } else {
      // This will happen if a super admin tries to change their own role.
      // Revert the dropdown in the UI by refreshing the user list.
      alert("Role could not be changed. Super Admins cannot change their own role.");
      this.allUsers.set(this.authService.getAllUsers());
    }
  }

  // --- Filter Methods for Performance View ---
  onFilterChange(event: Event, filterSignal: (value: string) => void): void {
    filterSignal((event.target as HTMLInputElement).value);
  }

  onStartDateChange(event: Event): void {
    this.dateRangeFilter.update(val => ({ ...val, start: (event.target as HTMLInputElement).value }));
  }

  onEndDateChange(event: Event): void {
    this.dateRangeFilter.update(val => ({ ...val, end: (event.target as HTMLInputElement).value }));
  }
  
  // --- Styling Helpers ---
  getScoreColorClass(score: number): string {
    if (score >= 8) return 'text-emerald-400';
    if (score >= 5) return 'text-cyan-400';
    return 'text-purple-400';
  }
  
  getScoreGradientClass(score: number): string {
    if (score >= 8) return 'from-emerald-400 to-green-500';
    if (score >= 5) return 'from-cyan-400 to-blue-500';
    return 'from-purple-400 to-indigo-500';
  }
}
