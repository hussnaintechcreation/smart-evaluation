import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { DashboardLayout } from '../components/common/DashboardLayout';
import type { Interview, InterviewResult } from '../types';
import { AIAnalysisPanel } from '../components/AIAnalysisPanel';
import { ArrowLeft, MessageSquare, Video, CheckCircle, Download } from 'lucide-react';
import { Button } from '../components/common/Button';
import { useTheme } from '../contexts/ThemeContext';
import { Skeleton } from '../components/common/Skeleton';
import ErrorBoundary from '../components/common/ErrorBoundary';

interface InterviewResultPageProps {
  userName: string;
  userRole: 'admin' | 'candidate';
  onLogout: () => void;
}

const InterviewResultPage: React.FC<InterviewResultPageProps> = ({ userName, userRole, onLogout }) => {
  const { interviewId } = useParams();
  const [interview, setInterview] = useState<Interview | null>(null);
  const [result, setResult] = useState<InterviewResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [isApproved, setIsApproved] = useState(false);
  const { theme } = useTheme();

  useEffect(() => {
    const timer = setTimeout(() => {
        try {
          const savedInterviews = localStorage.getItem('htc-interviews');
          if (savedInterviews) {
            const interviews: Interview[] = JSON.parse(savedInterviews);
            const currentInterview = interviews.find(i => i.id.toString() === interviewId);
            setInterview(currentInterview || null);
          }
    
          const savedResult = localStorage.getItem(`htc-interview-result-${interviewId}`);
          if (savedResult) {
            const parsedResult = JSON.parse(savedResult) as InterviewResult;
            setResult(parsedResult);
            setIsApproved(parsedResult.status === 'approved');
          }
        } catch (e) {
          console.error("Failed to load interview data from localStorage", e);
        } finally {
          setLoading(false);
        }
    }, 500); // Simulate network delay
    return () => clearTimeout(timer);
  }, [interviewId]);

  const handleApprove = () => {
    if (result) {
        try {
            const updatedResult = { ...result, status: 'approved' as const };
            localStorage.setItem(`htc-interview-result-${interviewId}`, JSON.stringify(updatedResult));
            setResult(updatedResult);
            setIsApproved(true);
        } catch (e) {
            console.error("Failed to approve result:", e);
            alert("Could not save the approval status. Your browser's storage might be full or disabled.");
        }
    }
  };

  if (loading) {
    return (
        <DashboardLayout userName={userName} userRole={userRole} onLogout={onLogout} title="Loading Results...">
            <div className="mb-6 flex justify-between items-center">
                <Skeleton className="w-48 h-10 rounded-lg" />
                {userRole === 'candidate' && <Skeleton className="w-48 h-10 rounded-lg" />}
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-1">
                    <div className={`${theme.cardBgClass} p-8 rounded-2xl border ${theme.borderColorClass} sticky top-8`}>
                        <div className="space-y-6">
                            <Skeleton className="w-3/4 h-8 mx-auto mb-6" />
                            <div className="text-center mb-4">
                                <Skeleton className="w-24 h-6 mx-auto mb-2" />
                                <Skeleton className="w-32 h-12 mx-auto my-2" />
                                <Skeleton className="w-full h-4" />
                                <Skeleton className="w-5/6 h-4 mt-1 mx-auto" />
                            </div>
                            
                            <hr className="border-t-0 bg-gradient-to-r from-transparent via-cyan-500/30 to-transparent h-[1px] my-4" />
                            
                            <div>
                                <Skeleton className="w-1/4 h-4 mb-4" />
                                <Skeleton className="w-full h-3 mb-2" />
                                <Skeleton className="w-full h-3 mb-2" />
                                <Skeleton className="w-3/4 h-3" />
                            </div>

                            {[...Array(3)].map((_, i) => (
                                <div key={i}>
                                    <div className="flex items-center gap-2 mb-3">
                                        <Skeleton className="w-5 h-5 rounded-md" />
                                        <Skeleton className="w-1/3 h-4" />
                                    </div>
                                    <div className="space-y-2">
                                        <div className="flex items-start gap-3 ml-3"><Skeleton className="w-2 h-2 rounded-full mt-1 flex-shrink-0" /><Skeleton className="w-5/6 h-3" /></div>
                                        <div className="flex items-start gap-3 ml-3"><Skeleton className="w-2 h-2 rounded-full mt-1 flex-shrink-0" /><Skeleton className="w-full h-3" /></div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
                <div className="lg:col-span-2 space-y-6">
                    {[...Array(2)].map((_, index) => (
                        <div key={index} className={`${theme.cardBgClass} p-6 rounded-xl border ${theme.borderColorClass}`}>
                            <Skeleton className="w-24 h-4 mb-1" />
                            <Skeleton className="w-full h-5 mb-4" />
                            <Skeleton className="w-full aspect-video rounded-lg mb-4" />
                            <Skeleton className="w-32 h-4 mb-2" />
                            <Skeleton className="w-full h-12 rounded-lg" />
                        </div>
                    ))}
                </div>
            </div>
        </DashboardLayout>
    );
  }

  if (!interview || !result) {
    return (
      <DashboardLayout userName={userName} userRole={userRole} onLogout={onLogout} title="Error">
        <div className="text-center">
          <p className="text-xl text-red-500">Interview results not found.</p>
          <Link to={userRole === 'admin' ? '/admin' : '/candidate'}>
            <Button className="mt-4">
              <ArrowLeft className="mr-2" size={16} /> Back to Dashboard
            </Button>
          </Link>
        </div>
      </DashboardLayout>
    );
  }

  // Candidate access check
  if (userRole === 'candidate' && result.status !== 'approved') {
     return (
      <DashboardLayout userName={userName} userRole={userRole} onLogout={onLogout} title="Result Pending">
        <div className="text-center">
          <p className="text-xl">Your interview result is currently under review.</p>
           <p className="text-gray-400">Please check back later.</p>
          <Link to="/candidate">
            <Button className="mt-4">
              <ArrowLeft className="mr-2" size={16} /> Back to Dashboard
            </Button>
          </Link>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout userName={userName} userRole={userRole} onLogout={onLogout} title={`Results: ${interview.title}`}>
      <ErrorBoundary>
        <>
          <div className="mb-6 flex justify-between items-center">
              <Link to={userRole === 'admin' ? '/admin' : '/candidate'}>
                  <Button variant="secondary">
                  <ArrowLeft className="mr-2" size={16} /> Back to Dashboard
                  </Button>
              </Link>
              {isApproved && (
                   <Link to={`/certificate/${interview.id}`} target="_blank">
                      <Button>
                          <Download className="mr-2" size={16} /> Download Certificate
                      </Button>
                  </Link>
              )}
          </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              className="sticky top-8"
            >
              <AIAnalysisPanel analysis={result.analysis} isAnalyzing={false} onClose={() => {}} />
              {userRole === 'admin' && !isApproved && (
                  <Button onClick={handleApprove} className="w-full mt-4">
                      <CheckCircle className="mr-2" size={16} /> Approve Result
                  </Button>
              )}
            </motion.div>
          </div>
          <div className="lg:col-span-2 space-y-6">
              {interview.questions.map((question, index) => (
                  <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      className={`${theme.cardBgClass} p-6 rounded-xl border ${theme.borderColorClass}`}
                  >
                      <p className={`text-sm text-cyan-500 dark:text-cyan-400 font-semibold`} style={{color: theme.gradientFromHex}}>Question {index + 1}</p>
                      <h3 className={`font-bold text-lg mb-4 ${theme.textColorClass}`}>{question}</h3>
                      
                      {result.answers[index] ? (
                          <div className="space-y-4">
                              <div>
                                  <h4 className={`flex items-center gap-2 text-sm font-semibold text-gray-500 dark:text-gray-400 mb-2`}>
                                      <Video size={16} /> Candidate's Video Response
                                  </h4>
                                  {result.answers[index].videoBase64 ? (
                                      <video
                                          controls
                                          src={`data:video/webm;base64,${result.answers[index].videoBase64}`}
                                          className="w-full rounded-lg bg-black"
                                      />
                                  ) : (
                                      <div className="w-full aspect-video bg-black rounded-lg flex items-center justify-center">
                                          <p className="text-gray-500">No video recorded.</p>
                                      </div>
                                  )}
                              </div>
                               <div>
                                  <h4 className="flex items-center gap-2 text-sm font-semibold text-gray-500 dark:text-gray-400 mb-2">
                                      <MessageSquare size={16} /> AI Transcript
                                  </h4>
                                  <div className={`p-3 ${theme.isDark ? 'bg-gray-800/60' : 'bg-slate-200/60'} rounded-lg`}>
                                      <p className={`${theme.textColorClass} whitespace-pre-wrap`}>{result.answers[index].transcript || '(No transcript available)'}</p>
                                  </div>
                              </div>
                          </div>
                      ) : (
                          <p className="text-gray-500">No answer recorded for this question.</p>
                      )}
                  </motion.div>
              ))}
          </div>
        </div>
        </>
      </ErrorBoundary>
    </DashboardLayout>
  );
};

export default InterviewResultPage;
