import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, StopCircle, Maximize, Minimize, X, Check, ArrowRight, ArrowLeft, Play } from 'lucide-react';
import { getGenAIClient } from './utils/gemini';
import type { Interview, InterviewResult, RecordedAnswer, AIAnalysisData } from '../types';
import { LiveServerMessage } from '@google/genai';
import { Button } from '../components/common/Button';
import { SmartEvaluationIcon } from '../components/common/SmartEvaluationIcon';
import { encode, blobToBase64, decode } from './utils/audio';
import { InstructionModal } from '../components/common/InstructionModal';
import { useTheme } from '../contexts/ThemeContext';
import ErrorBoundary from '../components/common/ErrorBoundary';
import { Skeleton } from '../components/common/Skeleton';

// Define the structure for the blob sent to Gemini API
interface GeminiBlob {
  data: string;
  mimeType: string;
}

interface InterviewProgress {
    qIndex: number;
    savedAnswers: Record<number, string>;
    savedVideoRecordings: Record<number, string>; // Storing base64 strings
}

// A minimal layout for the focused interview experience
const InterviewLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { theme } = useTheme();
    return (
        <div className={`min-h-screen ${theme.primaryBgClass} ${theme.textColorClass} flex flex-col items-center p-4 md:p-8`}>
            <header className="w-full max-w-5xl mb-6">
                <SmartEvaluationIcon />
            </header>
            <main className="w-full max-w-5xl flex-1">{children}</main>
        </div>
    );
};

const QUESTION_TIME_LIMIT = 180; // 3 minutes

const InterviewPage: React.FC = () => {
    const { interviewId } = useParams();
    const navigate = useNavigate();
    
    // Core state
    const [interview, setInterview] = useState<Interview | null>(null);
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [answers, setAnswers] = useState<Record<number, string>>({});
    const [videoRecordings, setVideoRecordings] = useState<Record<number, Blob>>({});
    
    // UI/Control State
    const [loading, setLoading] = useState(true);
    const [isListening, setIsListening] = useState(false);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [analysisResult, setAnalysisResult] = useState<AIAnalysisData | null>(null);
    const [error, setError] = useState('');
    const [timeLeft, setTimeLeft] = useState(QUESTION_TIME_LIMIT);
    const [isTimerActive, setIsTimerActive] = useState(false);
    const [isPlaying, setIsPlaying] = useState(false);
    const [isFullscreen, setIsFullscreen] = useState(false);
    const [isInstructionModalOpen, setIsInstructionModalOpen] = useState(false);
    const [showFinishedScreen, setShowFinishedScreen] = useState(false);
    const [user, setUser] = useState<{name: string} | null>(null);
    const { theme } = useTheme();


    // Media and API Refs
    const liveVideoRef = useRef<HTMLVideoElement>(null);
    const playbackVideoRef = useRef<HTMLVideoElement>(null);
    const videoContainerRef = useRef<HTMLDivElement>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const sessionPromiseRef = useRef<Promise<any> | null>(null);
    const inputAudioContextRef = useRef<AudioContext | null>(null);
    const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
    const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const recordedVideoChunks = useRef<Blob[]>([]);
    const timerIntervalRef = useRef<number | null>(null);
    const currentTranscriptionRef = useRef<string>(''); // Holds full transcript for current question
    const transcriptDisplayRef = useRef<HTMLDivElement>(null);

    // Initialization: Load interview data and any saved progress from localStorage
    useEffect(() => {
        setLoading(true);
        const timer = setTimeout(() => { // Simulate async loading
            try {
                const savedUser = localStorage.getItem('htc-user');
                if (savedUser) setUser(JSON.parse(savedUser) as { name: string });
                
                const savedInterviews = localStorage.getItem('htc-interviews');
                const interviews: Interview[] = savedInterviews ? JSON.parse(savedInterviews) : [];
                const currentInterview = interviews.find(i => i.id.toString() === interviewId);
                if (currentInterview) {
                    setInterview(currentInterview);
                    const instructionsSeen = localStorage.getItem(`htc-instructions-seen-${interviewId}`);
                    if (!instructionsSeen) {
                        setIsInstructionModalOpen(true);
                    }
                    // Check for saved progress
                    const savedProgress = localStorage.getItem(`htc-interview-progress-${interviewId}`);
                    if (savedProgress) {
                        const { qIndex, savedAnswers, savedVideoRecordings } = JSON.parse(savedProgress) as InterviewProgress;
                        setCurrentQuestionIndex(qIndex);
                        setAnswers(savedAnswers);
                        
                        // Load video recordings by converting base64 back to Blobs
                        if (savedVideoRecordings) {
                            const loadedVideoRecordings: Record<number, Blob> = {};
                            Object.keys(savedVideoRecordings).forEach(key => {
                                const base64String = savedVideoRecordings[key as any];
                                if (base64String) {
                                    const mimeType = 'video/webm'; // Assuming constant mimeType
                                    const decodedBytes = decode(base64String);
                                    loadedVideoRecordings[key as any] = new Blob([decodedBytes], { type: mimeType });
                                }
                            });
                            setVideoRecordings(loadedVideoRecordings);
                        }
                    }
                } else {
                    setError("Interview not found.");
                }
            } catch (e) {
                setError("Failed to load interview. The data may be corrupted.");
                console.error(e);
            } finally {
                setLoading(false);
            }
        }, 500);

        return () => clearTimeout(timer);
    }, [interviewId]);

    // Progress saving: Save current state to localStorage whenever it changes
    useEffect(() => {
        if (!interview) return;

        const saveProgress = async () => {
            // Asynchronously convert all video blobs to base64
            const savedVideoRecordings: Record<number, string> = {};
            const videoPromises = Object.keys(videoRecordings).map(async (key) => {
                const numericKey = parseInt(key, 10);
                const blob = videoRecordings[numericKey];
                if (blob) {
                    savedVideoRecordings[numericKey] = await blobToBase64(blob);
                }
            });
    
            await Promise.all(videoPromises);
    
            const progress: InterviewProgress = {
                qIndex: currentQuestionIndex,
                savedAnswers: answers,
                savedVideoRecordings,
            };
            
            try {
                localStorage.setItem(`htc-interview-progress-${interview.id}`, JSON.stringify(progress));
            } catch (e) {
                console.error("Failed to save progress to localStorage. It might be full.", e);
                setError("Could not save interview progress. Your browser storage might be full.");
            }
        };
    
        saveProgress();

    }, [currentQuestionIndex, answers, videoRecordings, interview]);

    // Timer logic
    useEffect(() => {
        if (isTimerActive) {
            timerIntervalRef.current = window.setInterval(() => {
                setTimeLeft(prev => {
                    if (prev <= 1) {
                        handleStopListening(); // Automatically stop when timer hits 0
                        return 0;
                    }
                    return prev - 1;
                });
            }, 1000);
        } else if (timerIntervalRef.current) {
            clearInterval(timerIntervalRef.current);
        }
        return () => {
            if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
        };
    }, [isTimerActive]);

    // Auto-scroll transcript display
    useEffect(() => {
        if (transcriptDisplayRef.current) {
            transcriptDisplayRef.current.scrollTop = transcriptDisplayRef.current.scrollHeight;
        }
    }, [answers[currentQuestionIndex]]);

    const formatTime = (seconds: number) => {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
    };
    
    const startDevices = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
            streamRef.current = stream;
            if (liveVideoRef.current) {
                liveVideoRef.current.srcObject = stream;
                liveVideoRef.current.play(); // Start playing stream in local video element
            }
            return stream;
        } catch (err) {
            setError("Microphone/Camera access denied. Please allow permissions in your browser settings.");
            console.error(err);
            return null;
        }
    };
    
    const handleStartListening = async () => {
        setError('');
        const stream = await startDevices();
        if (!stream) return;
        
        // Start Video Recording
        recordedVideoChunks.current = [];
        mediaRecorderRef.current = new MediaRecorder(stream, { mimeType: 'video/webm' });
        mediaRecorderRef.current.ondataavailable = (event) => {
            if (event.data.size > 0) recordedVideoChunks.current.push(event.data);
        };
        mediaRecorderRef.current.start();
        
        // Start Gemini Live Transcription
        const ai = getGenAIClient();
        inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
        
        sessionPromiseRef.current = ai.live.connect({
            model: 'gemini-2.5-flash-native-audio-preview-09-2025',
            callbacks: {
                onopen: () => {
                    mediaStreamSourceRef.current = inputAudioContextRef.current!.createMediaStreamSource(stream);
                    scriptProcessorRef.current = inputAudioContextRef.current!.createScriptProcessor(4096, 1, 1);
                    
                    scriptProcessorRef.current.onaudioprocess = (event) => {
                        const inputData = event.inputBuffer.getChannelData(0);
                        const l = inputData.length;
                        const int16 = new Int16Array(l);
                        for (let i = 0; i < l; i++) {
                            int16[i] = inputData[i] * 32768;
                        }
                        const pcmBlob: GeminiBlob = { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' };
                        
                        sessionPromiseRef.current?.then((session) => session.sendRealtimeInput({ media: pcmBlob }));
                    };
                    
                    mediaStreamSourceRef.current.connect(scriptProcessorRef.current);
                    scriptProcessorRef.current.connect(inputAudioContextRef.current.destination);
                },
                onmessage: (message: LiveServerMessage) => {
                    const newChunk = message.serverContent?.inputTranscription?.text;
                    if (newChunk) {
                        currentTranscriptionRef.current += newChunk; // Update the full transcript for current question
                        
                        // Update the 'answers' state with the growing transcript for persistence
                        setAnswers(prev => ({
                            ...prev,
                            [currentQuestionIndex]: currentTranscriptionRef.current
                        }));
                    }
                },
                onerror: (e: ErrorEvent) => {
                    setError("Real-time connection error. Please stop and try answering again.");
                    console.error('Gemini Live error:', e);
                    handleStopListening(); // Attempt to clean up resources
                },
                onclose: (e: CloseEvent) => { /* console.log('closed'); */ }
            },
            config: { inputAudioTranscription: {} }
        });
        
        setIsListening(true);
        setIsTimerActive(true);
        setTimeLeft(QUESTION_TIME_LIMIT);
        currentTranscriptionRef.current = ''; // Reset transcript for a new recording take
        setAnswers(prev => ({ ...prev, [currentQuestionIndex]: '' })); // Clear the persisted answer for this question
    };
    
    const handleStopListening = async () => {
        if (!isListening) return; // Prevent multiple stops

        setIsListening(false);
        setIsTimerActive(false);

        // Stop video recording
        if (mediaRecorderRef.current?.state === 'recording') {
            mediaRecorderRef.current?.stop();
        }
        const videoBlob = new Blob(recordedVideoChunks.current, { type: 'video/webm' });
        if(videoBlob.size > 0) {
            setVideoRecordings(prev => ({ ...prev, [currentQuestionIndex]: videoBlob }));
        }

        // Stop Gemini Live
        if (mediaStreamSourceRef.current && scriptProcessorRef.current) {
            mediaStreamSourceRef.current.disconnect();
            scriptProcessorRef.current.disconnect();
        }
        inputAudioContextRef.current?.close();
        sessionPromiseRef.current?.then(session => session.close()).catch(e => console.error("Error closing Gemini Live session", e));

        // Stop media stream tracks
        streamRef.current?.getTracks().forEach(track => track.stop());
        streamRef.current = null;
        if (liveVideoRef.current) liveVideoRef.current.srcObject = null;
    };

    const analyzeInterview = async (): Promise<boolean> => {
        setIsAnalyzing(true);
        setError('');
        const recordedAnswers: Record<number, RecordedAnswer> = {};

        try {
            if (isListening) await handleStopListening();

            for (const indexStr of Object.keys(answers)) {
                const index = parseInt(indexStr, 10);
                const videoBlob = videoRecordings[index];
                let videoBase64 = '';
                if (videoBlob) {
                  videoBase64 = await blobToBase64(videoBlob);
                }
                recordedAnswers[index] = {
                    transcript: answers[index] || '',
                    videoBase64: videoBase64,
                };
            }
        
            const ai = getGenAIClient();
            const analysisPrompt = `
                You are an expert technical interviewer and communication coach. Your task is to perform a comprehensive, multimodal analysis of a candidate's interview responses for a "${interview?.title}" position. For each question, you are given both the audio transcript and the video recording of the candidate's answer.

                **CRITICAL INSTRUCTIONS:**
                1.  **Multimodal Analysis:** Your evaluation MUST be based on BOTH the verbal content (from the transcript) and the non-verbal cues (from the video).
                2.  **Analyze Visual Cues:** Pay close attention to visual elements in the video such as:
                    *   **Body Language:** Posture, gestures, fidgeting.
                    *   **Confidence:** Tone of voice (inferred), speaking pace, and demeanor.
                    *   **Eye Contact:** Engagement with the camera.
                    *   **Presentation Style:** Overall professionalism and clarity.
                3.  **Integrate Feedback:** Explicitly integrate your observations of these visual cues into the 'summary' and 'overallFeedback' sections. For example, mention if the candidate appeared confident, maintained good eye contact, or seemed nervous.

                **OUTPUT FORMAT:**
                Your response must be a single, valid JSON object and nothing else. Do not include any text, markdown formatting like \`\`\`json, or explanations before or after the JSON object. The JSON object must strictly adhere to the following schema:

                {
                    "summary": "A concise overall summary of the candidate's performance, integrating both verbal content and non-verbal feedback from the video.",
                    "strengths": ["A list of key strengths. Include both technical skills (e.g., 'Strong technical knowledge in X') and presentation skills (e.g., 'Confident posture and clear articulation')."],
                    "improvements": ["A list of areas for improvement. Include both technical gaps (e.g., 'Could provide more specific examples') and non-verbal issues (e.g., 'Frequently looked away from the camera', 'Appeared hesitant')."],
                    "actionableNextSteps": ["A list of concrete, actionable steps. Include technical practice and advice for on-camera presence, e.g., 'Record and review practice answers to improve on-camera presence.'"],
                    "overallScore": "A numerical score from 1 to 10 evaluating the overall performance, considering all factors.",
                    "overallFeedback": "A brief paragraph justifying the score. This section MUST explicitly comment on the candidate's presentation style, body language, and confidence as observed in the video, in addition to their technical answers."
                }
            `;

            const contentsPayload: any[] = [{ text: analysisPrompt }];

            interview?.questions.forEach((q, i) => {
                contentsPayload.push({ text: `--- Question ${i + 1}: ${q} ---` });
                const answer = recordedAnswers[i];
                if (answer) {
                    contentsPayload.push({ text: `Transcript: ${answer.transcript || '(No transcript provided)'}` });
                    if (answer.videoBase64) {
                        contentsPayload.push({
                            inlineData: {
                                mimeType: 'video/webm',
                                data: answer.videoBase64,
                            }
                        });
                    }
                } else {
                    contentsPayload.push({ text: 'Answer: (No answer provided)' });
                }
            });

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: contentsPayload,
                config: { responseMimeType: 'application/json' },
            });
            
            // The AI's response might not be perfect JSON. We must clean it.
            let jsonText = response.text.trim();
            // Handle cases where the model wraps the JSON in markdown code blocks
            if (jsonText.startsWith('```json')) {
                jsonText = jsonText.substring(7, jsonText.length - 3).trim();
            }

            const analysisData: AIAnalysisData = JSON.parse(jsonText);
            setAnalysisResult(analysisData);

            const finalResult: InterviewResult = {
                interviewId: interview!.id,
                candidateName: user!.name,
                analysis: analysisData,
                answers: recordedAnswers,
                status: 'pending',
            };
            
            // Critical: wrap storage in try-catch
            try {
                localStorage.setItem(`htc-interview-result-${interview!.id}`, JSON.stringify(finalResult));
                // Clean up progress since interview is now complete
                localStorage.removeItem(`htc-interview-progress-${interview!.id}`);
                localStorage.removeItem(`htc-instructions-seen-${interview!.id}`);
            } catch(e) {
                console.error("Failed to save final interview result:", e);
                // Set an error message that the user can see, and don't return success
                setError("Your results were analyzed, but we couldn't save them. Your browser storage might be full.");
                return false;
            }
            
            return true; // Success

        } catch (e) {
            console.error("Error analyzing interview:", e);
            let errorMessage = "Analysis failed. The AI could not process the responses.";
            if (e instanceof SyntaxError) {
                errorMessage = "Analysis failed: The AI returned an invalid format. Please try again.";
            } else if (e instanceof Error && e.message.includes('API_KEY')) {
                 errorMessage = "Analysis failed: API Key is invalid or missing.";
            }
            setError(errorMessage + " Please contact support if the problem persists.");
            return false; // Failure
        } finally {
            setIsAnalyzing(false);
        }
    };

    const handleNextQuestion = () => {
        if (!interview || currentQuestionIndex >= interview.questions.length - 1) return;
        setCurrentQuestionIndex(prev => prev + 1);
        setTimeLeft(QUESTION_TIME_LIMIT);
    };

    const handlePrevQuestion = () => {
        if (currentQuestionIndex <= 0) return;
        setCurrentQuestionIndex(prev => prev + 1);
        setTimeLeft(QUESTION_TIME_LIMIT);
    };

    const handleFinishInterview = async () => {
        const success = await analyzeInterview();
        if (success) {
            setShowFinishedScreen(true);
        }
    };
    
    const toggleFullscreen = () => {
        if (!document.fullscreenElement) {
            videoContainerRef.current?.requestFullscreen().catch(err => {
                alert(`Error attempting to enable full-screen mode: ${err.message} (${err.name})`);
            });
        } else {
            document.exitFullscreen();
        }
    };
    
    useEffect(() => {
        const onFullscreenChange = () => setIsFullscreen(!!document.fullscreenElement);
        document.addEventListener('fullscreenchange', onFullscreenChange);
        return () => document.removeEventListener('fullscreenchange', onFullscreenChange);
    }, []);
    
    // Playback logic
    const handlePlayRecording = () => {
        if (playbackVideoRef.current && videoRecordings[currentQuestionIndex]) {
            const videoBlob = videoRecordings[currentQuestionIndex];
            const videoUrl = URL.createObjectURL(videoBlob);
            playbackVideoRef.current.src = videoUrl;
            playbackVideoRef.current.play();
            setIsPlaying(true);
        }
    };
    
    useEffect(() => {
        const videoElement = playbackVideoRef.current;
        const handleVideoEnd = () => setIsPlaying(false);
        videoElement?.addEventListener('ended', handleVideoEnd);
        return () => videoElement?.removeEventListener('ended', handleVideoEnd);
    }, []);


    if (loading) {
        return (
            <InterviewLayout>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-full">
                    {/* Left Panel Skeleton */}
                    <div className={`relative flex flex-col ${theme.isDark ? 'bg-black' : 'bg-slate-300'} rounded-2xl p-4`}>
                        <Skeleton className="w-full aspect-video rounded-lg flex-1" />
                        <div className="flex items-center justify-center gap-4 mt-4">
                            <Skeleton className="w-40 h-12 rounded-lg" />
                        </div>
                    </div>
                    {/* Right Panel Skeleton */}
                    <div className={`relative ${theme.cardBgClass} rounded-2xl p-6 flex flex-col border ${theme.borderColorClass}`}>
                        <div className="flex justify-between items-center mb-4">
                            <Skeleton className="w-32 h-8 rounded-full" />
                            <Skeleton className="w-24 h-8 rounded-full" />
                        </div>
                        <Skeleton className="w-3/4 h-6 mb-2" />
                        <Skeleton className="w-1/2 h-6 mb-4" />
                        <Skeleton className="flex-1 rounded-lg min-h-[200px]" />
                        <div className="flex justify-between items-center mt-6">
                            <Skeleton className="w-28 h-12 rounded-lg" />
                            <Skeleton className="w-28 h-12 rounded-lg" />
                        </div>
                    </div>
                </div>
            </InterviewLayout>
        );
    }

    if (error && !interview) { // Critical loading error
        return <InterviewLayout><div className="text-center text-red-500">{error}</div></InterviewLayout>;
    }
    
    if (showFinishedScreen) {
        return (
            <InterviewLayout>
                <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center flex flex-col items-center justify-center h-full">
                    <Check size={80} className="text-cyan-500" />
                    <h2 className="text-4xl font-bold mt-4 gradient-text">Interview Complete!</h2>
                    <p className="mt-2 text-lg text-gray-500 dark:text-gray-400">Thank you for your time. Your responses have been submitted for analysis.</p>
                    <Button onClick={() => navigate('/candidate')} className="mt-8">
                        Back to Dashboard
                    </Button>
                </motion.div>
            </InterviewLayout>
        );
    }
    
    const currentQuestion = interview?.questions[currentQuestionIndex];
    const hasRecording = !!videoRecordings[currentQuestionIndex];

    return (
        <ErrorBoundary>
        <InterviewLayout>
             <AnimatePresence>
                {isInstructionModalOpen && (
                    <InstructionModal onClose={() => {
                        try {
                           localStorage.setItem(`htc-instructions-seen-${interviewId}`, 'true');
                        } catch (e) { console.error("Could not save instruction seen flag", e); }
                        setIsInstructionModalOpen(false);
                    }} />
                )}
            </AnimatePresence>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-full">
                {/* Left Panel: Video & Controls */}
                <div ref={videoContainerRef} className={`relative flex flex-col ${theme.isDark ? 'bg-black' : 'bg-slate-300'} rounded-2xl p-4 transition-colors`}>
                    <div className="relative w-full aspect-video rounded-lg overflow-hidden flex-1 flex items-center justify-center bg-black/50">
                        {isListening ? (
                            <video ref={liveVideoRef} className="w-full h-full object-cover" autoPlay muted playsInline />
                        ) : hasRecording ? (
                            <video ref={playbackVideoRef} className="w-full h-full object-cover" />
                        ) : (
                            <div className="text-center text-gray-400">
                                <p>Your video will appear here.</p>
                                <p className="text-sm">Click 'Answer' to begin.</p>
                            </div>
                        )}
                         {!isListening && hasRecording && !isPlaying && (
                            <button onClick={handlePlayRecording} className="absolute inset-0 flex items-center justify-center bg-black/50 text-white hover:bg-black/70 transition-all">
                                <Play size={64} />
                            </button>
                        )}
                        <button onClick={toggleFullscreen} className="absolute top-2 right-2 p-2 bg-black/40 rounded-full text-white hover:bg-black/70">
                            {isFullscreen ? <Minimize size={18} /> : <Maximize size={18} />}
                        </button>
                    </div>
                    <div className="flex items-center justify-center gap-4 mt-4">
                        {!isListening ? (
                            <Button onClick={handleStartListening} className="w-40">
                                <Mic className="mr-2" /> {hasRecording ? 'Re-answer' : 'Answer'}
                            </Button>
                        ) : (
                            <Button onClick={handleStopListening} className="w-40" variant="secondary">
                                <StopCircle className="mr-2" /> Stop
                            </Button>
                        )}
                    </div>
                </div>
                {/* Right Panel: Question & Transcript */}
                 <div className={`relative ${theme.cardBgClass} rounded-2xl p-6 flex flex-col border ${theme.borderColorClass}`}>
                    <div className="flex justify-between items-center mb-4">
                        <span className={`px-3 py-1 text-sm font-semibold rounded-full ${theme.isDark ? 'bg-cyan-500/10 text-cyan-400' : 'bg-cyan-100 text-cyan-700'}`}>
                            Question {currentQuestionIndex + 1} of {interview?.questions.length}
                        </span>
                        <div className={`px-3 py-1 text-lg font-bold rounded-full ${timeLeft <= 10 ? 'text-red-400' : ''}`}>
                            {formatTime(timeLeft)}
                        </div>
                    </div>
                    <h2 className="text-xl font-bold mb-4">{currentQuestion}</h2>
                    <div ref={transcriptDisplayRef} className={`flex-1 p-4 rounded-lg overflow-y-auto ${theme.isDark ? 'bg-gray-800/60' : 'bg-slate-200/60'} min-h-[200px]`}>
                        <p className="whitespace-pre-wrap">{answers[currentQuestionIndex] || <span className="text-gray-500">Transcript will appear here as you speak...</span>}</p>
                    </div>
                    {error && <p className="text-red-400 text-sm mt-2 text-center">{error}</p>}
                    <div className="flex justify-between items-center mt-6">
                        <Button onClick={handlePrevQuestion} disabled={isListening || currentQuestionIndex === 0} variant="secondary">
                           <ArrowLeft className="mr-2" /> Prev
                        </Button>
                        
                        {currentQuestionIndex === (interview?.questions.length || 0) - 1 ? (
                            <Button onClick={handleFinishInterview} loading={isAnalyzing} disabled={isListening || Object.keys(answers).length === 0}>
                                Finish & Analyze
                            </Button>
                        ) : (
                            <Button onClick={handleNextQuestion} disabled={isListening}>
                                Next <ArrowRight className="ml-2" />
                            </Button>
                        )}
                    </div>
                </div>
            </div>
        </InterviewLayout>
        </ErrorBoundary>
    );
};

export default InterviewPage;
