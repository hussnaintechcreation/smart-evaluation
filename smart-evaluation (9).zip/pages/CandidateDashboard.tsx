import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { User, List } from 'lucide-react';
import { DashboardLayout } from '../components/common/DashboardLayout';
import type { Interview, InterviewResult, User as UserType } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { Skeleton } from '../components/common/Skeleton';
import ErrorBoundary from '../components/common/ErrorBoundary';
import { Button } from '../components/common/Button';

interface CandidateDashboardProps {
  user: UserType;
  onLogout: () => void;
}

interface DashboardCardProps {
    icon: React.ReactNode;
    title: string;
    children: React.ReactNode;
}

const DashboardCard: React.FC<DashboardCardProps> = ({ icon, title, children }) => {
    const { theme } = useTheme();
    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className={`${theme.cardBgClass} p-6 rounded-xl border ${theme.borderColorClass} w-full`}
        >
            <div className="flex items-center mb-4">
                <div className={`p-2 rounded-lg bg-cyan-500/20`} style={{ color: theme.gradientFromHex }}>
                    {icon}
                </div>
                <h2 className={`text-xl font-bold ml-3 ${theme.textColorClass}`}>{title}</h2>
            </div>
            <div>{children}</div>
        </motion.div>
    );
};

const CandidateDashboard: React.FC<CandidateDashboardProps> = ({ user, onLogout }) => {
  const [interviews, setInterviews] = useState<Interview[]>([]);
  const [interviewResults, setInterviewResults] = useState<Record<number, InterviewResult>>({});
  const [loading, setLoading] = useState(true);
  const { theme } = useTheme();

  useEffect(() => {
    const timer = setTimeout(() => {
        try {
          const savedInterviews = localStorage.getItem('htc-interviews');
          if (savedInterviews) {
            const parsedInterviews: Interview[] = JSON.parse(savedInterviews);
            setInterviews(parsedInterviews);
            
            const results: Record<number, InterviewResult> = {};
            parsedInterviews.forEach(interview => {
                const resultData = localStorage.getItem(`htc-interview-result-${interview.id}`);
                if (resultData) {
                    results[interview.id] = JSON.parse(resultData) as InterviewResult;
                }
            });
            setInterviewResults(results);
          }
        } catch (e) {
          console.error("Failed to load interviews from localStorage", e);
        } finally {
            setLoading(false);
        }
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return (
      <DashboardLayout userName={user.name} userRole={user.role} onLogout={onLogout} title="Candidate Portal">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Refined Profile Skeleton */}
          <div className={`${theme.cardBgClass} p-6 rounded-xl border ${theme.borderColorClass} w-full`}>
            <div className="flex items-center mb-4">
              <Skeleton className="w-10 h-10 rounded-lg" />
              <Skeleton className="w-1/3 h-6 ml-3" />
            </div>
            <div className="space-y-3">
              <Skeleton className="w-3/4 h-5" />
              <Skeleton className="w-full h-5" />
              <Skeleton className="w-1/2 h-5" />
              <Skeleton className="w-2/3 h-5" />
              <Skeleton className="w-5/6 h-5" />
              <Skeleton className="w-1/4 h-4 mt-2" />
            </div>
          </div>
          {/* Refined Interviews Skeleton */}
          <div className={`${theme.cardBgClass} p-6 rounded-xl border ${theme.borderColorClass} w-full`}>
            <div className="flex items-center mb-4">
              <Skeleton className="w-10 h-10 rounded-lg" />
              <Skeleton className="w-1/3 h-6 ml-3" />
            </div>
            <div className="space-y-4">
              {/* Item 1 */}
              <div className={`${theme.isDark ? 'bg-gray-800/60' : 'bg-slate-200/60'} p-4 rounded-lg flex items-center justify-between`}>
                <div>
                  <Skeleton className="w-5/6 h-5 mb-2" />
                  <Skeleton className="w-2/4 h-4" />
                </div>
                <Skeleton className="w-28 h-9 rounded-lg" />
              </div>
              {/* Item 2 */}
              <div className={`${theme.isDark ? 'bg-gray-800/60' : 'bg-slate-200/60'} p-4 rounded-lg flex items-center justify-between`}>
                <div>
                  <Skeleton className="w-3/4 h-5 mb-2" />
                  <Skeleton className="w-1/2 h-4" />
                </div>
                <Skeleton className="w-28 h-9 rounded-lg" />
              </div>
              {/* Item 3 */}
              <div className={`${theme.isDark ? 'bg-gray-800/60' : 'bg-slate-200/60'} p-4 rounded-lg flex items-center justify-between`}>
                <div>
                  <Skeleton className="w-4/6 h-5 mb-2" />
                  <Skeleton className="w-1/2 h-4" />
                </div>
                <Skeleton className="w-28 h-9 rounded-lg" />
              </div>
            </div>
          </div>
        </div>
      </DashboardLayout>
    );
  }
    
  return (
    <DashboardLayout userName={user.name} userRole={user.role} onLogout={onLogout} title="Candidate Portal">
      <ErrorBoundary>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <DashboardCard icon={<User />} title="My Profile">
              <div className={`space-y-3 ${theme.textColorClass}`}>
                  <p><strong>Full Name:</strong> {user.name}</p>
                  <p><strong>Email:</strong> {user.email}</p>
                  <p><strong>Gender:</strong> {user.gender || 'Not specified'}</p>
                  <p><strong>Date of Birth:</strong> {user.dob || 'Not specified'}</p>
                  <p><strong>CNIC:</strong> {user.cnic || 'Not specified'}</p>
                  <Link to="/profile" className={`text-sm ${theme.isDark ? 'text-cyan-400' : 'text-cyan-600'} hover:underline mt-2 font-semibold`}>
                    Edit Profile
                  </Link>
              </div>
          </DashboardCard>

          <DashboardCard icon={<List />} title="My Interviews">
              <div className="space-y-4">
                  {interviews.length > 0 ? interviews.map(interview => {
                      const result = interviewResults[interview.id];
                      return (
                          <div key={interview.id} className={`${theme.isDark ? 'bg-gray-800/60' : 'bg-slate-200/60'} p-4 rounded-lg flex items-center justify-between`}>
                              <div>
                                  <p className={`font-semibold ${theme.textColorClass}`}>{interview.title}</p>
                                  <p className="text-sm text-gray-500 dark:text-gray-400">{interview.questions.length} questions</p>
                              </div>
                              {result ? (
                                  <Link to={`/candidate/interview-result/${interview.id}`}>
                                      <Button>View Result</Button>
                                  </Link>
                              ) : (
                                  <Link to={`/interview/${interview.id}`}>
                                      <Button>Start Interview</Button>
                                  </Link>
                              )}
                          </div>
                      );
                  }) : (
                      <p className="text-center py-4 text-gray-500">No interviews are available at this time.</p>
                  )}
              </div>
          </DashboardCard>
        </div>
      </ErrorBoundary>
    </DashboardLayout>
  );
};

export default CandidateDashboard;
