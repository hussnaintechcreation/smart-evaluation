// Singleton audio manager for background ambient sound

interface AudioManagerState {
  audioElement: HTMLAudioElement | null;
  audioContext: AudioContext | null;
  sourceNode: MediaElementAudioSourceNode | null;
  gainNode: GainNode | null;
  isPlaying: boolean;
  isInitialized: boolean;
  isLoading: boolean;
  volume: number;
}

const state: AudioManagerState = {
  audioElement: null,
  audioContext: null,
  sourceNode: null,
  gainNode: null,
  isPlaying: false,
  isInitialized: false,
  isLoading: false,
  volume: 0.3, // Start at a low, unobtrusive volume
};

export const audioManager = {
  async init(audioUrl: string): Promise<void> {
    if (state.isInitialized || state.isLoading) return;

    // This must be called from a user gesture (e.g., a click)
    state.isLoading = true;
    try {
      if (!state.audioContext) { // Only create everything once
        state.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        
        state.audioElement = new Audio(audioUrl);
        state.audioElement.crossOrigin = 'anonymous';
        state.audioElement.loop = true;
        
        // Sync React state with audio element state
        state.audioElement.onplay = () => { state.isPlaying = true; };
        state.audioElement.onpause = () => { state.isPlaying = false; };
        
        state.sourceNode = state.audioContext.createMediaElementSource(state.audioElement);
        state.gainNode = state.audioContext.createGain();
        
        state.sourceNode.connect(state.gainNode);
        state.gainNode.connect(state.audioContext.destination);
      }

      state.gainNode!.gain.setValueAtTime(state.volume, state.audioContext.currentTime);
      state.isInitialized = true;
    } catch (error) {
      console.error("Error initializing ambient audio:", error);
      // Reset everything on failure to allow retrying
      state.isInitialized = false;
      state.audioContext = null;
      state.audioElement = null;
    } finally {
        state.isLoading = false;
    }
  },

  play(): void {
    if (!state.isInitialized || state.isPlaying || !state.audioContext || !state.audioElement) return;
    
    // Resume context if it was suspended
    if (state.audioContext.state === 'suspended') {
        state.audioContext.resume();
    }

    state.audioElement.play().catch(e => {
        console.error("Audio play failed:", e);
        state.isPlaying = false; // Ensure state is correct on failure
    });
  },

  pause(): void {
    if (!state.isPlaying || !state.audioElement) return;
    state.audioElement.pause();
  },

  setVolume(level: number): void {
    state.volume = Math.max(0, Math.min(1, level)); // Clamp between 0 and 1
    if (state.gainNode && state.audioContext) {
      // Use gain node for smoother volume changes
      state.gainNode.gain.linearRampToValueAtTime(state.volume, state.audioContext.currentTime + 0.1);
    }
  },
  
  getState() {
      return {
          isPlaying: state.isPlaying,
          volume: state.volume,
          isInitialized: state.isInitialized,
          isLoading: state.isLoading,
      };
  }
};
