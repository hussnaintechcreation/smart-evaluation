/**
 * The single source of truth for the application's current version.
 * This should be updated in tandem with package.json for each new release.
 */
export const APP_VERSION = '1.0.0';
