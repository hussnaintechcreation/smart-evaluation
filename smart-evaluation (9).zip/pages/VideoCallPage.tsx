
import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mic, MicOff, Video, VideoOff, PhoneOff, User as UserIcon } from 'lucide-react';
import { SmartEvaluationIcon } from '../components/common/SmartEvaluationIcon';
import { useTheme } from '../contexts/ThemeContext';
import type { User } from '../types';
import ErrorBoundary from '../components/common/ErrorBoundary';

// Basic STUN server configuration for NAT traversal
const servers = {
  iceServers: [
    {
      urls: ['stun:stun1.l.google.com:19302', 'stun:stun2.l.google.com:19302'],
    },
  ],
};

const VideoCallPage: React.FC = () => {
    const { interviewId } = useParams();
    const navigate = useNavigate();
    const { theme } = useTheme();

    const [localStream, setLocalStream] = useState<MediaStream | null>(null);
    const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
    const [isMuted, setIsMuted] = useState(false);
    const [isCameraOff, setIsCameraOff] = useState(false);
    const [user, setUser] = useState<User | null>(null);
    const [error, setError] = useState('');

    const peerConnection = useRef<RTCPeerConnection | null>(null);
    const localVideoRef = useRef<HTMLVideoElement>(null);
    const remoteVideoRef = useRef<HTMLVideoElement>(null);

    // Load user role
    useEffect(() => {
        try {
            const savedUser = localStorage.getItem('htc-user');
            if (savedUser) {
                setUser(JSON.parse(savedUser) as User);
            } else {
                navigate('/login');
            }
        } catch (e) {
            console.error("Failed to parse user data", e);
            navigate('/login');
        }
    }, [navigate]);

    // Cleanup on unmount
    useEffect(() => {
        return () => {
            localStream?.getTracks().forEach(track => track.stop());
            peerConnection.current?.close();
            // Clear signaling data on leaving to prevent stale connections
            if (interviewId) {
                try {
                    localStorage.removeItem(`webrtc-offer-${interviewId}`);
                    localStorage.removeItem(`webrtc-answer-${interviewId}`);
                    localStorage.removeItem(`webrtc-ice-candidates-${interviewId}-admin`);
                    localStorage.removeItem(`webrtc-ice-candidates-${interviewId}-candidate`);
                } catch (e) {
                    console.error("Failed to clear WebRTC signaling data:", e);
                }
            }
        };
    }, [localStream, interviewId]);

    // Main WebRTC setup effect
    useEffect(() => {
        if (!user || !interviewId) return;

        let isMounted = true;

        const setupWebRTC = async () => {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
                if (!isMounted) {
                    stream.getTracks().forEach(track => track.stop());
                    return;
                }
                setLocalStream(stream);
                if (localVideoRef.current) {
                    localVideoRef.current.srcObject = stream;
                }

                peerConnection.current = new RTCPeerConnection(servers);

                stream.getTracks().forEach(track => {
                    peerConnection.current!.addTrack(track, stream);
                });

                peerConnection.current.ontrack = event => {
                    setRemoteStream(event.streams[0]);
                    if (remoteVideoRef.current) {
                        remoteVideoRef.current.srcObject = event.streams[0];
                    }
                };

                peerConnection.current.onicecandidate = event => {
                    if (event.candidate) {
                        try {
                            const candidatesKey = `webrtc-ice-candidates-${interviewId}-${user.role}`;
                            const candidates = JSON.parse(localStorage.getItem(candidatesKey) || '[]');
                            candidates.push(event.candidate);
                            localStorage.setItem(candidatesKey, JSON.stringify(candidates));
                        } catch (e) {
                            console.error("Failed to store ICE candidate:", e);
                            setError("Connection error: Failed to exchange network information.");
                        }
                    }
                };
                
                // Signaling logic
                if (user.role === 'admin') {
                    const offer = await peerConnection.current.createOffer();
                    await peerConnection.current.setLocalDescription(offer);
                    localStorage.setItem(`webrtc-offer-${interviewId}`, JSON.stringify(offer));
                } else { // candidate
                    const offerString = localStorage.getItem(`webrtc-offer-${interviewId}`);
                    if (offerString) {
                        const offer = JSON.parse(offerString);
                        await peerConnection.current!.setRemoteDescription(new RTCSessionDescription(offer));
                        const answer = await peerConnection.current!.createAnswer();
                        await peerConnection.current!.setLocalDescription(answer);
                        localStorage.setItem(`webrtc-answer-${interviewId}`, JSON.stringify(answer));
                    }
                }
            } catch (err) {
                 console.error("WebRTC setup failed:", err);
                let message = "Could not start video call. Please check your camera/microphone and refresh.";
                if (err instanceof Error) {
                    if (err.name === 'NotAllowedError' || err.name === 'SecurityError') {
                        message = "Camera/Microphone access was denied. Please grant permissions and refresh.";
                    }
                } else if (err instanceof DOMException) {
                    if (err.name === 'NotFoundError') {
                        message = "No camera or microphone found. Please connect a device and refresh.";
                    } else if (err.name === 'QuotaExceededError' || err.name === 'NS_ERROR_DOM_QUOTA_REACHED') {
                        message = "Cannot start call: Your browser storage is full. Please clear some space and try again.";
                    }
                }
                setError(message);
            }
        };

        const handleStorageChange = async (event: StorageEvent) => {
            if (!peerConnection.current || !interviewId || !event.newValue) return;
            try {
                if (user.role === 'admin' && event.key === `webrtc-answer-${interviewId}`) {
                    const answer = JSON.parse(event.newValue);
                    if (!peerConnection.current.currentRemoteDescription) {
                        await peerConnection.current.setRemoteDescription(new RTCSessionDescription(answer));
                    }
                }

                const otherRole = user.role === 'admin' ? 'candidate' : 'admin';
                if (event.key === `webrtc-ice-candidates-${interviewId}-${otherRole}`) {
                    const candidates = JSON.parse(event.newValue);
                    for (const candidate of candidates) {
                        if (candidate) {
                            await peerConnection.current!.addIceCandidate(new RTCIceCandidate(candidate)).catch(e => console.error("Error adding received ICE candidate", e));
                        }
                    }
                }
            } catch (e) {
                console.error("Error handling signaling data:", e);
                setError("Connection error: Failed to process incoming network information.");
            }
        };
        
        setupWebRTC();
        window.addEventListener('storage', handleStorageChange);

        return () => {
             isMounted = false;
             window.removeEventListener('storage', handleStorageChange);
        }

    }, [user, interviewId]);
    
    // Toggle functions
    const toggleMute = () => {
        localStream?.getAudioTracks().forEach(track => {
            track.enabled = !track.enabled;
        });
        setIsMuted(!isMuted);
    };

    const toggleCamera = () => {
        localStream?.getVideoTracks().forEach(track => {
            track.enabled = !track.enabled;
        });
        setIsCameraOff(!isCameraOff);
    };
    
    const hangUp = () => {
        navigate(user?.role === 'admin' ? '/admin' : '/candidate');
    };

    return (
      <div className={`min-h-screen ${theme.primaryBgClass} ${theme.textColorClass} flex flex-col items-center p-4 md:p-8`}>
        <ErrorBoundary>
          <>
            <header className="w-full max-w-7xl mb-4 flex justify-between items-center">
                <SmartEvaluationIcon />
                <h1 className="text-xl font-bold gradient-text">Live Interview</h1>
            </header>
            <div className="relative w-full flex-1 rounded-xl bg-black border-2 border-cyan-500/30 overflow-hidden shadow-2xl shadow-cyan-500/10">
                <motion.video
                    ref={remoteVideoRef}
                    autoPlay
                    playsInline
                    className="w-full h-full object-cover"
                    initial={{ opacity: 0 }}
                    animate={remoteStream ? { opacity: 1 } : {}}
                />
                {!remoteStream && !error && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <UserIcon size={64} className="text-gray-600" />
                        <p className="mt-4 text-gray-500">Waiting for the other participant to join...</p>
                    </div>
                )}
                {error && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center p-4">
                        <div className="bg-red-500/20 text-red-300 p-4 rounded-lg text-center">
                            <p className="font-bold">Connection Error</p>
                            <p className="text-sm mt-1">{error}</p>
                        </div>
                    </div>
                )}
                <motion.div
                    drag
                    dragConstraints={{ left: 0, right: window.innerWidth - 220, top: 0, bottom: window.innerHeight - 200 }}
                    className="absolute top-4 right-4 w-40 md:w-52 aspect-video rounded-lg overflow-hidden border-2 border-gray-600 shadow-lg cursor-grab active:cursor-grabbing bg-black"
                >
                    <video
                        ref={localVideoRef}
                        autoPlay
                        muted
                        playsInline
                        className="w-full h-full object-cover"
                    />
                </motion.div>

                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-4 p-3 bg-gray-900/80 backdrop-blur-sm rounded-full">
                    <button onClick={toggleMute} className={`p-3 rounded-full transition-colors ${isMuted ? 'bg-red-500 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-200'}`}>
                        {isMuted ? <MicOff /> : <Mic />}
                    </button>
                     <button onClick={toggleCamera} className={`p-3 rounded-full transition-colors ${isCameraOff ? 'bg-red-500 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-200'}`}>
                        {isCameraOff ? <VideoOff /> : <Video />}
                    </button>
                    <button onClick={hangUp} className="p-3 rounded-full bg-red-600 hover:bg-red-700 text-white">
                        <PhoneOff />
                    </button>
                </div>
            </div>
          </>
        </ErrorBoundary>
      </div>
    );
};

export default VideoCallPage;
