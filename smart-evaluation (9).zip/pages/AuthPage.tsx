

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence, Variants } from 'framer-motion';
import { Input } from '../components/common/Input';
import { Button } from '../components/common/Button';
import { formatCNIC, validateCNIC } from './utils/cnic';
import { Hero3D } from '../components/Hero3D';
import { SmartEvaluationIcon } from '../components/common/SmartEvaluationIcon';
import { BrandFooter } from '../components/common/BrandFooter';
import { useTheme } from '../contexts/ThemeContext';
import { BackgroundVideo } from '../components/common/BackgroundVideo';
import { AmbientAudioPlayer } from '../components/common/AmbientAudioPlayer';
import { Shield, User, ArrowLeft } from 'lucide-react';

interface AuthPageProps {
  onAuth: (role: 'admin' | 'candidate', name: string, email: string) => void;
  onDemoLogin: () => void;
}

// Animation Variants
const containerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1, duration: 0.4 } },
  exit: { opacity: 0, transition: { duration: 0.2 } },
};

const panelVariants: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' } },
};

// Reusable selection card component
const PortalSelectionCard: React.FC<{
  title: string;
  description: string;
  icon: React.ReactNode;
  onClick: () => void;
  shadowColorClass: string;
}> = ({ title, description, icon, onClick, shadowColorClass }) => {
  const { theme } = useTheme();
  return (
    <motion.div
      variants={panelVariants}
      whileHover={{ y: -8, scale: 1.02 }}
      transition={{ type: 'spring', stiffness: 300 }}
      onClick={onClick}
      className={`cursor-pointer p-8 ${theme.cardBgClass} backdrop-blur-xl border ${theme.borderColorClass} rounded-2xl shadow-2xl ${shadowColorClass} text-center flex flex-col items-center`}
    >
      {icon}
      <h2 className="text-2xl font-bold mt-4">{title}</h2>
      <p className="text-gray-500 dark:text-gray-400 mt-2 flex-1">{description}</p>
      <span className={`mt-4 font-semibold text-sm gradient-text`}>
        Select Portal &rarr;
      </span>
    </motion.div>
  );
};


const AuthPage: React.FC<AuthPageProps> = ({ onAuth, onDemoLogin }) => {
  const { theme } = useTheme();
  const [view, setView] = useState<'selection' | 'admin' | 'candidate'>('selection');

  // State for Candidate Form
  const [isSigningUp, setIsSigningUp] = useState(false);
  const [candidateEmail, setCandidateEmail] = useState('');
  const [candidatePassword, setCandidatePassword] = useState('');
  const [candidateFullName, setCandidateFullName] = useState('');
  const [candidateCnic, setCandidateCnic] = useState('');
  const [candidateValidationErrors, setCandidateValidationErrors] = useState<Record<string, string>>({});
  const [candidateAuthError, setCandidateAuthError] = useState('');
  const [isCandidateLoading, setIsCandidateLoading] = useState(false);

  // State for Admin Form
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminValidationError, setAdminValidationError] = useState<Record<string, string>>({});
  const [adminAuthError, setAdminAuthError] = useState('');
  const [isAdminLoading, setIsAdminLoading] = useState(false);

  // Pre-fill forms with demo credentials for user guidance
  useEffect(() => {
    setAdminEmail('admin@htc.com');
    setAdminPassword('admin123');
    setCandidateEmail('candidate@htc.com');
    setCandidatePassword('candidate123');
  }, []);

  const handleCnicChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCNIC(e.target.value);
    setCandidateCnic(formatted);
    if (candidateValidationErrors.cnic) setCandidateValidationErrors(p => ({...p, cnic: ''}));
  };

  // Validation and Submit for Admin
  const validateAdminForm = () => {
    const errors: Record<string, string> = {};
    if (!adminEmail) errors.email = 'Email address is required.';
    else if (!/\S+@\S+\.\S+/.test(adminEmail)) errors.email = 'Email address is invalid.';
    if (!adminPassword) errors.password = 'Password is required.';
    setAdminValidationError(errors);
    return Object.keys(errors).length === 0;
  }

  const handleAdminSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAdminAuthError('');
    if (!validateAdminForm()) return;
    setIsAdminLoading(true);

    setTimeout(() => {
        const isAdmin = adminEmail.toLowerCase() === 'admin@htc.com' && adminPassword === 'admin123';
        if (isAdmin) {
          onAuth('admin', 'HUSSNAIN', adminEmail);
        } else {
          setAdminAuthError('Invalid admin credentials.');
        }
      setIsAdminLoading(false);
    }, 1000);
  }

  // Validation and Submit for Candidate
  const validateCandidateForm = () => {
    const errors: Record<string, string> = {};
    if (!candidateEmail) errors.email = 'Email address is required.';
    else if (!/\S+@\S+\.\S+/.test(candidateEmail)) errors.email = 'Email address is invalid.';
    if (!candidatePassword) errors.password = 'Password is required.';
    else if (candidatePassword.length < 6 && isSigningUp) errors.password = 'Password must be at least 6 characters.';

    if (isSigningUp) {
      if (!candidateFullName.trim()) errors.fullName = 'Full name is required.';
      if (!candidateCnic) errors.cnic = 'CNIC is required.';
      else if (!validateCNIC(candidateCnic)) errors.cnic = 'Invalid CNIC format. Use #####-#######-#.';
    }
    
    setCandidateValidationErrors(errors);
    return Object.keys(errors).length === 0;
  }

  const handleCandidateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCandidateAuthError('');
    if (!validateCandidateForm()) return;

    setIsCandidateLoading(true);

    setTimeout(() => {
      if (isSigningUp) {
        onAuth('candidate', candidateFullName, candidateEmail);
      } else { // Login mode
        const isCandidate = candidateEmail.toLowerCase() === 'candidate@htc.com' && candidatePassword === 'candidate123';
        if (isCandidate) {
          onAuth('candidate', 'HUSSNAIN', candidateEmail);
        } else {
          setCandidateAuthError('Invalid candidate credentials.');
        }
      }
      setIsCandidateLoading(false);
    }, 1000);
  };
  
  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen p-4 overflow-hidden">
      <AmbientAudioPlayer />
      <BackgroundVideo src="https://cdn.pixabay.com/video/2024/02/01/198301-912534563_large.mp4" />
      <div className="absolute inset-0 z-0">
          <Hero3D />
      </div>

      <div className="relative z-10 w-full">
        <div className="text-center mb-8 max-w-4xl mx-auto">
            <SmartEvaluationIcon />
            <p className="text-gray-500 dark:text-gray-400 mt-2">
                Welcome to the future of interviewing. Please select your portal to begin.
            </p>
        </div>

        <AnimatePresence mode="wait">
          {view === 'selection' ? (
            <motion.div
              key="selection"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto"
            >
              <PortalSelectionCard
                title="Admin Portal"
                description="Manage interviews, review candidates, and access administrative tools."
                icon={<Shield className="w-12 h-12 gradient-text" />}
                onClick={() => setView('admin')}
                shadowColorClass="shadow-cyan-500/10"
              />
              <PortalSelectionCard
                title="Candidate Portal"
                description="Take your scheduled interview, manage your profile, and view your results."
                icon={<User className="w-12 h-12 gradient-text" />}
                onClick={() => setView('candidate')}
                shadowColorClass="shadow-blue-500/10"
              />
            </motion.div>
          ) : (
            <motion.div
              key="form"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              className={`relative max-w-md mx-auto p-8 ${theme.cardBgClass} backdrop-blur-xl border ${theme.borderColorClass} rounded-2xl shadow-2xl`}
            >
              <button onClick={() => setView('selection')} className={`absolute top-4 left-4 flex items-center gap-1 text-sm ${theme.textColorClass} opacity-70 hover:opacity-100 transition-opacity`}>
                <ArrowLeft size={16} /> Back
              </button>

              {view === 'admin' ? (
                <>
                  <div className="flex flex-col items-center text-center mb-6">
                    <Shield className="w-10 h-10 gradient-text mb-2" />
                    <h2 className="text-2xl font-bold">Admin Portal</h2>
                  </div>
                  <form onSubmit={handleAdminSubmit} className="space-y-4">
                    <Input
                        id="admin-email" type="email" placeholder="Email"
                        value={adminEmail} onChange={(e) => setAdminEmail(e.target.value)}
                        error={adminValidationError.email}
                    />
                    <Input
                        id="admin-password" type="password" placeholder="Password"
                        value={adminPassword} onChange={(e) => setAdminPassword(e.target.value)}
                        error={adminValidationError.password}
                    />
                    {adminAuthError && <p className="text-red-400 text-sm pt-1 text-center">{adminAuthError}</p>}
                    <Button type="submit" className="w-full !mt-6" loading={isAdminLoading}>
                        Login
                    </Button>
                  </form>
                </>
              ) : ( // Candidate view
                 <>
                  <div className="flex flex-col items-center text-center mb-6">
                    <User className="w-10 h-10 gradient-text mb-2" />
                    <h2 className="text-2xl font-bold">Candidate Portal</h2>
                  </div>
                  <form onSubmit={handleCandidateSubmit} className="space-y-4">
                    <AnimatePresence mode="popLayout">
                      {isSigningUp && (
                        <motion.div key="signup-fields" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="space-y-4 overflow-hidden">
                            <Input
                            id="fullName-signup" type="text" placeholder="Full Name"
                            value={candidateFullName} onChange={(e) => setCandidateFullName(e.target.value)}
                            error={candidateValidationErrors.fullName}
                          />
                        </motion.div>
                      )}
                    </AnimatePresence>
                    <Input
                        id="candidate-email" type="email" placeholder="Email"
                        value={candidateEmail} onChange={(e) => setCandidateEmail(e.target.value)}
                        error={candidateValidationErrors.email}
                    />
                    <Input
                        id="candidate-password" type="password" placeholder="Password"
                        value={candidatePassword} onChange={(e) => setCandidatePassword(e.target.value)}
                        error={candidateValidationErrors.password}
                    />
                    <AnimatePresence mode="popLayout">
                      {isSigningUp && (
                        <motion.div key="cnic-field" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
                           <Input
                            id="cnic-signup" type="text" placeholder="CNIC (#####-#######-#)"
                            value={candidateCnic} onChange={handleCnicChange} maxLength={15}
                            error={candidateValidationErrors.cnic}
                          />
                        </motion.div>
                      )}
                    </AnimatePresence>
                    {candidateAuthError && <p className="text-red-400 text-sm pt-1 text-center">{candidateAuthError}</p>}
                    <Button type="submit" className="w-full !mt-6" loading={isCandidateLoading}>
                        {isSigningUp ? 'Create Account' : 'Login'}
                    </Button>
                    <div className="text-center text-sm">
                        {isSigningUp ? (
                            <span>Already have an account? <button type="button" onClick={() => setIsSigningUp(false)} className="font-semibold text-cyan-500 hover:underline">Login</button></span>
                        ) : (
                            <span>Don't have an account? <button type="button" onClick={() => setIsSigningUp(true)} className="font-semibold text-cyan-500 hover:underline">Sign Up</button></span>
                        )}
                    </div>
                  </form>
                </>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        <div className="text-center mt-8">
            <Button type="button" onClick={onDemoLogin} variant="secondary">Login with Demo Account</Button>
        </div>
        
        <div className="mt-8">
          <BrandFooter />
        </div>
      </div>
    </div>
  );
};

export default AuthPage;