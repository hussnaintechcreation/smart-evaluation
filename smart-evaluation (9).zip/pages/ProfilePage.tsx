

import React, { useState, useRef, useEffect, Suspense } from 'react';
// FIX: Import 'AnimatePresence' from 'framer-motion' to handle component enter/exit animations.
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '../components/common/Button';
import { Input } from '../components/common/Input';
import { ArrowLeft, User, Edit3, Camera, Save, X, LoaderCircle, Trash2, LogOut } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { Avatar3D } from '../components/Avatar3D';
import type { AvatarConfig, User as UserType } from '../types';
import { formatCNIC, validateCNIC } from './utils/cnic';
import ErrorBoundary from '../components/common/ErrorBoundary';
import { ConfirmationModal } from '../components/common/ConfirmationModal';

interface ProfilePageProps {
  user: UserType;
  onUserUpdate: (updatedUser: Partial<UserType>) => void;
  onLogout: () => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ user, onUserUpdate, onLogout }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
      name: user.name,
      email: user.email,
      gender: user.gender || 'Prefer not to say',
      dob: user.dob || '',
      cnic: user.cnic || '',
  });
  const [error, setError] = useState('');
  const [isClearDataModalOpen, setIsClearDataModalOpen] = useState(false);

  // Avatar state
  const [avatarConfig, setAvatarConfig] = useState<AvatarConfig>({ color: '#00F0FF' });
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [show3DAvatar, setShow3DAvatar] = useState(true);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const avatarCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const { theme } = useTheme();

  useEffect(() => {
    // Load saved 2D avatar or 3D config from localStorage
    try {
        const savedAvatar = localStorage.getItem('htc-user-avatar');
        if (savedAvatar) {
            setAvatarPreview(savedAvatar);
            setShow3DAvatar(false);
        }
        const savedConfig = localStorage.getItem('htc-user-avatar-config');
        if (savedConfig) {
            setAvatarConfig(JSON.parse(savedConfig) as AvatarConfig);
        }
    } catch(e) { console.error("Failed to load user preferences", e); }
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      const { name, value } = e.target;
      setFormData(prev => ({ ...prev, [name]: name === 'cnic' ? formatCNIC(value) : value }));
  };

  const handleAvatarUploadClick = () => {
      fileInputRef.current?.click();
  };

  const handleAvatarFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setError('');
      const file = e.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onloadend = () => {
            const result = reader.result as string;
              setAvatarPreview(result);
              try {
                localStorage.setItem('htc-user-avatar', result);
                setShow3DAvatar(false);
              } catch (err) {
                console.error("Failed to save avatar preview:", err);
                setError("Could not save new avatar. Your browser storage might be full.");
              }
          };
          reader.readAsDataURL(file);
      }
  };
  
  const handleRemoveAvatar = () => {
    setError('');
    setAvatarPreview(null);
    setShow3DAvatar(true);
    try {
        localStorage.removeItem('htc-user-avatar');
    } catch (e) {
        console.error("Failed to remove avatar:", e);
        setError("Could not remove avatar. Your browser storage might be full or disabled.");
    }
  };

  const handleSave = () => {
    setError('');
    const updatedUserData: Partial<UserType> = {
        name: formData.name,
        gender: formData.gender as UserType['gender'],
        dob: formData.dob,
        cnic: formData.cnic,
    };
    onUserUpdate(updatedUserData);

    // Save avatar preferences
    try {
        if (show3DAvatar) {
            localStorage.setItem('htc-user-avatar-config', JSON.stringify(avatarConfig));
            // Capture and save 3D snapshot
            if (avatarCanvasRef.current) {
                const snapshot = avatarCanvasRef.current.toDataURL('image/png');
                localStorage.setItem('htc-user-avatar', snapshot);
            }
        } else if (avatarPreview) {
            localStorage.setItem('htc-user-avatar', avatarPreview);
        } else {
             // This case handles removing a 2D avatar to revert to 3D
            localStorage.removeItem('htc-user-avatar');
        }
        window.dispatchEvent(new Event('storage')); // Notify other components
    } catch (e) {
        console.error("Failed to save avatar", e);
        setError("Failed to save your preferences. Please try again.");
    }

    setIsEditing(false);
  };
  
  const handleCancel = () => {
    setError('');
    // Reset form to original user data
    setFormData({
        name: user.name,
        email: user.email,
        gender: user.gender || 'Prefer not to say',
        dob: user.dob || '',
        cnic: user.cnic || '',
    });
    // Reset avatar state
    const savedAvatar = localStorage.getItem('htc-user-avatar');
    if (savedAvatar) {
      setAvatarPreview(savedAvatar);
      setShow3DAvatar(false);
    } else {
      setShow3DAvatar(true);
    }
    setIsEditing(false);
  }

  const handleClearData = () => {
    setError(''); // Clear previous errors
    try {
      const keysToRemove: string[] = [];
      // Iterate over all keys in localStorage
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && (
          key.startsWith('htc-interview-progress-') || 
          key.startsWith('htc-interview-result-') || 
          key.startsWith('htc-instructions-seen-')
        )) {
          keysToRemove.push(key);
        }
      }
      
      // Remove all identified keys
      keysToRemove.forEach(key => localStorage.removeItem(key));
      
      // Remove static chat history key
      localStorage.removeItem('htc-chat-history');

      console.log('Application cache cleared.');
      setIsClearDataModalOpen(false);

      // Reload the page to reflect the cleared state
      window.location.reload();
    } catch (e) {
      console.error("Failed to clear application data:", e);
      setError("Could not clear data. Your browser's storage might be full or disabled.");
      setIsClearDataModalOpen(false);
    }
  };


  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 relative">
      <ErrorBoundary>
        <>
          <input type="file" ref={fileInputRef} onChange={handleAvatarFileChange} accept="image/*" className="hidden" />
          <div className="absolute top-6 left-6 z-20">
              <Link to="/candidate">
                  <Button variant="secondary">
                      <ArrowLeft size={16} className="mr-2" /> Back to Dashboard
                  </Button>
              </Link>
          </div>

          <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.5, ease: 'easeOut' }}
              className={`relative z-10 w-full max-w-md ${theme.cardBgClass} p-8 rounded-3xl border-2 shadow-2xl`}
              style={{
                  borderColor: `${theme.gradientFromHex}40`,
                  boxShadow: `0 10px 30px -10px ${theme.gradientFromHex}30`,
                  background: theme.isDark ? 'rgba(15, 23, 42, 0.5)' : 'rgba(255, 255, 255, 0.5)',
                  backdropFilter: 'blur(16px)',
              }}
          >
              <div className="flex flex-col items-center">
                  <div className="relative mb-4 w-40 h-40 group">
                      <AnimatePresence>
                      {!show3DAvatar && avatarPreview && (
                          <motion.img 
                              src={avatarPreview} 
                              alt="Profile" 
                              className="w-full h-full rounded-full object-cover"
                              initial={{ scale: 0.8, opacity: 0 }}
                              animate={{ scale: 1, opacity: 1 }}
                              exit={{ scale: 0.8, opacity: 0 }}
                          />
                      )}
                      </AnimatePresence>
                      <AnimatePresence>
                      {show3DAvatar && (
                          <motion.div 
                              className="w-full h-full absolute inset-0"
                              initial={{ scale: 0.8, opacity: 0 }}
                              animate={{ scale: 1, opacity: 1 }}
                              exit={{ scale: 0.8, opacity: 0 }}
                          >
                              <Suspense fallback={
                                  <div className="w-full h-full rounded-full bg-gray-800 flex items-center justify-center">
                                      <LoaderCircle className="animate-spin" />
                                  </div>
                              }>
                                  <Avatar3D 
                                      color={avatarConfig.color}
                                      onCanvasMount={(canvas) => (avatarCanvasRef.current = canvas)}
                                  />
                              </Suspense>
                          </motion.div>
                      )}
                      </AnimatePresence>
                       <AnimatePresence>
                          {isEditing && (
                              <motion.div
                                  initial={{ opacity: 0 }}
                                  animate={{ opacity: 1 }}
                                  exit={{ opacity: 0 }}
                                  className="absolute inset-0 bg-black/60 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                                  onClick={handleAvatarUploadClick}
                              >
                                  <div className="text-white text-center">
                                      <Camera size={24} />
                                      <p className="text-xs mt-1 font-semibold">Change</p>
                                  </div>
                              </motion.div>
                          )}
                      </AnimatePresence>
                  </div>

                  {!isEditing ? (
                      <div className="text-center w-full">
                          <h2 className={`text-3xl font-bold ${theme.textColorClass}`}>{user.name}</h2>
                          <p className="text-gray-500 dark:text-gray-400 mt-1">{user.email}</p>

                          <div className={`mt-6 w-full text-left p-4 rounded-lg ${theme.isDark ? 'bg-gray-800/40' : 'bg-slate-100/60'}`}>
                              <ul className="space-y-3">
                                  <li className="flex justify-between items-center">
                                      <span className="font-semibold text-gray-500 dark:text-gray-400 text-sm">Gender</span>
                                      <span className={`${theme.textColorClass}`}>{user.gender || 'Not specified'}</span>
                                  </li>
                                  <li className="flex justify-between items-center">
                                      <span className="font-semibold text-gray-500 dark:text-gray-400 text-sm">Date of Birth</span>
                                      <span className={`${theme.textColorClass}`}>{user.dob || 'Not specified'}</span>
                                  </li>
                                  <li className="flex justify-between items-center">
                                      <span className="font-semibold text-gray-500 dark:text-gray-400 text-sm">CNIC</span>
                                      <span className={`${theme.textColorClass}`}>{user.cnic || 'Not specified'}</span>
                                  </li>
                              </ul>
                          </div>

                          <Button onClick={() => setIsEditing(true)} className="mt-6">
                              <Edit3 size={16} className="mr-2"/> Edit Profile
                          </Button>
                      </div>
                  ) : (
                      <div className="w-full text-left space-y-4">
                          <div>
                             <h3 className={`text-xl font-bold text-center mb-4 ${theme.textColorClass}`}>Edit Profile</h3>
                             <div className="flex justify-center gap-2 mb-4">
                                 <Button size="sm" variant="secondary" onClick={handleRemoveAvatar}> <Trash2 size={14} className="mr-1.5"/>Remove Picture</Button>
                             </div>
                          </div>

                          {show3DAvatar && (
                              <div>
                                  <label htmlFor="avatarColor" className="block text-sm font-medium mb-1">Avatar Color</label>
                                  <input id="avatarColor" type="color" value={avatarConfig.color} onChange={(e) => setAvatarConfig({color: e.target.value})} className="w-10 h-10 p-1 bg-transparent border-none rounded-lg cursor-pointer" />
                              </div>
                          )}
                          <div>
                              <label htmlFor="name" className="block text-sm font-medium mb-1">Full Name</label>
                              <Input id="name" name="name" type="text" value={formData.name} onChange={handleInputChange} />
                          </div>
                          <div>
                              <label htmlFor="email" className="block text-sm font-medium mb-1">Email</label>
                              <Input id="email" name="email" type="email" value={formData.email} disabled />
                          </div>
                          <div>
                              <label htmlFor="dob" className="block text-sm font-medium mb-1">Date of Birth</label>
                              <Input id="dob" name="dob" type="date" value={formData.dob} onChange={handleInputChange} />
                          </div>
                           <div>
                              <label htmlFor="gender" className="block text-sm font-medium mb-1">Gender</label>
                              <select name="gender" id="gender" value={formData.gender} onChange={handleInputChange} className={`w-full px-4 py-3 ${theme.isDark ? 'bg-gray-800/50 border-gray-700 text-gray-200' : 'bg-slate-200 border-slate-300 text-slate-800'} rounded-lg placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all duration-300`}>
                                  <option>Male</option>
                                  <option>Female</option>
                                  <option>Other</option>
                                  <option>Prefer not to say</option>
                              </select>
                          </div>
                          <div>
                              <label htmlFor="cnic" className="block text-sm font-medium mb-1">CNIC</label>
                              <Input id="cnic" name="cnic" type="text" placeholder="#####-#######-#" value={formData.cnic} onChange={handleInputChange} maxLength={15} />
                          </div>
                          {error && <p className="text-red-400 text-sm mt-2 text-center">{error}</p>}
                          <div className="flex justify-center gap-4 pt-4">
                              <Button onClick={handleCancel} variant="secondary"><X size={16} className="mr-2"/> Cancel</Button>
                              <Button onClick={handleSave}><Save size={16} className="mr-2"/> Save</Button>
                          </div>
                      </div>
                  )}
                   <div className="w-full border-t mt-6 pt-6 text-center border-cyan-500/10">
                      <Button onClick={onLogout} variant="secondary" size="sm">
                          <LogOut size={14} className="mr-2"/> Log Out
                      </Button>
                  </div>
                  <div className="w-full border-t mt-4 pt-4 text-center border-red-500/20">
                    <Button 
                        onClick={() => setIsClearDataModalOpen(true)}
                        variant="secondary" 
                        size="sm"
                        className="text-red-500 border-red-500/30 hover:bg-red-500/10 dark:text-red-400 dark:border-red-400/30 dark:hover:bg-red-400/10"
                    >
                        <Trash2 size={14} className="mr-2"/> Clear Application Data
                    </Button>
                    <p className="text-xs text-gray-500 mt-2">Removes all interview progress and chat history.</p>
                  </div>
              </div>
          </motion.div>
          <ConfirmationModal
            isOpen={isClearDataModalOpen}
            onClose={() => setIsClearDataModalOpen(false)}
            onConfirm={handleClearData}
            title="Confirm Clear Data"
            message="Are you sure you want to clear all application data? This action will remove all saved interview progress, results, and chat history and cannot be undone."
          />
        </>
      </ErrorBoundary>
    </div>
  );
};

export default ProfilePage;
