
import React, { useState, useEffect } from 'react';
import { Routes, Route, useNavigate, Navigate } from 'react-router-dom';
import HomePage from './pages/HomePage';
import AuthPage from './pages/AuthPage';
import AdminDashboard from './pages/AdminDashboard';
import CandidateDashboard from './pages/CandidateDashboard';
import ProfilePage from './pages/ProfilePage'; // Import ProfilePage
import AIToolsPage from './pages/AIToolsPage';
import InterviewPage from './pages/InterviewPage';
import InterviewResultPage from './pages/InterviewResultPage';
import CertificatePage from './pages/CertificatePage';
import VideoCallPage from './pages/VideoCallPage';
import { Chatbot } from './components/Chatbot';
import { ConfirmationModal } from './components/common/ConfirmationModal';
import { ThemeProvider, useTheme } from './contexts/ThemeContext';
import { mockInterviews, mockInterviewResult } from './pages/utils/mockData';
import { APP_VERSION } from './pages/utils/version';
import ErrorBoundary from './components/common/ErrorBoundary';
import { ProtectedRoute } from './components/common/ProtectedRoute';
import type { User } from './types';


const AppContent: React.FC = () => {
  const [user, setUser] = useState<User | null>(() => {
    try {
        const savedUser = localStorage.getItem('htc-user');
        return savedUser ? (JSON.parse(savedUser) as User) : null;
    } catch (e) {
        console.error("Failed to load user session from localStorage", e);
        return null;
    }
  });
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);
  const navigate = useNavigate();
  const { theme } = useTheme();

  useEffect(() => {
    // --- Data Migration Check ---
    const runMigrations = () => {
        try {
            const storedVersion = localStorage.getItem('htc-app-version');
            if (storedVersion !== APP_VERSION) {
                console.log(`Migrating data from version ${storedVersion || 'pre-1.0.0'} to ${APP_VERSION}`);
                localStorage.setItem('htc-app-version', APP_VERSION);
            }
        } catch (e) {
            console.error("Failed to run data migration:", e);
        }
    };

    runMigrations();
  }, []);

  const handleLogin = (role: 'admin' | 'candidate', name: string, email: string) => {
    try {
        const userData: User = { role, name, email };
        // Pre-populate mock data for the specific candidate
        if (email === 'candidate@htc.com') {
            userData.gender = 'Male';
            userData.dob = '1995-08-15';
            userData.cnic = '12345-6789012-3';
        }
        setUser(userData);
        localStorage.setItem('htc-user', JSON.stringify(userData));
        navigate(role === 'admin' ? '/admin' : '/candidate');
    } catch (e) {
        console.error("Failed to save user session:", e);
        alert("Could not save your session. Your browser's storage might be full or disabled.");
    }
  };
  
  const handleUserUpdate = (updatedUser: Partial<User>) => {
    setUser(prevUser => {
        if (!prevUser) return null;
        const newUser = { ...prevUser, ...updatedUser };
        try {
            localStorage.setItem('htc-user', JSON.stringify(newUser));
        } catch (e) {
             console.error("Failed to update user data:", e);
             alert("Could not save your profile changes. Your browser's storage might be full or disabled.");
        }
        return newUser;
    });
  };

  const handleDemoLogin = () => {
    const demoUser: User = { 
        role: 'candidate' as const, 
        name: 'Demo Candidate',
        email: 'demo@htc.com',
        gender: 'Prefer not to say',
        dob: '2000-01-01',
        cnic: '12345-6789012-3'
    };
    setUser(demoUser);
    try {
        localStorage.setItem('htc-user', JSON.stringify(demoUser));
        localStorage.setItem('htc-interviews', JSON.stringify(mockInterviews));
        localStorage.setItem(`htc-interview-result-${mockInterviewResult.interviewId}`, JSON.stringify(mockInterviewResult));
        localStorage.removeItem(`htc-interview-progress-${mockInterviewResult.interviewId}`);
        localStorage.removeItem(`htc-instructions-seen-${mockInterviewResult.interviewId}`);
    } catch (e) {
        console.error("Failed to pre-populate demo data to localStorage", e);
        alert("Could not log in with demo account due to a storage issue. Your browser's storage might be full or disabled.");
    }
    navigate('/candidate');
  };

  const handleLogoutRequest = () => {
    setIsLogoutModalOpen(true);
  };
  
  const handleConfirmLogout = () => {
      try {
          setUser(null);
          localStorage.removeItem('htc-user');
          localStorage.removeItem('htc-user-avatar');
          localStorage.removeItem('htc-user-avatar-config');
          localStorage.removeItem('htc-chat-history');
          setIsLogoutModalOpen(false);
          navigate('/', { replace: true });
      } catch (e) {
        console.error("Failed to clear session data on logout:", e);
        // Still proceed with logout in the app state even if storage fails
        setUser(null);
        setIsLogoutModalOpen(false);
        navigate('/', { replace: true });
      }
  };
  

  return (
    <div className={`min-h-screen ${theme.primaryBgClass} ${theme.textColorClass} overflow-x-hidden transition-colors duration-300`}>
       <div className="absolute inset-0 z-0 opacity-20">
        <div className="absolute top-0 left-0 w-96 h-96 bg-cyan-500 rounded-full mix-blend-screen filter blur-3xl animate-blob"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500 rounded-full mix-blend-screen filter blur-3xl animate-blob animation-delay-2000"></div>
        <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-purple-500 rounded-full mix-blend-screen filter blur-3xl animate-blob animation-delay-4000"></div>
      </div>
      <ErrorBoundary>
        <main className="relative z-10">
          <Routes>
            <Route 
              path="/" 
              element={!user ? <HomePage /> : <Navigate to={user.role === 'admin' ? '/admin' : '/candidate'} replace />} 
            />
            <Route 
              path="/login" 
              element={!user ? <AuthPage onAuth={handleLogin} onDemoLogin={handleDemoLogin} /> : <Navigate to={user.role === 'admin' ? '/admin' : '/candidate'} replace />} 
            />
            <Route 
              path="/admin" 
              element={
                <ProtectedRoute user={user} allowedRoles={['admin']}>
                  {user ? <AdminDashboard userName={user.name} userRole={user.role} onLogout={handleLogoutRequest} /> : null}
                </ProtectedRoute>
              } 
            />
            <Route
              path="/admin/interview-result/:interviewId"
              element={
                <ProtectedRoute user={user} allowedRoles={['admin']}>
                  {user ? <InterviewResultPage userName={user.name} userRole={user.role} onLogout={handleLogoutRequest} /> : null}
                </ProtectedRoute>
              }
            />
            <Route 
              path="/candidate" 
              element={
                <ProtectedRoute user={user} allowedRoles={['candidate']}>
                  {user ? <CandidateDashboard user={user} onLogout={handleLogoutRequest} /> : null}
                </ProtectedRoute>
              } 
            />
            <Route
              path="/profile"
              element={
                <ProtectedRoute user={user} allowedRoles={['candidate']}>
                  {user ? <ProfilePage user={user} onUserUpdate={handleUserUpdate} onLogout={handleLogoutRequest} /> : null}
                </ProtectedRoute>
              }
            />
            <Route
              path="/candidate/interview-result/:interviewId"
              element={
                <ProtectedRoute user={user} allowedRoles={['candidate']}>
                  {user ? <InterviewResultPage userName={user.name} userRole={user.role} onLogout={handleLogoutRequest} /> : null}
                </ProtectedRoute>
              }
            />
            <Route
              path="/ai-tools"
              element={
                <ProtectedRoute user={user} allowedRoles={['admin', 'candidate']}>
                  {user ? <AIToolsPage userName={user.name} userRole={user.role} onLogout={handleLogoutRequest} /> : null}
                </ProtectedRoute>
              }
            />
            <Route
              path="/interview/:interviewId"
              element={
                <ProtectedRoute user={user} allowedRoles={['candidate']}>
                  <InterviewPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/call/:interviewId"
              element={
                <ProtectedRoute user={user} allowedRoles={['admin', 'candidate']}>
                  <VideoCallPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/certificate/:interviewId"
              element={<CertificatePage />}
            />
            <Route 
              path="*" 
              element={<Navigate to="/" replace />} 
            />
          </Routes>
        </main>
        <Chatbot />
        <ConfirmationModal
          isOpen={isLogoutModalOpen}
          onClose={() => setIsLogoutModalOpen(false)}
          onConfirm={handleConfirmLogout}
          title="Confirm Logout"
          message="Are you sure you want to log out of your account?"
        />
      </ErrorBoundary>
    </div>
  );
};

const App: React.FC = () => (
    <ThemeProvider>
        <AppContent />
    </ThemeProvider>
);

export default App;
