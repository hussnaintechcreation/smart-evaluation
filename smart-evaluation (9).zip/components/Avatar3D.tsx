
// FIX: Removed the `/// <reference types="@react-three/fiber" />` directive.
// In modern TypeScript setups, these types are typically discovered automatically.
// The explicit directive can cause resolution failures and subsequent errors
// where JSX elements from react-three-fiber are not recognized.
import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { useTheme } from '../contexts/ThemeContext';

// FIX: The `extend(THREE)` call, which was causing a type error, has been removed.
// In modern versions of react-three-fiber, most THREE.js objects are available
// as JSX elements by default, making this call redundant.

interface Avatar3DProps {
  color: string;
  onCanvasMount?: (canvas: HTMLCanvasElement) => void;
}

const Figure: React.FC<{ avatarColor: string }> = ({ avatarColor }) => {
  const groupRef = useRef<THREE.Group>(null!);
  const headRef = useRef<THREE.Mesh>(null!);
  const bodyRef = useRef<THREE.Mesh>(null!);
  const material = new THREE.MeshStandardMaterial({
      color: avatarColor,
      roughness: 0.4,
      metalness: 0.1,
  });

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    if (groupRef.current) {
      // Subtle idle breathing animation
      groupRef.current.position.y = Math.sin(time * 2) * 0.05;
    }
    if (headRef.current) {
        // Subtle head movement
        headRef.current.rotation.y = Math.sin(time * 0.7) * 0.1;
        headRef.current.rotation.x = Math.cos(time * 0.5) * 0.05;
    }
  });

  return (
    <group ref={groupRef} position={[0, -0.7, 0]}>
      {/* Head */}
      <mesh ref={headRef} material={material} position={[0, 0.9, 0]}>
        <sphereGeometry args={[0.4, 32, 32]} />
      </mesh>
      {/* Body */}
      <mesh ref={bodyRef} material={material} position={[0, 0.1, 0]}>
        <cylinderGeometry args={[0.3, 0.5, 1.2, 32]} />
      </mesh>
      {/* Base */}
       <mesh material={material} position={[0, -0.6, 0]}>
        <cylinderGeometry args={[0.5, 0.55, 0.2, 32]} />
      </mesh>
    </group>
  );
};

export const Avatar3D: React.FC<Avatar3DProps> = ({ color, onCanvasMount }) => {
  const { theme } = useTheme();

  return (
    <Canvas
      camera={{ position: [0, 0.5, 3], fov: 45 }}
      gl={{ preserveDrawingBuffer: true, antialias: true }}
      onCreated={({ gl }) => {
        if (onCanvasMount) {
          onCanvasMount(gl.domElement);
        }
      }}
      className="rounded-full"
    >
      <ambientLight intensity={0.5} />
      <directionalLight position={[5, 5, 5]} intensity={1.5} />
      <pointLight position={[-5, 2, 5]} color={theme.gradientFromHex} intensity={3} />
      <pointLight position={[5, -2, -5]} color={theme.gradientToHex} intensity={3} />
      
      <Figure avatarColor={color} />
      
      <OrbitControls 
        enableZoom={false} 
        enablePan={false} 
        autoRotate 
        autoRotateSpeed={0.8}
        minPolarAngle={Math.PI / 2.5}
        maxPolarAngle={Math.PI / 1.8}
      />
    </Canvas>
  );
};