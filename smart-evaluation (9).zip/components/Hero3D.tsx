
// FIX: Removed the `/// <reference types="@react-three/fiber" />` directive.
// In modern TypeScript setups, these types are typically discovered automatically.
// The explicit directive can cause resolution failures and subsequent errors
// where JSX elements from react-three-fiber are not recognized.
import React, { useRef, useMemo, forwardRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { EffectComposer, Bloom, DepthOfField, GodRays, Vignette } from '@react-three/postprocessing';
import { KernelSize } from 'postprocessing';
import { useTheme } from '../contexts/ThemeContext';

// FIX: The `extend(THREE)` call, which was causing a type error, has been removed.
// In modern versions of react-three-fiber, most THREE.js objects are available
// as JSX elements by default, making this call redundant.

const DigitalCore = forwardRef<THREE.Mesh>((props, ref) => {
  const groupRef = useRef<THREE.Group>(null!);
  const shellRef = useRef<THREE.Mesh>(null!);
  const innerShellRef = useRef<THREE.Mesh>(null!);
  const ring1Ref = useRef<THREE.Mesh>(null!);
  const ring2Ref = useRef<THREE.Mesh>(null!);
  const ring3Ref = useRef<THREE.Mesh>(null!);
  const lightRef = useRef<THREE.PointLight>(null!);
  const { theme } = useTheme();

  // Ref to track mouse velocity for interaction
  const lastPointer = useRef(new THREE.Vector2());
  const smoothedVelocity = useRef(0); // Using ref to persist smoothed value across frames

  useFrame((state, delta) => {
    const time = state.clock.getElapsedTime();
    
    // --- NEW: Calculate mouse velocity with more smoothing ---
    const pointerVelocity = state.pointer.distanceTo(lastPointer.current) / delta;
    lastPointer.current.copy(state.pointer);
    smoothedVelocity.current = THREE.MathUtils.lerp(smoothedVelocity.current, pointerVelocity, 0.05);

    // Mouse movement interaction: Gently rotate the entire group to "look at" the pointer.
    if (groupRef.current) {
      groupRef.current.rotation.y = THREE.MathUtils.lerp(groupRef.current.rotation.y, (state.pointer.x * Math.PI) / 15, 0.02);
      groupRef.current.rotation.x = THREE.MathUtils.lerp(groupRef.current.rotation.x, (-state.pointer.y * Math.PI) / 15, 0.02);
    }
    
    // Existing animations
    if (ref && 'current' in ref && ref.current) {
      ref.current.rotation.y += delta * 0.5;
      const scale = 1 + Math.sin(time * 2) * 0.05; // Gentle pulse
      ref.current.scale.set(scale, scale, scale);
    }
    if (lightRef.current) {
        lightRef.current.intensity = 2 + Math.sin(time * 2) * 0.5; // Pulse light
    }
    if (shellRef.current) {
      shellRef.current.rotation.x += delta * 0.1;
      shellRef.current.rotation.y -= delta * 0.15;
    }
    if (innerShellRef.current) {
        innerShellRef.current.rotation.y += delta * 0.25;
        innerShellRef.current.rotation.z -= delta * 0.2;
    }
    
    // --- ENHANCED: Rings now react to mouse movement speed with more sensitivity ---
    const velocityFactor = smoothedVelocity.current * 15;
    if (ring1Ref.current) {
      ring1Ref.current.rotation.x = Math.PI / 2;
      ring1Ref.current.rotation.y += delta * (0.3 + velocityFactor);
    }
    if (ring2Ref.current) {
      ring2Ref.current.rotation.x = Math.PI / 2;
      ring2Ref.current.rotation.z += delta * (-0.2 - velocityFactor * 0.8);
    }
    if (ring3Ref.current) {
        ring3Ref.current.rotation.z = Math.PI / 2;
        ring3Ref.current.rotation.y += delta * (0.1 + velocityFactor * 0.5);
    }
  });

  return (
    <group ref={groupRef}>
      {/* Inner glowing core */}
      <mesh ref={ref}>
        <sphereGeometry args={[0.5, 32, 32]} />
        {/* Use theme gradient colors for inner glow */}
        <meshBasicMaterial color={new THREE.Color(theme.gradientFromHex).multiplyScalar(3)} toneMapped={false} />
        <pointLight ref={lightRef} color={theme.gradientFromHex} intensity={2} distance={10} />
      </mesh>
      
      {/* Outer crystalline shell */}
      <mesh ref={shellRef}>
        <icosahedronGeometry args={[1.2, 1]} />
        <meshPhysicalMaterial
            roughness={0}
            transmission={1}
            thickness={0.5}
            color={theme.gradientFromHex}
            envMapIntensity={2}
        />
      </mesh>

      {/* New inner crystalline shell */}
      <mesh ref={innerShellRef}>
        <dodecahedronGeometry args={[0.9, 0]} />
        <meshStandardMaterial
            color={new THREE.Color(theme.gradientToHex).lerp(new THREE.Color(0xffffff), 0.5)}
            emissive={new THREE.Color(theme.gradientToHex)}
            emissiveIntensity={0.3}
            metalness={0.9}
            roughness={0.1}
            transparent
            opacity={0.4}
        />
      </mesh>
      
      {/* Rotating rings */}
      <mesh ref={ring1Ref}>
        <torusGeometry args={[1.8, 0.02, 16, 100]} />
        <meshBasicMaterial color={theme.gradientFromHex} toneMapped={false} />
      </mesh>
       <mesh ref={ring2Ref}>
        <torusGeometry args={[2.2, 0.02, 16, 100]} />
        <meshBasicMaterial color={theme.gradientToHex} toneMapped={false} />
      </mesh>
       <mesh ref={ring3Ref}>
        <torusGeometry args={[1.5, 0.015, 16, 100]} />
        <meshBasicMaterial color="#ffffff" toneMapped={false} />
      </mesh>
    </group>
  );
});

const DataStream: React.FC<{ mouseVec: THREE.Vector3 }> = ({ mouseVec }) => {
    const pointsRef = useRef<THREE.Points>(null!);
    const count = 5000;
    const { theme } = useTheme();
    
    const [positions, colors, originalParams] = useMemo(() => {
        const pos = new Float32Array(count * 3);
        const col = new Float32Array(count * 3);
        const params = new Float32Array(count * 3); // radius, phi, theta
        const color = new THREE.Color();

        for (let i = 0; i < count; i++) {
            const radius = 3 + Math.random() * 2;
            const phi = Math.acos(2 * Math.random() - 1); // latitude
            const theta = Math.random() * Math.PI * 2; // longitude
            params.set([radius, phi, theta], i * 3);
            
            // Initial particle color based on theme
            color.set(theme.gradientFromHex).lerp(new THREE.Color(theme.gradientToHex), Math.random());
            col.set([color.r, color.g, color.b], i * 3);
        }
        return [pos, col, params];
    }, [theme]); // Re-memoize if theme changes

    useFrame((state, delta) => {
        if (!pointsRef.current) return;

        const positions = pointsRef.current.geometry.attributes.position.array as Float32Array;
        const colors = pointsRef.current.geometry.attributes.color.array as Float32Array;
        const time = state.clock.getElapsedTime();
        const tempVec = new THREE.Vector3();
        const tempColor = new THREE.Color();
        const whiteColor = new THREE.Color(0xffffff);

        const fromColor = new THREE.Color(theme.gradientFromHex);
        const toColor = new THREE.Color(theme.gradientToHex);

        for (let i = 0; i < count; i++) {
            const i3 = i * 3;
            const radius = originalParams[i3];
            const phi = originalParams[i3 + 1];
            let theta = originalParams[i3 + 2] + time * 0.05;

            tempVec.setFromSphericalCoords(radius, phi, theta);
            
            // --- REFINED: Interactive Vortex Effect ---
            const dist = tempVec.distanceTo(mouseVec);
            const influenceRadius = 2.5; // Larger radius of effect
            const vortexStrength = 12.0; // Stronger swirl
            const attractionStrength = 1.8; // Weaker pull to center to emphasize swirl

            // Animate particle color based on theme
            const colorFactor = (phi / Math.PI + time * 0.03) % 1;
            tempColor.copy(fromColor).lerp(toColor, colorFactor);
            
            if (dist < influenceRadius) {
                const influenceFactor = Math.pow(1 - dist / influenceRadius, 2);
                
                // Vector from particle to mouse for attraction
                const direction = mouseVec.clone().sub(tempVec).normalize();
                
                // --- ATTRACTION (frame-rate independent) ---
                const attractionDisplacement = direction.clone().multiplyScalar(influenceFactor * attractionStrength * delta);
                tempVec.add(attractionDisplacement);

                // --- VORTEX SWIRL (frame-rate independent) ---
                const tangent = new THREE.Vector3(-direction.y, direction.x, 0).normalize();
                const swirlDisplacement = tangent.multiplyScalar(influenceFactor * vortexStrength * (1 - dist / influenceRadius) * delta);
                tempVec.add(swirlDisplacement);

                // --- ENHANCED GLOW ---
                // Make particles near the cursor glow much brighter and whiter
                const glowFactor = influenceFactor;
                tempColor.lerp(whiteColor, glowFactor).multiplyScalar(1 + glowFactor * 1.5);
            }

            positions[i3] = tempVec.x;
            positions[i3 + 1] = tempVec.y;
            positions[i3 + 2] = tempVec.z;
            
            colors[i3] = tempColor.r;
            colors[i3 + 1] = tempColor.g;
            colors[i3 + 2] = tempColor.b;
        }

        pointsRef.current.geometry.attributes.position.needsUpdate = true;
        pointsRef.current.geometry.attributes.color.needsUpdate = true;
    });

    return (
        <points ref={pointsRef}>
            <bufferGeometry>
                <bufferAttribute
                    attach="attributes-position"
                    count={count}
                    array={positions}
                    itemSize={3}
                />
                <bufferAttribute
                    attach="attributes-color"
                    count={count}
                    array={colors}
                    itemSize={3}
                />
            </bufferGeometry>
            <pointsMaterial
                size={0.025}
                transparent
                opacity={0.8}
                blending={THREE.AdditiveBlending}
                depthWrite={false}
                vertexColors
            />
        </points>
    );
};

// --- NEW ---
const AmbientShape: React.FC<{ position: THREE.Vector3, mouseVec: THREE.Vector3 }> = ({ position, mouseVec }) => {
  const ref = useRef<THREE.Mesh>(null!);
  const { theme } = useTheme();

  // Store original state to interpolate from
  const originalPosition = useMemo(() => position.clone(), [position]);
  const originalScale = useMemo(() => new THREE.Vector3(1, 1, 1), []);
  const hoverScale = useMemo(() => new THREE.Vector3(1.5, 1.5, 1.5), []);
  
  const material = useMemo(() => new THREE.MeshStandardMaterial({
    color: theme.gradientToHex,
    emissive: theme.gradientFromHex,
    emissiveIntensity: 0.1,
    metalness: 0.8,
    roughness: 0.2,
    transparent: true,
    opacity: 0.7,
  }), [theme]);

  useFrame((state, delta) => {
    if (!ref.current) return;

    // --- NEW: Parallax Effect ---
    // The shapes move slightly opposite to the cursor, creating an illusion of depth.
    const parallaxFactor = 0.2;
    const targetX = originalPosition.x - state.pointer.x * parallaxFactor;
    const targetY = originalPosition.y - state.pointer.y * parallaxFactor;

    // Smoothly interpolate the mesh position for a fluid parallax effect.
    ref.current.position.x = THREE.MathUtils.lerp(ref.current.position.x, targetX, 0.05);
    ref.current.position.y = THREE.MathUtils.lerp(ref.current.position.y, targetY, 0.05);

    // --- Proximity Interaction Logic ---
    const dist = ref.current.position.distanceTo(mouseVec);
    const isNearby = dist < 1.5;

    if (isNearby) {
      ref.current.rotation.y += delta * 0.5;
      ref.current.rotation.x += delta * 0.3;
    }

    ref.current.scale.lerp(isNearby ? hoverScale : originalScale, 0.1);

    const targetIntensity = isNearby ? 1.0 : 0.1;
    material.emissiveIntensity = THREE.MathUtils.lerp(material.emissiveIntensity, targetIntensity, 0.1);
  });

  return (
    <mesh ref={ref} position={position} material={material}>
      <octahedronGeometry args={[0.1, 0]} />
    </mesh>
  );
};

const AmbientShapes: React.FC<{ mouseVec: THREE.Vector3 }> = ({ mouseVec }) => {
  const shapes = useMemo(() => {
    const temp = [];
    for (let i = 0; i < 40; i++) {
      const radius = 2.5 + Math.random() * 2.5;
      const phi = Math.acos(2 * Math.random() - 1);
      const theta = Math.random() * Math.PI * 2;
      const pos = new THREE.Vector3().setFromSphericalCoords(radius, phi, theta);
      temp.push({ id: i, position: pos });
    }
    return temp;
  }, []);

  return (
    <group>
      {shapes.map(shape => (
        <AmbientShape key={shape.id} position={shape.position} mouseVec={mouseVec} />
      ))}
    </group>
  );
};

// Component to house the scene and R3F hooks, preventing them from running outside the Canvas
const Scene: React.FC<{
  sun: THREE.Mesh | null;
  setSun: React.Dispatch<React.SetStateAction<THREE.Mesh | null>>;
  interactive: boolean;
}> = ({ sun, setSun, interactive }) => {
  const { theme } = useTheme();
  const mouseVec = useRef(new THREE.Vector3(1000, 1000, 1000)).current;

  // This hook is now safely inside a component that will be a child of <Canvas>
  useFrame((state) => {
    mouseVec.lerp(
      new THREE.Vector3(
        (state.pointer.x * state.viewport.width) / 2,
        (state.pointer.y * state.viewport.height) / 2,
        0
      ),
      0.05
    );
  });

  return (
    <>
      <color attach="background" args={[theme.primaryBgColorHex]} />
      <fog attach="fog" args={[theme.primaryBgColorHex, 10, 25]} />
      <ambientLight intensity={0.1} />
      
      <DigitalCore ref={setSun} />
      <DataStream mouseVec={mouseVec} />
      <AmbientShapes mouseVec={mouseVec} />
      
      {interactive && <OrbitControls 
          enableZoom={false} 
          enablePan={false} 
          autoRotate 
          autoRotateSpeed={0.2}
          minPolarAngle={Math.PI / 3}
          maxPolarAngle={Math.PI * 2 / 3}
      />}
      
      <EffectComposer>
        <DepthOfField focusDistance={0} focalLength={0.02} bokehScale={2} height={480} />
        <Bloom
            kernelSize={KernelSize.LARGE}
            luminanceThreshold={0.6}
            luminanceSmoothing={0.1}
            intensity={1.0}
        />
        {sun && <GodRays 
            sun={sun}
            kernelSize={KernelSize.SMALL}
            density={0.8}
            decay={0.95}
            weight={0.6}
            exposure={0.4}
            samples={60}
            clampMax={1}
        />}
        <Vignette eskil={false} offset={0.1} darkness={1.1} />
      </EffectComposer>
    </>
  );
};


export const Hero3D: React.FC<{ interactive?: boolean }> = ({ interactive = true }) => {
  const [sun, setSun] = useState<THREE.Mesh | null>(null);

  return (
    <Canvas camera={{ position: [0, 2, 9], fov: 50 }}>
      <Scene sun={sun} setSun={setSun} interactive={interactive} />
    </Canvas>
  );
};