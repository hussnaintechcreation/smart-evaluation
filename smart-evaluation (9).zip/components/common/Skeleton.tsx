import React from 'react';
import { useTheme } from '../../contexts/ThemeContext';

interface SkeletonProps extends React.HTMLAttributes<HTMLDivElement> {}

export const Skeleton: React.FC<SkeletonProps> = ({ className, ...props }) => {
  const { theme } = useTheme();
  const baseClass = `animate-pulse ${theme.isDark ? 'bg-gray-700/50' : 'bg-slate-200'} rounded-md`;

  return (
    <div className={`${baseClass} ${className}`} {...props} />
  );
};
