import React, { Component, ErrorInfo, ReactNode } from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle } from 'lucide-react';
import { Button } from './Button';
import { useTheme } from '../../contexts/ThemeContext';

// Fallback UI as a functional component to use hooks
const ErrorFallback: React.FC<{ onReset: () => void }> = ({ onReset }) => {
  const { theme } = useTheme();

  return (
    <div className={`flex flex-col items-center justify-center min-h-screen p-4 ${theme.primaryBgClass}`}>
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className={`relative z-10 w-full max-w-md p-8 text-center ${theme.cardBgClass} backdrop-blur-xl border ${theme.borderColorClass} rounded-2xl shadow-2xl shadow-red-500/10`}
      >
        <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100 dark:bg-red-500/20 mb-4">
          <AlertTriangle className="h-6 w-6 text-red-600 dark:text-red-400" />
        </div>
        <h2 className="text-2xl font-bold gradient-text">Something went wrong.</h2>
        <p className="mt-2 text-gray-500 dark:text-gray-400">
          An unexpected error occurred. Please try refreshing the page. If the problem persists, contact support.
        </p>
        <Button onClick={onReset} className="mt-6">
          Refresh Page
        </Button>
      </motion.div>
    </div>
  );
};


interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
}

class ErrorBoundary extends Component<Props, State> {
  // FIX: The previous implementation using only a class field for state initialization
  // caused a type error where `this.props` was not found. Reverting to a standard
  // constructor ensures that the component's props and state are correctly
  // initialized and typed according to React's class component API.
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(_: Error): State {
    // Update state so the next render will show the fallback UI.
    return { hasError: true };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // You can also log the error to an error reporting service
    console.error("Uncaught error:", error, errorInfo);
  }
  
  handleReset = () => {
     // Simple reset by reloading the page
     window.location.reload();
  }

  render() {
    if (this.state.hasError) {
      return <ErrorFallback onReset={this.handleReset} />;
    }

    return this.props.children;
  }
}

export default ErrorBoundary;