
import React from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { APP_VERSION } from '../../pages/utils/version';

export const BrandFooter: React.FC = () => {
  const { theme } = useTheme();
  return (
    <div className={`mt-8 text-center text-xs ${theme.textColorClass}`}>
      <p>© {new Date().getFullYear()} Smart Evaluation Project.</p>
      <p className="font-semibold">Powered by HussnainTechVertex Pvt Ltd.</p>
      <p className="opacity-50 mt-1">Version {APP_VERSION}</p>
    </div>
  );
};
