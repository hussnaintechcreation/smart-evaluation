import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from './Button';
import { Shield, User, Bot, LogOut, UserCircle } from 'lucide-react';
import { SmartEvaluationIcon } from './SmartEvaluationIcon';
import { ThemeSelector } from './ThemeToggle';
import { useTheme } from '../../contexts/ThemeContext';

interface DashboardLayoutProps {
  userName: string;
  userRole: 'admin' | 'candidate';
  onLogout: () => void;
  title: string;
  children: React.ReactNode;
}

const UserProfileDropdown: React.FC<{ userName: string; onLogout: () => void; userRole: 'admin' | 'candidate' }> = ({ userName, onLogout, userRole }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [avatar, setAvatar] = useState<string | null>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const { theme } = useTheme();
  
  // Effect to get avatar from localStorage
  useEffect(() => {
    try {
      const savedAvatar = localStorage.getItem('htc-user-avatar');
      setAvatar(savedAvatar);
    } catch (e) {
      console.error("Failed to load avatar from localStorage", e);
    }
    // Listen for storage changes to update avatar if changed on another page
    const handleStorageChange = () => {
        setAvatar(localStorage.getItem('htc-user-avatar'));
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);
  
  // Effect to close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getInitials = (name: string) => {
      return name.split(' ').map(n => n[0]).join('').toUpperCase();
  }

  return (
    <div ref={dropdownRef} className="relative">
      <button onClick={() => setIsOpen(!isOpen)} className={`flex items-center gap-3 p-2 rounded-lg transition-colors ${theme.isDark ? 'hover:bg-gray-700/50' : 'hover:bg-slate-200'}`}>
        <div className="w-9 h-9 rounded-full bg-gradient-to-br flex items-center justify-center font-bold text-white" style={{ background: `linear-gradient(to bottom right, ${theme.gradientFromHex}, ${theme.gradientToHex})` }}>
          {avatar ? <img src={avatar} alt="User Avatar" className="w-full h-full rounded-full object-cover"/> : getInitials(userName)}
        </div>
        <div className="text-left hidden md:block">
            <p className={`font-semibold text-sm ${theme.textColorClass}`}>{userName}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400 capitalize">{userRole}</p>
        </div>
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className={`absolute right-0 mt-2 w-48 ${theme.cardBgClass} border ${theme.borderColorClass} rounded-lg shadow-xl overflow-hidden z-50`}
          >
            {userRole === 'candidate' && (
                <Link to="/profile" onClick={() => setIsOpen(false)} className={`flex items-center gap-3 w-full text-left px-4 py-2.5 text-sm ${theme.textColorClass} hover:${theme.isDark ? 'bg-gray-700/80' : 'bg-slate-200'} transition-colors`}>
                    <UserCircle size={16} /> My Profile
                </Link>
            )}
            <button onClick={onLogout} className={`flex items-center gap-3 w-full text-left px-4 py-2.5 text-sm ${theme.textColorClass} hover:${theme.isDark ? 'bg-gray-700/80' : 'bg-slate-200'} transition-colors`}>
              <LogOut size={16} /> Logout
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};


export const DashboardLayout: React.FC<DashboardLayoutProps> = ({ userName, userRole, onLogout, title, children }) => {
  const { theme } = useTheme();

  const roleConfig = {
    admin: { icon: <Shield size={12} /> },
    candidate: { icon: <User size={12} /> },
  };
  const currentRole = roleConfig[userRole];

  return (
    <div className="p-4 md:p-8">
      <header className="flex flex-col sm:flex-row justify-between sm:items-center mb-8 gap-4">
        <div>
          <div className="flex items-center gap-3 mb-1">
              <SmartEvaluationIcon iconOnly />
              <h1 className={`text-3xl font-bold ${theme.textColorClass}`}>{title}</h1>
          </div>
          <p className="text-gray-500 dark:text-gray-400 mt-1 flex items-center gap-2">
            <span>Welcome to Smart Evaluation</span>
          </p>
        </div>
        <div className="flex items-center gap-2">
            <ThemeSelector />
            <Link to="/ai-tools">
                <Button variant="secondary">
                    <Bot size={16} className="mr-2"/> AI Tools
                </Button>
            </Link>
            <UserProfileDropdown userName={userName} onLogout={onLogout} userRole={userRole}/>
        </div>
      </header>
      <main>{children}</main>
    </div>
  );
};
