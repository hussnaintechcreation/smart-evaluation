import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from './Button';
import { UploadCloud, X } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';

interface UpdateNotificationProps {
  isOpen: boolean;
  onDismiss: () => void;
  onRefresh: () => void;
}

export const UpdateNotification: React.FC<UpdateNotificationProps> = ({ isOpen, onDismiss, onRefresh }) => {
  const { theme } = useTheme();

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 50, scale: 0.9 }}
          transition={{ type: 'spring', stiffness: 200, damping: 25 }}
          className={`fixed bottom-6 right-6 z-50 w-full max-w-sm ${theme.cardBgClass} backdrop-blur-xl border ${theme.borderColorClass} rounded-2xl shadow-2xl shadow-cyan-500/10 p-5`}
        >
          <button 
            onClick={onDismiss} 
            className={`absolute top-3 right-3 text-gray-500 hover:${theme.isDark ? 'text-white' : 'text-slate-900'} transition-colors`}
            aria-label="Dismiss update notification"
          >
              <X size={20} />
          </button>
          
          <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-cyan-500/10 flex items-center justify-center" style={{ color: theme.gradientFromHex }}>
                <UploadCloud size={24} />
              </div>
              <div>
                  <h3 className={`font-semibold ${theme.textColorClass}`}>New Version Available</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      A new version of the application has been released. Refresh to get the latest features and improvements.
                  </p>
                  <div className="mt-4 flex items-center gap-3">
                      <Button onClick={onRefresh} size="sm">Refresh Now</Button>
                      <Button onClick={onDismiss} size="sm" variant="secondary">Later</Button>
                  </div>
              </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
