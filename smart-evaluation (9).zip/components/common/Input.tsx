import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTheme } from '../../contexts/ThemeContext';
import { Eye, EyeOff } from 'lucide-react';

type InputProps = React.InputHTMLAttributes<HTMLInputElement> & {
  error?: string;
};

export const Input: React.FC<InputProps> = ({ error, type, ...props }) => {
  const { theme } = useTheme();
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);

  const actualType = type === 'password' && isPasswordVisible ? 'text' : type;
  
  const errorVariants = {
    hidden: { opacity: 0, y: -5 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <div className="relative">
      <input
        {...props}
        type={actualType}
        className={`w-full px-4 py-3 ${type === 'password' ? 'pr-12' : ''} ${theme.isDark ? 'bg-gray-800/50 border-gray-700 text-gray-200' : 'bg-slate-200 border-slate-300 text-slate-800'} rounded-lg placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all duration-300 ${error ? 'border-red-500/50 focus:ring-red-500 focus:border-red-500' : ''}`}
      />
      {type === 'password' && (
        <button
          type="button"
          onClick={() => setIsPasswordVisible(!isPasswordVisible)}
          className="absolute inset-y-0 right-0 flex items-center pr-4 text-gray-500 hover:text-gray-400 transition-colors"
          aria-label={isPasswordVisible ? "Hide password" : "Show password"}
        >
          {isPasswordVisible ? <EyeOff size={18} /> : <Eye size={18} />}
        </button>
      )}
      <AnimatePresence>
        {error && (
          <motion.p
            variants={errorVariants}
            initial="hidden"
            animate="visible"
            exit="hidden"
            transition={{ duration: 0.2 }}
            className="mt-1.5 text-xs text-red-400"
          >
            {error}
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
};
