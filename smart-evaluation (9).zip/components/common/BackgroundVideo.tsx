import React from 'react';

interface BackgroundVideoProps {
  src: string;
}

export const BackgroundVideo: React.FC<BackgroundVideoProps> = ({ src }) => {
  return (
    <video
      autoPlay
      loop
      muted
      playsInline
      className="fixed inset-0 w-full h-full object-cover -z-10 opacity-20"
      src={src}
    />
  );
};
