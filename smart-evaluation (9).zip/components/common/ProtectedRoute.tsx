import React from 'react';
import { Navigate } from 'react-router-dom';
import type { User } from '../../types';

interface ProtectedRouteProps {
  user: User | null;
  allowedRoles: Array<'admin' | 'candidate'>;
  children: React.ReactElement;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ user, allowedRoles, children }) => {
  if (!user) {
    // User not logged in, redirect to login page.
    // `replace` prevents the user from navigating back to the protected route.
    return <Navigate to="/login" replace />;
  }

  if (!allowedRoles.includes(user.role)) {
    // User's role is not allowed for this route.
    // Redirect them to their respective dashboard to prevent unauthorized access.
    const homePath = user.role === 'admin' ? '/admin' : '/candidate';
    return <Navigate to={homePath} replace />;
  }

  // User is authenticated and has an allowed role, render the component.
  return children;
};