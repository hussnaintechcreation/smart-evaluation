import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence, Variants } from 'framer-motion';
import { Volume2, VolumeX, Play, Pause, LoaderCircle } from 'lucide-react';
import { audioManager } from '../../pages/utils/audioManager';
import { useTheme } from '../../contexts/ThemeContext';

const AMBIENT_AUDIO_URL = 'https://cdn.pixabay.com/audio/2022/10/19/audio_2932333b63.mp3';

export const AmbientAudioPlayer: React.FC = () => {
    const [playerState, setPlayerState] = useState(audioManager.getState());
    const [isHovered, setIsHovered] = useState(false);
    const { theme } = useTheme();

    const syncState = useCallback(() => {
        setPlayerState(audioManager.getState());
    }, []);

    useEffect(() => {
        // Poll for state changes from the audio manager, which is outside React's lifecycle.
        // Initialization is now handled by the first user interaction in `handlePlayPause`.
        const interval = setInterval(syncState, 500);
        return () => clearInterval(interval);

    }, [syncState]);

    const handlePlayPause = () => {
        if (playerState.isLoading) return;
        
        if (!playerState.isInitialized) {
            // First interaction, trigger init
            audioManager.init(AMBIENT_AUDIO_URL).then(() => {
                audioManager.play();
                syncState();
            });
        } else {
            if (playerState.isPlaying) {
                audioManager.pause();
            } else {
                audioManager.play();
            }
        }
        syncState(); // Immediately update UI
    };

    const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newVolume = parseFloat(e.target.value);
        audioManager.setVolume(newVolume);
        syncState();
    };
    
    // FIX: Explicitly typed the variants object with the 'Variants' type from Framer Motion.
    // This helps TypeScript correctly interpret the 'ease' property as a valid Easing type,
    // resolving the type error.
    const controlVariants: Variants = {
        hidden: { opacity: 0, width: 0, x: -10 },
        visible: { opacity: 1, width: '8rem', x: 0, transition: { duration: 0.3, ease: 'easeOut' }},
    };

    return (
        <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1, duration: 0.5 }}
            className={`fixed bottom-6 left-6 z-40 flex items-center gap-2 p-2 ${theme.cardBgClass} backdrop-blur-md border ${theme.borderColorClass} rounded-full shadow-lg`}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
        >
            <button 
                onClick={handlePlayPause} 
                disabled={playerState.isLoading}
                className={`w-10 h-10 flex-shrink-0 flex items-center justify-center rounded-full text-white transition-colors`}
                style={{ background: `linear-gradient(to right, ${theme.gradientFromHex}, ${theme.gradientToHex})` }}
                aria-label={playerState.isPlaying ? "Pause ambient audio" : "Play ambient audio"}
            >
                {playerState.isLoading ? (
                    <LoaderCircle size={20} className="animate-spin" />
                ) : playerState.isPlaying ? (
                    <Pause size={20} />
                ) : (
                    <Play size={20} className="ml-0.5" />
                )}
            </button>
            <AnimatePresence>
            {isHovered && (
                <motion.div 
                    variants={controlVariants}
                    initial="hidden"
                    animate="visible"
                    exit="hidden"
                    className="flex items-center gap-2 overflow-hidden"
                >
                    {playerState.volume > 0 ? <Volume2 size={20} /> : <VolumeX size={20} />}
                    <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.01"
                        value={playerState.volume}
                        onChange={handleVolumeChange}
                        className="w-full h-1 bg-gray-600/50 rounded-lg appearance-none cursor-pointer"
                        style={{ accentColor: theme.gradientFromHex }}
                        aria-label="Volume control"
                    />
                </motion.div>
            )}
            </AnimatePresence>
        </motion.div>
    );
};
