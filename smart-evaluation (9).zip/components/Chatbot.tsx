

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, Variants } from 'framer-motion';
import { MessageSquare, Send, X, Bot } from 'lucide-react';
import { Link } from 'react-router-dom';
import { FunctionDeclaration, Type } from '@google/genai';
import { techStackData } from '../constants';
import { getGenAIClient } from '../pages/utils/gemini';
import { useTheme } from '../contexts/ThemeContext';

interface Message {
  id: number;
  text: string;
  sender: 'user' | 'bot';
}

const systemInstruction = `You are a helpful AI assistant for HussnainTechVertex Pvt Ltd. The owner and developer of this project is Hussnain. Your purpose is to answer questions about the company's project, its architecture, and the technologies used. Be concise and helpful. You can also help users find their way around the site byusing the navigateToPage function. Here is the tech stack data for context: ${JSON.stringify(techStackData)}`;

const fabVariants: Variants = {
    hidden: { scale: 0, rotate: -45 },
    visible: { scale: 1, rotate: 0, transition: { type: 'spring', stiffness: 260, damping: 20 }},
};

const chatWindowVariants: Variants = {
    hidden: { opacity: 0, y: 30, scale: 0.95 },
    visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.3, ease: 'easeOut' }},
    exit: { opacity: 0, y: 30, scale: 0.95, transition: { duration: 0.2, ease: 'easeIn' }},
};

// Function declaration for Gemini to understand navigation tasks
const navigationFunction: FunctionDeclaration = {
  name: 'navigateToPage',
  description: 'Provides a link to a specific page within the application when a user asks where to find something.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      page: {
        type: Type.STRING,
        description: 'The page to navigate to. Must be one of: "ai-tools", "profile", "candidate-dashboard", "admin-dashboard".',
      },
    },
    required: ['page'],
  },
};

const pageMap = {
    'ai-tools': { path: '/ai-tools', name: 'AI Tools Page' },
    'profile': { path: '/profile', name: 'Profile Page' },
    'candidate-dashboard': { path: '/candidate', name: 'Candidate Dashboard' },
    'admin-dashboard': { path: '/admin', name: 'Admin Dashboard' },
};

/**
 * A component to safely render chat message content, parsing markdown-style links
 * into clickable React Router Links.
 */
const ChatMessageContent = ({ text }: { text: string }) => {
    const { theme } = useTheme();
    const linkRegex = /\[([^\]]+)\]\(([^)]+)\)/g;
    const parts = text.split(linkRegex);
  
    return (
      <p className="text-sm break-words">
        {parts.map((part, index) => {
          if (index % 3 === 1) { // This part is the link text
            const linkPath = parts[index + 1];
            // Only render internal links for security
            if (linkPath && linkPath.startsWith('/')) {
              // FIX: Use theme colors for links instead of hardcoded values.
              return <Link key={index} to={linkPath} className="underline transition-all hover:brightness-90" style={{ color: theme.gradientFromHex }}>{part}</Link>;
            }
            // Fallback for malformed or external links
            return `[${part}](${linkPath})`; 
          } else if (index % 3 === 2) { // This is the path, which we've already used
            return null;
          } else { // This is a regular text part
            return part;
          }
        }).filter(Boolean)}
      </p>
    );
  };


export const Chatbot: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [messages, setMessages] = useState<Message[]>([]);
    const [inputValue, setInputValue] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef<null | HTMLDivElement>(null);
    const { theme } = useTheme();

    useEffect(() => {
        try {
            const storedMessages = localStorage.getItem('htc-chat-history');
            if (storedMessages) {
                setMessages(JSON.parse(storedMessages));
            } else {
                setMessages([
                    { id: Date.now(), text: "Welcome! I'm the HussnainTechVertex AI Assistant. Feel free to ask me anything about this project, its architecture, or the technologies we're using.", sender: 'bot' }
                ]);
            }
        } catch (error) {
            console.error("Failed to parse chat history from localStorage", error);
            setMessages([
                { id: Date.now(), text: "Welcome! I'm the HussnainTechVertex AI Assistant. Feel free to ask me anything about this project, its architecture, or the technologies we're using.", sender: 'bot' }
            ]);
        }
    }, []);

    useEffect(() => {
        if (messages.length > 0) {
            try {
                localStorage.setItem('htc-chat-history', JSON.stringify(messages));
            } catch (error) {
                console.error("Failed to save chat history to localStorage", error);
            }
        }
    }, [messages]);
    
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, isLoading]);

    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!inputValue.trim() || isLoading) return;

        const userMessage: Message = { id: Date.now(), text: inputValue, sender: 'user' };
        setMessages(prev => [...prev, userMessage]);
        setInputValue('');
        setIsLoading(true);

        try {
            const ai = getGenAIClient();
            // We pass a subset of the history to keep the payload reasonable
            const conversationHistory = messages.slice(-6).map(msg => ({
                role: msg.sender === 'user' ? 'user' : 'model',
                parts: [{ text: msg.text }]
            }));

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: [
                    ...conversationHistory,
                    { role: 'user', parts: [{ text: inputValue }] }
                ],
                config: {
                    systemInstruction: systemInstruction,
                    tools: [{ functionDeclarations: [navigationFunction] }],
                },
            });

            let botResponseText = response.text || '';

            // Handle function calls if the model returns any
            if (response.functionCalls) {
                for (const funcCall of response.functionCalls) {
                    if (funcCall.name === 'navigateToPage') {
                        const pageKey = funcCall.args.page as keyof typeof pageMap;
                        const pageInfo = pageMap[pageKey];
                        if (pageInfo) {
                            // Append a markdown link to the response text
                            botResponseText += ` Here is a direct link: [${pageInfo.name}](${pageInfo.path})`;
                        }
                    }
                }
            }

            if (botResponseText.trim()) {
                const botMessage: Message = { id: Date.now() + 1, text: botResponseText.trim(), sender: 'bot' };
                setMessages(prev => [...prev, botMessage]);
            } else {
                 const errorMessage: Message = {
                    id: Date.now() + 1,
                    text: "I'm not sure how to respond to that. Could you try rephrasing?",
                    sender: 'bot',
                };
                setMessages(prev => [...prev, errorMessage]);
            }

        } catch (error) {
            console.error("Error calling Gemini API:", error);
            const errorMessage: Message = {
                id: Date.now() + 1,
                text: "Sorry, I'm having trouble connecting right now. Please try again later.",
                sender: 'bot',
            };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
        <>
            <motion.button
                variants={fabVariants}
                initial="hidden"
                animate="visible"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setIsOpen(!isOpen)}
                className="fixed bottom-6 right-6 z-40 w-16 h-16 bg-gradient-to-r text-white rounded-full shadow-lg shadow-cyan-500/30 flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-100 dark:focus:ring-offset-gray-900 focus:ring-cyan-400"
                aria-label="Toggle Chat"
                style={{ background: `linear-gradient(to right, ${theme.gradientFromHex}, ${theme.gradientToHex})` }}
            >
                <AnimatePresence>
                    {isOpen ? <X size={30} /> : <MessageSquare size={30} />}
                </AnimatePresence>
            </motion.button>
            
            <AnimatePresence>
            {isOpen && (
                <motion.div
                    variants={chatWindowVariants}
                    initial="hidden"
                    animate="visible"
                    exit="exit"
                    className={`fixed bottom-24 right-6 z-50 w-[calc(100vw-3rem)] max-w-sm h-[60vh] max-h-[500px] ${theme.cardBgClass} backdrop-blur-xl border ${theme.borderColorClass} rounded-2xl shadow-2xl shadow-cyan-500/10 flex flex-col`}
                >
                    <header className={`flex items-center justify-between p-4 border-b ${theme.isDark ? 'border-gray-700/50' : 'border-slate-200'}`}>
                        <h3 className="font-bold text-lg gradient-text">HTV AI Assistant</h3>
                        <button onClick={() => setIsOpen(false)} className={`text-gray-500 hover:${theme.isDark ? 'text-white' : 'text-slate-900'} transition-colors`}>
                            <X size={20} />
                        </button>
                    </header>
                    <div className="flex-1 p-4 space-y-4 overflow-y-auto">
                        {messages.map((msg) => (
                            <div key={msg.id} className={`flex items-end gap-2 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                                {msg.sender === 'bot' && <div className={`w-8 h-8 flex-shrink-0 ${theme.isDark ? 'bg-gray-700' : 'bg-slate-200'} rounded-full flex items-center justify-center`}><Bot style={{color: theme.gradientFromHex}} size={20}/></div>}
                                <div className={`max-w-[80%] px-4 py-2 rounded-2xl ${msg.sender === 'user' ? `text-white rounded-br-none` : `${theme.isDark ? 'bg-gray-700 text-gray-200' : 'bg-slate-200 text-slate-800'} rounded-bl-none`}`}
                                  style={msg.sender === 'user' ? { background: theme.gradientToHex } : {}}
                                >
                                    <ChatMessageContent text={msg.text} />
                                </div>
                            </div>
                        ))}
                        {isLoading && (
                            <div className="flex items-end gap-2 justify-start">
                                <div className={`w-8 h-8 flex-shrink-0 ${theme.isDark ? 'bg-gray-700' : 'bg-slate-200'} rounded-full flex items-center justify-center`}><Bot style={{color: theme.gradientFromHex}} size={20}/></div>
                                <div className={`px-4 py-3 rounded-2xl ${theme.isDark ? 'bg-gray-700' : 'bg-slate-200'} rounded-bl-none`}>
                                   <div className="flex items-center space-x-2">
                                       <div className={`h-2 w-16 ${theme.isDark ? 'bg-gray-600' : 'bg-slate-300'} rounded-full animate-pulse`}></div>
                                   </div>
                                </div>
                            </div>
                        )}
                        <div ref={messagesEndRef} />
                    </div>
                    <form onSubmit={handleSendMessage} className={`p-4 border-t ${theme.isDark ? 'border-gray-700/50' : 'border-slate-200'}`}>
                        <div className={`flex items-center ${theme.isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-slate-200/50 border-slate-300'} rounded-lg focus-within:ring-2 focus-within:ring-cyan-500 transition-all`}>
                            <input
                                type="text"
                                value={inputValue}
                                onChange={(e) => setInputValue(e.target.value)}
                                placeholder="Ask a question..."
                                className={`w-full px-4 py-2 bg-transparent ${theme.textColorClass} placeholder-gray-500 focus:outline-none`}
                                disabled={isLoading}
                            />
                            <button type="submit" className={`p-3 text-gray-500 dark:text-gray-400 hover:text-cyan-400 disabled:text-gray-400 dark:disabled:text-gray-600 transition-colors`} disabled={isLoading}
                            style={{color: theme.gradientFromHex}}
                            >
                                <Send size={20} />
                            </button>
                        </div>
                    </form>
                </motion.div>
            )}
            </AnimatePresence>
        </>
    );
};
